import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Header } from './components/layout/Header';
import { Footer } from './components/layout/Footer';
import { HomePage } from './pages/HomePage';
import { CollectionsPage } from './pages/CollectionsPage';
import { CollectionPage } from './pages/CollectionPage';
import { BriefPage } from './pages/BriefPage';
import { OrderTrackingPage } from './pages/OrderTrackingPage';
import { UsefulPage } from './pages/UsefulPage';
import { AdminPage } from './pages/AdminPage';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-dark-950">
        <Routes>
          {/* Административная панель без общего layout */}
          <Route path="/admin" element={<AdminPage />} />
          
          {/* Основные страницы с общим layout */}
          <Route path="/*" element={
            <>
              <Header />
              <Routes>
                <Route path="/" element={<HomePage />} />
                <Route path="/collections" element={<CollectionsPage />} />
                <Route path="/useful" element={<UsefulPage />} />
                <Route path="/collection/:slug" element={<CollectionPage />} />
                <Route path="/collection/:slug/brief" element={<BriefPage />} />
                <Route path="/order/search" element={<OrderTrackingPage />} />
                <Route path="/order/:orderNumber" element={<OrderTrackingPage />} />
              </Routes>
              <Footer />
            </>
          } />
        </Routes>
      </div>
    </Router>
  );
}

export default App;