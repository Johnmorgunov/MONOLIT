import React from 'react';
import { LogOut, User, Shield } from 'lucide-react';
import { Button } from '../ui/Button';
import type { AdminSession } from '../../types/admin';

interface AdminHeaderProps {
  session: AdminSession;
  onLogout: () => void;
}

export const AdminHeader: React.FC<AdminHeaderProps> = ({ session, onLogout }) => {
  return (
    <header className="bg-dark-900/95 backdrop-blur-lg border-b border-gold-400/20 sticky top-0 z-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-4">
            <div className="w-8 h-8 bg-gold-400 rounded-full flex items-center justify-center">
              <Shield size={20} className="text-black" />
            </div>
            <div>
              <h1 className="font-manrope text-lg font-medium text-white">
                Административная панель
              </h1>
              <p className="text-xs text-gray-400">
                MONOLIT Kitchen Management
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2 text-sm">
              <User size={16} className="text-gold-400" />
              <span className="text-white">{session.user.username}</span>
              <span className="text-gray-400">({session.user.role})</span>
            </div>
            
            <Button
              variant="outline"
              size="sm"
              onClick={onLogout}
              className="flex items-center space-x-2"
            >
              <LogOut size={16} />
              <span>Выйти</span>
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
};
