import React, { useState } from 'react';
import { Lock, User, AlertCircle } from 'lucide-react';
import { Button } from '../ui/Button';
import { LoadingSpinner } from '../ui/LoadingSpinner';
import { adminService } from '../../services/adminService';
import type { AdminSession } from '../../types/admin';

interface AdminLoginProps {
  onLogin: (session: AdminSession) => void;
}

export const AdminLogin: React.FC<AdminLoginProps> = ({ onLogin }) => {
  const [credentials, setCredentials] = useState({
    username: '',
    password: ''
  });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);

    try {
      const session = await adminService.login(credentials.username, credentials.password);
      
      if (session) {
        onLogin(session);
      } else {
        setError('Неверные учетные данные');
      }
    } catch (err) {
      setError('Ошибка входа в систему');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-dark-950 flex items-center justify-center p-4">
      <div className="max-w-md w-full">
        <div className="bg-dark-900/50 backdrop-blur-sm border border-gold-400/20 p-8">
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-gold-400 rounded-full flex items-center justify-center mx-auto mb-4">
              <Lock size={32} className="text-black" />
            </div>
            <h1 className="font-manrope text-2xl font-medium text-white mb-2">
              Административная панель
            </h1>
            <p className="text-gray-400">
              Войдите для управления заказами
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-white mb-2">
                Имя пользователя
              </label>
              <div className="relative">
                <User size={20} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  value={credentials.username}
                  onChange={(e) => setCredentials(prev => ({ ...prev, username: e.target.value }))}
                  className="w-full pl-10 pr-4 py-3 bg-dark-800 border border-gray-600 text-white focus:outline-none focus:border-gold-400 transition-colors duration-300"
                  placeholder="admin или manager"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-white mb-2">
                Пароль
              </label>
              <div className="relative">
                <Lock size={20} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input
                  type="password"
                  value={credentials.password}
                  onChange={(e) => setCredentials(prev => ({ ...prev, password: e.target.value }))}
                  className="w-full pl-10 pr-4 py-3 bg-dark-800 border border-gray-600 text-white focus:outline-none focus:border-gold-400 transition-colors duration-300"
                  placeholder="admin123 или manager123"
                  required
                />
              </div>
            </div>

            {error && (
              <div className="flex items-center space-x-2 p-3 bg-red-900/20 border border-red-500/30 text-red-300">
                <AlertCircle size={16} />
                <span className="text-sm">{error}</span>
              </div>
            )}

            <Button
              variant="primary"
              size="lg"
              disabled={isLoading}
              className="w-full flex items-center justify-center space-x-2"
            >
              {isLoading ? (
                <>
                  <LoadingSpinner size="sm" />
                  <span>Вход...</span>
                </>
              ) : (
                <span>Войти</span>
              )}
            </Button>
          </form>

          <div className="mt-6 p-4 bg-blue-900/20 border border-blue-500/30 rounded">
            <p className="text-blue-300 text-sm">
              <strong>Тестовые учетные данные:</strong><br />
              Администратор: admin / admin123<br />
              Менеджер: manager / manager123
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
