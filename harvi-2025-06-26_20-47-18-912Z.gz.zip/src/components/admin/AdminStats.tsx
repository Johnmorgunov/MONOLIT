import React from 'react';
import { Package, Clock, CheckCircle, TrendingUp, AlertTriangle } from 'lucide-react';
import { AnimatedSection } from '../ui/AnimatedSection';
import type { AdminStats } from '../../types/admin';

interface AdminStatsProps {
  stats: AdminStats;
}

export const AdminStats: React.FC<AdminStatsProps> = ({ stats }) => {
  const statCards = [
    {
      icon: <Package size={24} className="text-blue-400" />,
      title: 'Всего заказов',
      value: stats.totalOrders.toString(),
      description: 'Общее количество заказов'
    },
    {
      icon: <Clock size={24} className="text-gold-400" />,
      title: 'Активные заказы',
      value: stats.activeOrders.toString(),
      description: 'Заказы в работе'
    },
    {
      icon: <CheckCircle size={24} className="text-green-400" />,
      title: 'Завершенные',
      value: stats.completedOrders.toString(),
      description: 'Выполненные заказы'
    },
    {
      icon: <AlertTriangle size={24} className="text-red-400" />,
      title: 'Просроченные',
      value: stats.overdueOrders.toString(),
      description: 'Заказы с просрочкой'
    },
    {
      icon: <TrendingUp size={24} className="text-purple-400" />,
      title: 'Среднее время',
      value: `${Math.round(stats.averageCompletionTime)} дн.`,
      description: 'Среднее время выполнения'
    }
  ];

  return (
    <div className="space-y-8">
      {/* Основная статистика */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
        {statCards.map((card, index) => (
          <AnimatedSection key={index}>
            <div className="bg-dark-900/50 backdrop-blur-sm border border-gold-400/10 p-6 hover:border-gold-400/30 transition-all duration-300">
              <div className="flex items-center mb-4">
                {card.icon}
                <h3 className="font-manrope text-sm font-medium text-white ml-3">
                  {card.title}
                </h3>
              </div>
              <div className="text-2xl font-bold text-white mb-2">
                {card.value}
              </div>
              <p className="text-xs text-gray-400">
                {card.description}
              </p>
            </div>
          </AnimatedSection>
        ))}
      </div>

      {/* Статистика по этапам */}
      <AnimatedSection>
        <div className="bg-dark-900/50 backdrop-blur-sm border border-gold-400/10 p-6">
          <h3 className="font-manrope text-lg font-medium text-white mb-6">
            Статистика по этапам
          </h3>
          
          <div className="space-y-4">
            {stats.stageStatistics.map((stage, index) => (
              <div key={stage.stageId} className="flex items-center justify-between p-4 bg-dark-800/50 border border-gray-700">
                <div className="flex-1">
                  <h4 className="text-white font-medium mb-1">
                    {stage.stageName}
                  </h4>
                  <div className="flex items-center space-x-4 text-sm text-gray-400">
                    <span>Средняя длительность: {stage.averageDuration} дн.</span>
                    <span>Процент завершения: {Math.round(stage.completionRate)}%</span>
                    {stage.overdueCount > 0 && (
                      <span className="text-red-400">Просрочено: {stage.overdueCount}</span>
                    )}
                  </div>
                </div>
                
                <div className="w-32">
                  <div className="w-full bg-gray-700 h-2 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gold-400 transition-all duration-500"
                      style={{ width: `${stage.completionRate}%` }}
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </AnimatedSection>
    </div>
  );
};
