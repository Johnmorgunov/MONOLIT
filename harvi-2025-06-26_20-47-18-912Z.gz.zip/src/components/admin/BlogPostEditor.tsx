import React, { useState, useEffect } from 'react';
import { Save, X, Eye, EyeOff } from 'lucide-react';
import { Button } from '../ui/Button';
import { FormField } from '../ui/FormField';
import { contentService } from '../../services/contentService';
import type { BlogPost, BlogCategory } from '../../types';

interface BlogPostEditorProps {
  post?: BlogPost;
  onSave: () => void;
  onCancel: () => void;
}

export const BlogPostEditor: React.FC<BlogPostEditorProps> = ({
  post,
  onSave,
  onCancel
}) => {
  const [formData, setFormData] = useState({
    title: '',
    slug: '',
    excerpt: '',
    content: '',
    featuredImage: '',
    categoryId: '',
    tags: '',
    author: '',
    isPublished: false,
    readTime: 5
  });

  const [categories, setCategories] = useState<BlogCategory[]>([]);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    setCategories(contentService.getBlogCategories());
    
    if (post) {
      setFormData({
        title: post.title,
        slug: post.slug,
        excerpt: post.excerpt,
        content: post.content,
        featuredImage: post.featuredImage,
        categoryId: post.category.id,
        tags: post.tags.join(', '),
        author: post.author,
        isPublished: post.isPublished,
        readTime: post.readTime
      });
    }
  }, [post]);

  const handleInputChange = (field: string, value: string | number | boolean) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    
    // Автогенерация slug при изменении заголовка
    if (field === 'title' && typeof value === 'string') {
      const generatedSlug = contentService.generateSlug(value);
      setFormData(prev => ({ ...prev, slug: generatedSlug }));
    }
    
    // Очистка ошибки при изменении поля
    if (errors[field]) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[field];
        return newErrors;
      });
    }
  };

  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.title.trim()) {
      newErrors.title = 'Заголовок обязателен';
    }
    
    if (!formData.slug.trim()) {
      newErrors.slug = 'Slug обязателен';
    } else if (!contentService.isSlugUnique(formData.slug, post?.id)) {
      newErrors.slug = 'Такой slug уже существует';
    }
    
    if (!formData.excerpt.trim()) {
      newErrors.excerpt = 'Краткое описание обязательно';
    }
    
    if (!formData.content.trim()) {
      newErrors.content = 'Содержание статьи обязательно';
    }
    
    if (!formData.featuredImage.trim()) {
      newErrors.featuredImage = 'Изображение обязательно';
    }
    
    if (!formData.categoryId) {
      newErrors.categoryId = 'Категория обязательна';
    }
    
    if (!formData.author.trim()) {
      newErrors.author = 'Автор обязателен';
    }
    
    if (formData.readTime < 1) {
      newErrors.readTime = 'Время чтения должно быть больше 0';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;
    
    setIsSubmitting(true);
    
    try {
      const category = categories.find(c => c.id === formData.categoryId);
      if (!category) throw new Error('Категория не найдена');
      
      const postData = {
        ...(post && { id: post.id }),
        title: formData.title.trim(),
        slug: formData.slug.trim(),
        excerpt: formData.excerpt.trim(),
        content: formData.content.trim(),
        featuredImage: formData.featuredImage.trim(),
        category,
        tags: formData.tags.split(',').map(tag => tag.trim()).filter(tag => tag),
        author: formData.author.trim(),
        isPublished: formData.isPublished,
        readTime: formData.readTime
      };
      
      contentService.saveBlogPost(postData);
      onSave();
    } catch (error) {
      setErrors({ submit: `Ошибка сохранения: ${error}` });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="bg-dark-900/50 backdrop-blur-sm border border-gold-400/10 p-8 rounded-xl">
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <FormField label="Заголовок" error={errors.title} required>
            <input
              type="text"
              value={formData.title}
              onChange={(e) => handleInputChange('title', e.target.value)}
              className="w-full p-3 bg-dark-800 border border-gray-600 text-white focus:outline-none focus:border-gold-400 rounded-lg"
              placeholder="Введите заголовок статьи"
            />
          </FormField>

          <FormField label="Slug (URL)" error={errors.slug} required>
            <input
              type="text"
              value={formData.slug}
              onChange={(e) => handleInputChange('slug', e.target.value)}
              className="w-full p-3 bg-dark-800 border border-gray-600 text-white focus:outline-none focus:border-gold-400 rounded-lg"
              placeholder="url-статьи"
            />
          </FormField>
        </div>

        <FormField label="Краткое описание" error={errors.excerpt} required>
          <textarea
            value={formData.excerpt}
            onChange={(e) => handleInputChange('excerpt', e.target.value)}
            className="w-full p-3 bg-dark-800 border border-gray-600 text-white focus:outline-none focus:border-gold-400 rounded-lg"
            rows={3}
            placeholder="Краткое описание статьи для превью"
          />
        </FormField>

        <FormField label="Содержание статьи (Markdown)" error={errors.content} required>
          <textarea
            value={formData.content}
            onChange={(e) => handleInputChange('content', e.target.value)}
            className="w-full p-3 bg-dark-800 border border-gray-600 text-white focus:outline-none focus:border-gold-400 rounded-lg font-mono text-sm"
            rows={15}
            placeholder="# Заголовок статьи

Содержание статьи в формате Markdown..."
          />
        </FormField>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <FormField label="URL изображения" error={errors.featuredImage} required>
            <input
              type="url"
              value={formData.featuredImage}
              onChange={(e) => handleInputChange('featuredImage', e.target.value)}
              className="w-full p-3 bg-dark-800 border border-gray-600 text-white focus:outline-none focus:border-gold-400 rounded-lg"
              placeholder="https://example.com/image.jpg"
            />
          </FormField>

          <FormField label="Категория" error={errors.categoryId} required>
            <select
              value={formData.categoryId}
              onChange={(e) => handleInputChange('categoryId', e.target.value)}
              className="w-full p-3 bg-dark-800 border border-gray-600 text-white focus:outline-none focus:border-gold-400 rounded-lg"
            >
              <option value="">Выберите категорию</option>
              {categories.map(category => (
                <option key={category.id} value={category.id}>
                  {category.name}
                </option>
              ))}
            </select>
          </FormField>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <FormField label="Теги (через запятую)" error={errors.tags}>
            <input
              type="text"
              value={formData.tags}
              onChange={(e) => handleInputChange('tags', e.target.value)}
              className="w-full p-3 bg-dark-800 border border-gray-600 text-white focus:outline-none focus:border-gold-400 rounded-lg"
              placeholder="дизайн, кухня, советы"
            />
          </FormField>

          <FormField label="Автор" error={errors.author} required>
            <input
              type="text"
              value={formData.author}
              onChange={(e) => handleInputChange('author', e.target.value)}
              className="w-full p-3 bg-dark-800 border border-gray-600 text-white focus:outline-none focus:border-gold-400 rounded-lg"
              placeholder="Имя автора"
            />
          </FormField>

          <FormField label="Время чтения (мин)" error={errors.readTime} required>
            <input
              type="number"
              min="1"
              max="60"
              value={formData.readTime}
              onChange={(e) => handleInputChange('readTime', parseInt(e.target.value) || 1)}
              className="w-full p-3 bg-dark-800 border border-gray-600 text-white focus:outline-none focus:border-gold-400 rounded-lg"
            />
          </FormField>
        </div>

        <div className="flex items-center space-x-3">
          <label className="flex items-center space-x-2 cursor-pointer">
            <input
              type="checkbox"
              checked={formData.isPublished}
              onChange={(e) => handleInputChange('isPublished', e.target.checked)}
              className="w-4 h-4 text-gold-400 bg-dark-800 border-gray-600 rounded focus:ring-gold-400"
            />
            <span className="text-white flex items-center space-x-2">
              {formData.isPublished ? <Eye size={16} /> : <EyeOff size={16} />}
              <span>{formData.isPublished ? 'Опубликовано' : 'Черновик'}</span>
            </span>
          </label>
        </div>

        {errors.submit && (
          <div className="p-4 bg-red-900/20 border border-red-500/30 text-red-300 rounded-lg">
            {errors.submit}
          </div>
        )}

        <div className="flex justify-end space-x-4 pt-6 border-t border-gray-700">
          <Button
            type="button"
            variant="outline"
            onClick={onCancel}
            disabled={isSubmitting}
          >
            Отмена
          </Button>
          <Button
            type="submit"
            variant="primary"
            disabled={isSubmitting}
            className="flex items-center space-x-2"
          >
            <Save size={16} />
            <span>{isSubmitting ? 'Сохранение...' : 'Сохранить'}</span>
          </Button>
        </div>
      </form>
    </div>
  );
};