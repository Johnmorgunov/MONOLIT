import React, { useState, useEffect } from 'react';
import { Save, Plus, Trash2 } from 'lucide-react';
import { Button } from '../ui/Button';
import { FormField } from '../ui/FormField';
import { contentService } from '../../services/contentService';
import type { Collection } from '../../types';

interface CollectionEditorProps {
  collection?: Collection;
  onSave: () => void;
  onCancel: () => void;
}

export const CollectionEditor: React.FC<CollectionEditorProps> = ({
  collection,
  onSave,
  onCancel
}) => {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    detailedDescription: '',
    price: '',
    startingPrice: 0,
    image: '',
    slug: '',
    features: [''],
    materials: [''],
    colors: [''],
    sizes: [''],
    warranty: '',
    gallery: ['']
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (collection) {
      setFormData({
        title: collection.title,
        description: collection.description,
        detailedDescription: collection.detailedDescription,
        price: collection.price,
        startingPrice: collection.startingPrice,
        image: collection.image,
        slug: collection.slug,
        features: collection.features.length > 0 ? collection.features : [''],
        materials: collection.specifications.materials.length > 0 ? collection.specifications.materials : [''],
        colors: collection.specifications.colors.length > 0 ? collection.specifications.colors : [''],
        sizes: collection.specifications.sizes.length > 0 ? collection.specifications.sizes : [''],
        warranty: collection.specifications.warranty,
        gallery: collection.gallery.length > 0 ? collection.gallery : ['']
      });
    }
  }, [collection]);

  const handleInputChange = (field: string, value: string | number) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    
    // Автогенерация slug при изменении заголовка
    if (field === 'title' && typeof value === 'string') {
      const generatedSlug = contentService.generateSlug(value);
      setFormData(prev => ({ ...prev, slug: generatedSlug }));
    }
    
    // Автогенерация цены при изменении стартовой цены
    if (field === 'startingPrice' && typeof value === 'number') {
      const formattedPrice = `от ${new Intl.NumberFormat('ru-RU').format(value)} ₽`;
      setFormData(prev => ({ ...prev, price: formattedPrice }));
    }
    
    // Очистка ошибки при изменении поля
    if (errors[field]) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[field];
        return newErrors;
      });
    }
  };

  const handleArrayChange = (field: string, index: number, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: prev[field as keyof typeof prev].map((item: string, i: number) => 
        i === index ? value : item
      )
    }));
  };

  const addArrayItem = (field: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: [...prev[field as keyof typeof prev], '']
    }));
  };

  const removeArrayItem = (field: string, index: number) => {
    setFormData(prev => ({
      ...prev,
      [field]: prev[field as keyof typeof prev].filter((_: string, i: number) => i !== index)
    }));
  };

  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.title.trim()) {
      newErrors.title = 'Название обязательно';
    }
    
    if (!formData.slug.trim()) {
      newErrors.slug = 'Slug обязателен';
    } else if (!contentService.isSlugUnique(formData.slug, collection?.id)) {
      newErrors.slug = 'Такой slug уже существует';
    }
    
    if (!formData.description.trim()) {
      newErrors.description = 'Краткое описание обязательно';
    }
    
    if (!formData.detailedDescription.trim()) {
      newErrors.detailedDescription = 'Подробное описание обязательно';
    }
    
    if (!formData.image.trim()) {
      newErrors.image = 'Главное изображение обязательно';
    }
    
    if (formData.startingPrice <= 0) {
      newErrors.startingPrice = 'Стартовая цена должна быть больше 0';
    }
    
    if (!formData.warranty.trim()) {
      newErrors.warranty = 'Информация о гарантии обязательна';
    }
    
    // Проверяем, что есть хотя бы один заполненный элемент в массивах
    const filledFeatures = formData.features.filter(f => f.trim());
    if (filledFeatures.length === 0) {
      newErrors.features = 'Добавьте хотя бы одну особенность';
    }
    
    const filledMaterials = formData.materials.filter(m => m.trim());
    if (filledMaterials.length === 0) {
      newErrors.materials = 'Добавьте хотя бы один материал';
    }
    
    const filledColors = formData.colors.filter(c => c.trim());
    if (filledColors.length === 0) {
      newErrors.colors = 'Добавьте хотя бы один цвет';
    }
    
    const filledSizes = formData.sizes.filter(s => s.trim());
    if (filledSizes.length === 0) {
      newErrors.sizes = 'Добавьте хотя бы один размер';
    }
    
    const filledGallery = formData.gallery.filter(g => g.trim());
    if (filledGallery.length === 0) {
      newErrors.gallery = 'Добавьте хотя бы одно изображение в галерею';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;
    
    setIsSubmitting(true);
    
    try {
      const collectionData = {
        ...(collection && { id: collection.id }),
        title: formData.title.trim(),
        description: formData.description.trim(),
        detailedDescription: formData.detailedDescription.trim(),
        price: formData.price.trim(),
        startingPrice: formData.startingPrice,
        image: formData.image.trim(),
        slug: formData.slug.trim(),
        features: formData.features.filter(f => f.trim()),
        specifications: {
          materials: formData.materials.filter(m => m.trim()),
          colors: formData.colors.filter(c => c.trim()),
          sizes: formData.sizes.filter(s => s.trim()),
          warranty: formData.warranty.trim()
        },
        gallery: formData.gallery.filter(g => g.trim())
      };
      
      contentService.saveCollection(collectionData);
      onSave();
    } catch (error) {
      setErrors({ submit: `Ошибка сохранения: ${error}` });
    } finally {
      setIsSubmitting(false);
    }
  };

  const renderArrayField = (
    label: string,
    field: string,
    placeholder: string,
    error?: string
  ) => (
    <FormField label={label} error={error} required>
      <div className="space-y-3">
        {formData[field as keyof typeof formData].map((item: string, index: number) => (
          <div key={index} className="flex space-x-2">
            <input
              type="text"
              value={item}
              onChange={(e) => handleArrayChange(field, index, e.target.value)}
              className="flex-1 p-3 bg-dark-800 border border-gray-600 text-white focus:outline-none focus:border-gold-400 rounded-lg"
              placeholder={placeholder}
            />
            {formData[field as keyof typeof formData].length > 1 && (
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => removeArrayItem(field, index)}
                className="border-red-500 text-red-400 hover:bg-red-500 hover:text-white"
              >
                <Trash2 size={16} />
              </Button>
            )}
          </div>
        ))}
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={() => addArrayItem(field)}
          className="flex items-center space-x-2"
        >
          <Plus size={16} />
          <span>Добавить</span>
        </Button>
      </div>
    </FormField>
  );

  return (
    <div className="bg-dark-900/50 backdrop-blur-sm border border-gold-400/10 p-8 rounded-xl">
      <form onSubmit={handleSubmit} className="space-y-8">
        {/* Основная информация */}
        <div className="space-y-6">
          <h3 className="text-lg font-medium text-white border-b border-gray-700 pb-2">
            Основная информация
          </h3>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <FormField label="Название коллекции" error={errors.title} required>
              <input
                type="text"
                value={formData.title}
                onChange={(e) => handleInputChange('title', e.target.value)}
                className="w-full p-3 bg-dark-800 border border-gray-600 text-white focus:outline-none focus:border-gold-400 rounded-lg"
                placeholder="URBAN"
              />
            </FormField>

            <FormField label="Slug (URL)" error={errors.slug} required>
              <input
                type="text"
                value={formData.slug}
                onChange={(e) => handleInputChange('slug', e.target.value)}
                className="w-full p-3 bg-dark-800 border border-gray-600 text-white focus:outline-none focus:border-gold-400 rounded-lg"
                placeholder="urban-collection"
              />
            </FormField>
          </div>

          <FormField label="Краткое описание" error={errors.description} required>
            <input
              type="text"
              value={formData.description}
              onChange={(e) => handleInputChange('description', e.target.value)}
              className="w-full p-3 bg-dark-800 border border-gray-600 text-white focus:outline-none focus:border-gold-400 rounded-lg"
              placeholder="Современный минимализм с элементами роскоши"
            />
          </FormField>

          <FormField label="Подробное описание" error={errors.detailedDescription} required>
            <textarea
              value={formData.detailedDescription}
              onChange={(e) => handleInputChange('detailedDescription', e.target.value)}
              className="w-full p-3 bg-dark-800 border border-gray-600 text-white focus:outline-none focus:border-gold-400 rounded-lg"
              rows={4}
              placeholder="Подробное описание коллекции..."
            />
          </FormField>
        </div>

        {/* Цена и изображения */}
        <div className="space-y-6">
          <h3 className="text-lg font-medium text-white border-b border-gray-700 pb-2">
            Цена и изображения
          </h3>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <FormField label="Стартовая цена (₽)" error={errors.startingPrice} required>
              <input
                type="number"
                min="0"
                step="1000"
                value={formData.startingPrice}
                onChange={(e) => handleInputChange('startingPrice', parseInt(e.target.value) || 0)}
                className="w-full p-3 bg-dark-800 border border-gray-600 text-white focus:outline-none focus:border-gold-400 rounded-lg"
                placeholder="249000"
              />
            </FormField>

            <FormField label="Отображаемая цена" error={errors.price}>
              <input
                type="text"
                value={formData.price}
                onChange={(e) => handleInputChange('price', e.target.value)}
                className="w-full p-3 bg-dark-800 border border-gray-600 text-white focus:outline-none focus:border-gold-400 rounded-lg"
                placeholder="от 249 000 ₽"
              />
            </FormField>

            <FormField label="Главное изображение" error={errors.image} required>
              <input
                type="url"
                value={formData.image}
                onChange={(e) => handleInputChange('image', e.target.value)}
                className="w-full p-3 bg-dark-800 border border-gray-600 text-white focus:outline-none focus:border-gold-400 rounded-lg"
                placeholder="https://example.com/image.jpg"
              />
            </FormField>
          </div>
        </div>

        {/* Особенности */}
        <div className="space-y-6">
          <h3 className="text-lg font-medium text-white border-b border-gray-700 pb-2">
            Особенности и характеристики
          </h3>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="space-y-6">
              {renderArrayField(
                'Особенности коллекции',
                'features',
                'Фасады из натурального шпона дуба',
                errors.features
              )}
              
              {renderArrayField(
                'Материалы',
                'materials',
                'Натуральный шпон дуба',
                errors.materials
              )}
            </div>
            
            <div className="space-y-6">
              {renderArrayField(
                'Цветовые решения',
                'colors',
                'Дуб натуральный',
                errors.colors
              )}
              
              {renderArrayField(
                'Размеры',
                'sizes',
                'Линейная от 2.4м',
                errors.sizes
              )}
            </div>
          </div>

          <FormField label="Гарантия" error={errors.warranty} required>
            <input
              type="text"
              value={formData.warranty}
              onChange={(e) => handleInputChange('warranty', e.target.value)}
              className="w-full p-3 bg-dark-800 border border-gray-600 text-white focus:outline-none focus:border-gold-400 rounded-lg"
              placeholder="14 месяцев полная гарантия"
            />
          </FormField>
        </div>

        {/* Галерея */}
        <div className="space-y-6">
          <h3 className="text-lg font-medium text-white border-b border-gray-700 pb-2">
            Галерея изображений
          </h3>
          
          {renderArrayField(
            'Изображения галереи',
            'gallery',
            'https://example.com/gallery-image.jpg',
            errors.gallery
          )}
        </div>

        {errors.submit && (
          <div className="p-4 bg-red-900/20 border border-red-500/30 text-red-300 rounded-lg">
            {errors.submit}
          </div>
        )}

        <div className="flex justify-end space-x-4 pt-6 border-t border-gray-700">
          <Button
            type="button"
            variant="outline"
            onClick={onCancel}
            disabled={isSubmitting}
          >
            Отмена
          </Button>
          <Button
            type="submit"
            variant="primary"
            disabled={isSubmitting}
            className="flex items-center space-x-2"
          >
            <Save size={16} />
            <span>{isSubmitting ? 'Сохранение...' : 'Сохранить'}</span>
          </Button>
        </div>
      </form>
    </div>
  );
};