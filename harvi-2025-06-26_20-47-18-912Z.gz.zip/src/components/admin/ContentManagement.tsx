import React, { useState } from 'react';
import { Plus, BookOpen, Camera, Package, Edit, Trash2, Eye } from 'lucide-react';
import { AnimatedSection } from '../ui/AnimatedSection';
import { Button } from '../ui/Button';
import { BlogPostEditor } from './BlogPostEditor';
import { WorkPhotoEditor } from './WorkPhotoEditor';
import { CollectionEditor } from './CollectionEditor';
import { contentService } from '../../services/contentService';
import type { BlogPost, WorkPhoto, Collection } from '../../types';

type ContentType = 'posts' | 'photos' | 'collections';
type EditorMode = 'create' | 'edit' | null;

export const ContentManagement: React.FC = () => {
  const [activeTab, setActiveTab] = useState<ContentType>('posts');
  const [editorMode, setEditorMode] = useState<EditorMode>(null);
  const [editingItem, setEditingItem] = useState<BlogPost | WorkPhoto | Collection | null>(null);

  const [blogPosts, setBlogPosts] = useState<BlogPost[]>(() => contentService.getBlogPosts());
  const [workPhotos, setWorkPhotos] = useState<WorkPhoto[]>(() => contentService.getWorkPhotos());
  const [collections, setCollections] = useState<Collection[]>(() => contentService.getCollections());

  const handleCreate = () => {
    setEditingItem(null);
    setEditorMode('create');
  };

  const handleEdit = (item: BlogPost | WorkPhoto | Collection) => {
    setEditingItem(item);
    setEditorMode('edit');
  };

  const handleDelete = async (id: string, type: ContentType) => {
    if (!confirm('Вы уверены, что хотите удалить этот элемент?')) return;

    try {
      switch (type) {
        case 'posts':
          contentService.deleteBlogPost(id);
          setBlogPosts(contentService.getBlogPosts());
          break;
        case 'photos':
          contentService.deleteWorkPhoto(id);
          setWorkPhotos(contentService.getWorkPhotos());
          break;
        case 'collections':
          contentService.deleteCollection(id);
          setCollections(contentService.getCollections());
          break;
      }
    } catch (error) {
      alert(`Ошибка удаления: ${error}`);
    }
  };

  const handleSave = () => {
    // Обновляем данные после сохранения
    setBlogPosts(contentService.getBlogPosts());
    setWorkPhotos(contentService.getWorkPhotos());
    setCollections(contentService.getCollections());
    setEditorMode(null);
    setEditingItem(null);
  };

  const handleCancel = () => {
    setEditorMode(null);
    setEditingItem(null);
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('ru-RU', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const tabs = [
    { key: 'posts', label: 'Статьи блога', icon: <BookOpen size={16} />, count: blogPosts.length },
    { key: 'photos', label: 'Фото работ', icon: <Camera size={16} />, count: workPhotos.length },
    { key: 'collections', label: 'Коллекции', icon: <Package size={16} />, count: collections.length }
  ];

  if (editorMode) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h2 className="font-manrope text-2xl font-medium text-white">
            {editorMode === 'create' ? 'Создание' : 'Редактирование'} {
              activeTab === 'posts' ? 'статьи' :
              activeTab === 'photos' ? 'фотографии' : 'коллекции'
            }
          </h2>
          <Button variant="outline" onClick={handleCancel}>
            Отмена
          </Button>
        </div>

        {activeTab === 'posts' && (
          <BlogPostEditor
            post={editingItem as BlogPost}
            onSave={handleSave}
            onCancel={handleCancel}
          />
        )}

        {activeTab === 'photos' && (
          <WorkPhotoEditor
            photo={editingItem as WorkPhoto}
            onSave={handleSave}
            onCancel={handleCancel}
          />
        )}

        {activeTab === 'collections' && (
          <CollectionEditor
            collection={editingItem as Collection}
            onSave={handleSave}
            onCancel={handleCancel}
          />
        )}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <AnimatedSection>
        <div className="flex items-center justify-between">
          <h2 className="font-manrope text-2xl font-medium text-white">
            Управление контентом
          </h2>
          <Button
            variant="primary"
            onClick={handleCreate}
            className="flex items-center space-x-2"
          >
            <Plus size={16} />
            <span>Создать {
              activeTab === 'posts' ? 'статью' :
              activeTab === 'photos' ? 'фото' : 'коллекцию'
            }</span>
          </Button>
        </div>
      </AnimatedSection>

      {/* Tabs */}
      <AnimatedSection>
        <div className="flex space-x-1 bg-dark-800 p-1 rounded-lg">
          {tabs.map(tab => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key as ContentType)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-md transition-all duration-200 ${
                activeTab === tab.key
                  ? 'bg-gold-400 text-black'
                  : 'text-white hover:bg-dark-700'
              }`}
            >
              {tab.icon}
              <span>{tab.label}</span>
              <span className={`px-2 py-1 text-xs rounded-full ${
                activeTab === tab.key
                  ? 'bg-black/20 text-black'
                  : 'bg-dark-600 text-gray-300'
              }`}>
                {tab.count}
              </span>
            </button>
          ))}
        </div>
      </AnimatedSection>

      {/* Content */}
      <AnimatedSection>
        <div className="bg-dark-900/50 backdrop-blur-sm border border-gold-400/10 rounded-xl overflow-hidden">
          {/* Blog Posts */}
          {activeTab === 'posts' && (
            <div className="divide-y divide-gray-700">
              {blogPosts.length === 0 ? (
                <div className="p-8 text-center">
                  <BookOpen size={48} className="text-gray-600 mx-auto mb-4" />
                  <p className="text-gray-400">Нет статей</p>
                </div>
              ) : (
                blogPosts.map(post => (
                  <div key={post.id} className="p-6 hover:bg-dark-800/30 transition-colors duration-200">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3 mb-2">
                          <h3 className="font-medium text-white">{post.title}</h3>
                          <span className={`px-2 py-1 text-xs rounded-full ${
                            post.isPublished 
                              ? 'bg-green-900/20 border border-green-500/30 text-green-300'
                              : 'bg-gray-900/20 border border-gray-500/30 text-gray-300'
                          }`}>
                            {post.isPublished ? 'Опубликовано' : 'Черновик'}
                          </span>
                        </div>
                        <p className="text-gray-400 text-sm mb-2 line-clamp-2">{post.excerpt}</p>
                        <div className="flex items-center space-x-4 text-xs text-gray-500">
                          <span>Категория: {post.category.name}</span>
                          <span>Автор: {post.author}</span>
                          <span>Обновлено: {formatDate(post.updatedAt)}</span>
                          <span>Время чтения: {post.readTime} мин</span>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2 ml-4">
                        {post.isPublished && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => window.open(`/useful/article/${post.slug}`, '_blank')}
                            className="flex items-center space-x-1"
                          >
                            <Eye size={14} />
                            <span>Просмотр</span>
                          </Button>
                        )}
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleEdit(post)}
                          className="flex items-center space-x-1"
                        >
                          <Edit size={14} />
                          <span>Изменить</span>
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDelete(post.id, 'posts')}
                          className="flex items-center space-x-1 border-red-500 text-red-400 hover:bg-red-500 hover:text-white"
                        >
                          <Trash2 size={14} />
                          <span>Удалить</span>
                        </Button>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          {/* Work Photos */}
          {activeTab === 'photos' && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-6">
              {workPhotos.length === 0 ? (
                <div className="col-span-full text-center py-8">
                  <Camera size={48} className="text-gray-600 mx-auto mb-4" />
                  <p className="text-gray-400">Нет фотографий</p>
                </div>
              ) : (
                workPhotos.map(photo => (
                  <div key={photo.id} className="bg-dark-800/50 rounded-lg overflow-hidden group">
                    <div className="aspect-square overflow-hidden">
                      <img
                        src={photo.imageUrl}
                        alt={photo.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                    <div className="p-4">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="font-medium text-white text-sm line-clamp-1">{photo.title}</h3>
                        <span className={`px-2 py-1 text-xs rounded-full ${
                          photo.isPublished 
                            ? 'bg-green-900/20 border border-green-500/30 text-green-300'
                            : 'bg-gray-900/20 border border-gray-500/30 text-gray-300'
                        }`}>
                          {photo.isPublished ? 'Опубликовано' : 'Скрыто'}
                        </span>
                      </div>
                      <p className="text-gray-400 text-xs mb-3 line-clamp-2">{photo.description}</p>
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-gray-500 capitalize">{photo.category}</span>
                        <div className="flex space-x-1">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleEdit(photo)}
                            className="p-1"
                          >
                            <Edit size={12} />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleDelete(photo.id, 'photos')}
                            className="p-1 border-red-500 text-red-400 hover:bg-red-500 hover:text-white"
                          >
                            <Trash2 size={12} />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          {/* Collections */}
          {activeTab === 'collections' && (
            <div className="divide-y divide-gray-700">
              {collections.length === 0 ? (
                <div className="p-8 text-center">
                  <Package size={48} className="text-gray-600 mx-auto mb-4" />
                  <p className="text-gray-400">Нет коллекций</p>
                </div>
              ) : (
                collections.map(collection => (
                  <div key={collection.id} className="p-6 hover:bg-dark-800/30 transition-colors duration-200">
                    <div className="flex items-start justify-between">
                      <div className="flex space-x-4">
                        <div className="w-20 h-20 rounded-lg overflow-hidden flex-shrink-0">
                          <img
                            src={collection.image}
                            alt={collection.title}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div className="flex-1">
                          <h3 className="font-medium text-white mb-1">{collection.title}</h3>
                          <p className="text-gray-400 text-sm mb-2 line-clamp-2">{collection.description}</p>
                          <div className="flex items-center space-x-4 text-xs text-gray-500">
                            <span>Цена: {collection.price}</span>
                            <span>Slug: {collection.slug}</span>
                            <span>Материалов: {collection.specifications.materials.length}</span>
                            <span>Фото: {collection.gallery.length}</span>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2 ml-4">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => window.open(`/collection/${collection.slug}`, '_blank')}
                          className="flex items-center space-x-1"
                        >
                          <Eye size={14} />
                          <span>Просмотр</span>
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleEdit(collection)}
                          className="flex items-center space-x-1"
                        >
                          <Edit size={14} />
                          <span>Изменить</span>
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDelete(collection.id, 'collections')}
                          className="flex items-center space-x-1 border-red-500 text-red-400 hover:bg-red-500 hover:text-white"
                        >
                          <Trash2 size={14} />
                          <span>Удалить</span>
                        </Button>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}
        </div>
      </AnimatedSection>
    </div>
  );
};