import React, { useState } from 'react';
import { X, Save, Plus, MessageSquare, Calendar, CheckSquare, Clock, AlertTriangle } from 'lucide-react';
import { Button } from '../ui/Button';
import { LoadingSpinner } from '../ui/LoadingSpinner';
import { OrderProgressMap } from '../order/OrderProgressMap';
import { StageScheduleEditor } from './StageScheduleEditor';
import { StageChecklistEditor } from './StageChecklistEditor';
import { collections } from '../../data/collections';
import { adminService } from '../../services/adminService';
import type { Order } from '../../types/order';
import type { OrderUpdate } from '../../types/admin';

interface OrderDetailsModalProps {
  order: Order;
  isOpen: boolean;
  onClose: () => void;
  onOrderUpdate: (updatedOrder: Order) => void;
}

export const OrderDetailsModal: React.FC<OrderDetailsModalProps> = ({
  order,
  isOpen,
  onClose,
  onOrderUpdate
}) => {
  const [isUpdating, setIsUpdating] = useState(false);
  const [newNote, setNewNote] = useState('');
  const [selectedStage, setSelectedStage] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'overview' | 'schedule' | 'checklist'>('overview');

  if (!isOpen) return null;

  const collection = collections.find(c => c.id === order.collectionId);
  const selectedStageData = selectedStage ? order.stages.find(s => s.id === selectedStage) : null;

  const handleStageUpdate = async (update: Omit<OrderUpdate, 'orderId'>) => {
    setIsUpdating(true);
    
    try {
      const updatedOrder = await adminService.updateOrder({
        ...update,
        orderId: order.id
      });
      
      if (updatedOrder) {
        onOrderUpdate(updatedOrder);
      }
    } catch (error) {
      console.error('Ошибка обновления заказа:', error);
    } finally {
      setIsUpdating(false);
    }
  };

  const handleMarkComplete = (stageId: string) => {
    handleStageUpdate({
      stageId,
      action: 'mark_complete'
    });
  };

  const handleUnmarkComplete = (stageId: string) => {
    handleStageUpdate({
      stageId,
      action: 'unmark_complete'
    });
  };

  const handleAddNote = async () => {
    if (!newNote.trim()) return;
    
    await handleStageUpdate({
      stageId: order.stages[0].id,
      action: 'update_progress',
      note: newNote.trim()
    });
    
    setNewNote('');
  };

  const handleScheduleUpdate = (schedule: any) => {
    if (!selectedStage) return;
    
    handleStageUpdate({
      stageId: selectedStage,
      action: 'update_schedule',
      schedule
    });
  };

  // Новый обработчик для каскадного обновления
  const handleCascadeUpdate = async (updates: { stageId: string; schedule: any }[]) => {
    setIsUpdating(true);
    
    try {
      // Обновляем все этапы последовательно
      for (const update of updates) {
        await adminService.updateOrder({
          orderId: order.id,
          stageId: update.stageId,
          action: 'update_schedule',
          schedule: update.schedule
        });
      }
      
      // Получаем обновленный заказ
      const updatedOrder = await adminService.getOrderById(order.id);
      if (updatedOrder) {
        onOrderUpdate(updatedOrder);
      }
    } catch (error) {
      console.error('Ошибка каскадного обновления:', error);
    } finally {
      setIsUpdating(false);
    }
  };

  const handleChecklistUpdate = (itemId: string, isCompleted: boolean) => {
    if (!selectedStage) return;
    
    handleStageUpdate({
      stageId: selectedStage,
      action: 'update_checklist',
      checklistUpdate: { itemId, isCompleted }
    });
  };

  const handleAddChecklistItem = (newItem: any) => {
    if (!selectedStage) return;
    
    handleStageUpdate({
      stageId: selectedStage,
      action: 'update_checklist',
      newChecklistItem: newItem
    });
  };

  const getOverdueStagesCount = () => {
    return order.stages.filter(stage => stage.schedule?.isOverdue).length;
  };

  const getIncompleteRequiredTasks = () => {
    return order.stages.reduce((total, stage) => {
      return total + stage.checklist.filter(item => item.isRequired && !item.isCompleted).length;
    }, 0);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-dark-900 border border-gold-400/20 max-w-7xl w-full max-h-[95vh] overflow-y-auto rounded-xl">
        {/* Header */}
        <div className="sticky top-0 bg-dark-900 border-b border-gold-400/20 p-6 flex items-center justify-between rounded-t-xl">
          <div className="flex items-center space-x-4">
            <div>
              <h2 className="font-manrope text-xl font-medium text-white">
                Заказ {order.orderNumber}
              </h2>
              <p className="text-gray-400">
                {collection?.title} • {order.customerName}
              </p>
            </div>
            
            {/* Индикаторы статуса */}
            <div className="flex items-center space-x-4">
              {order.isOverdue && (
                <div className="flex items-center space-x-1 px-3 py-1 bg-red-900/20 border border-red-500/30 rounded-full">
                  <AlertTriangle size={16} className="text-red-400" />
                  <span className="text-red-300 text-sm">Просрочен</span>
                </div>
              )}
              
              {getOverdueStagesCount() > 0 && (
                <div className="flex items-center space-x-1 px-3 py-1 bg-orange-900/20 border border-orange-500/30 rounded-full">
                  <Clock size={16} className="text-orange-400" />
                  <span className="text-orange-300 text-sm">{getOverdueStagesCount()} этапов просрочено</span>
                </div>
              )}
              
              {getIncompleteRequiredTasks() > 0 && (
                <div className="flex items-center space-x-1 px-3 py-1 bg-yellow-900/20 border border-yellow-500/30 rounded-full">
                  <CheckSquare size={16} className="text-yellow-400" />
                  <span className="text-yellow-300 text-sm">{getIncompleteRequiredTasks()} задач требуют внимания</span>
                </div>
              )}
            </div>
          </div>
          
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white transition-colors duration-300 p-2 hover:bg-dark-800 rounded-full"
          >
            <X size={24} />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-8">
          {/* Order Info */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-dark-800/50 p-4 border border-gray-700 rounded-xl">
              <h3 className="font-medium text-white mb-3">Информация о клиенте</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-400">Имя:</span>
                  <span className="text-white">{order.customerName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Телефон:</span>
                  <span className="text-white">{order.customerPhone}</span>
                </div>
                {order.customerEmail && (
                  <div className="flex justify-between">
                    <span className="text-gray-400">Email:</span>
                    <span className="text-white">{order.customerEmail}</span>
                  </div>
                )}
              </div>
            </div>

            <div className="bg-dark-800/50 p-4 border border-gray-700 rounded-xl">
              <h3 className="font-medium text-white mb-3">Информация о заказе</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-400">Дата создания:</span>
                  <span className="text-white">{order.createdDate.toLocaleDateString('ru-RU')}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Плановое завершение:</span>
                  <span className="text-white">{order.estimatedCompletionDate.toLocaleDateString('ru-RU')}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Общий прогресс:</span>
                  <span className="text-gold-400">{Math.round(order.totalProgress)}%</span>
                </div>
              </div>
            </div>

            <div className="bg-dark-800/50 p-4 border border-gray-700 rounded-xl">
              <h3 className="font-medium text-white mb-3">Ближайшие дедлайны</h3>
              <div className="space-y-2 text-sm">
                {order.nextDeadline ? (
                  <>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Следующий дедлайн:</span>
                      <span className="text-white">{order.nextDeadline.toLocaleDateString('ru-RU')}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Дней осталось:</span>
                      <span className={`${Math.ceil((order.nextDeadline.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24)) < 3 ? 'text-red-400' : 'text-white'}`}>
                        {Math.ceil((order.nextDeadline.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))}
                      </span>
                    </div>
                  </>
                ) : (
                  <span className="text-gray-400">Нет активных дедлайнов</span>
                )}
              </div>
            </div>
          </div>

          {/* Progress Map */}
          <div>
            <h3 className="font-manrope text-lg font-medium text-white mb-6">
              Этапы выполнения
            </h3>
            {isUpdating && (
              <div className="flex items-center justify-center py-4 mb-4">
                <LoadingSpinner size="sm" className="text-gold-400 mr-2" />
                <span className="text-gray-400">Обновление...</span>
              </div>
            )}
            <OrderProgressMap
              stages={order.stages}
              onStageClick={setSelectedStage}
              onMarkComplete={handleMarkComplete}
              onUnmarkComplete={handleUnmarkComplete}
              isEditable={!isUpdating}
            />
          </div>

          {/* Stage Details */}
          {selectedStageData && (
            <div className="bg-dark-800/50 p-6 border border-gray-700 rounded-xl">
              <div className="flex items-center justify-between mb-6">
                <h3 className="font-manrope text-lg font-medium text-white">
                  Управление этапом: {selectedStageData.title}
                </h3>
                
                {/* Tabs */}
                <div className="flex space-x-2">
                  <button
                    onClick={() => setActiveTab('overview')}
                    className={`px-4 py-2 text-sm transition-colors duration-300 rounded-lg ${
                      activeTab === 'overview' 
                        ? 'bg-gold-400 text-black' 
                        : 'bg-dark-700 text-white hover:bg-dark-600'
                    }`}
                  >
                    Обзор
                  </button>
                  <button
                    onClick={() => setActiveTab('schedule')}
                    className={`px-4 py-2 text-sm transition-colors duration-300 flex items-center space-x-2 rounded-lg ${
                      activeTab === 'schedule' 
                        ? 'bg-gold-400 text-black' 
                        : 'bg-dark-700 text-white hover:bg-dark-600'
                    }`}
                  >
                    <Calendar size={16} />
                    <span>Расписание</span>
                  </button>
                  <button
                    onClick={() => setActiveTab('checklist')}
                    className={`px-4 py-2 text-sm transition-colors duration-300 flex items-center space-x-2 rounded-lg ${
                      activeTab === 'checklist' 
                        ? 'bg-gold-400 text-black' 
                        : 'bg-dark-700 text-white hover:bg-dark-600'
                    }`}
                  >
                    <CheckSquare size={16} />
                    <span>Чек-лист ({selectedStageData.checklist.filter(i => i.isCompleted).length}/{selectedStageData.checklist.length})</span>
                  </button>
                </div>
              </div>

              {/* Tab Content */}
              {activeTab === 'overview' && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-medium text-white mb-3">Описание этапа</h4>
                    <p className="text-gray-300 mb-4">{selectedStageData.description}</p>
                    
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-400">Статус:</span>
                        <span className={`
                          ${selectedStageData.status === 'completed' ? 'text-green-400' : ''}
                          ${selectedStageData.status === 'current' || selectedStageData.status === 'in-progress' ? 'text-gold-400' : ''}
                          ${selectedStageData.status === 'pending' ? 'text-gray-400' : ''}
                        `}>
                          {selectedStageData.status === 'completed' && 'Завершен'}
                          {(selectedStageData.status === 'current' || selectedStageData.status === 'in-progress') && 'В работе'}
                          {selectedStageData.status === 'pending' && 'Ожидает'}
                        </span>
                      </div>
                      
                      <div className="flex justify-between">
                        <span className="text-gray-400">Прогресс чек-листа:</span>
                        <span className="text-gold-400">{Math.round(selectedStageData.checklistProgress)}%</span>
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="font-medium text-white mb-3">Быстрые действия</h4>
                    <div className="space-y-3">
                      {selectedStageData.canMarkComplete && (
                        <Button
                          variant="primary"
                          size="sm"
                          onClick={() => handleMarkComplete(selectedStageData.id)}
                          disabled={isUpdating}
                          className="w-full"
                        >
                          Отметить этап как выполненный
                        </Button>
                      )}
                      
                      {selectedStageData.canUnmarkComplete && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleUnmarkComplete(selectedStageData.id)}
                          disabled={isUpdating}
                          className="w-full border-red-500 text-red-400 hover:bg-red-500 hover:text-white"
                        >
                          Отменить выполнение этапа
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'schedule' && (
                <StageScheduleEditor
                  stage={selectedStageData}
                  allStages={order.stages}
                  onScheduleUpdate={handleScheduleUpdate}
                  onCascadeUpdate={handleCascadeUpdate}
                  isUpdating={isUpdating}
                />
              )}

              {activeTab === 'checklist' && (
                <StageChecklistEditor
                  stage={selectedStageData}
                  onChecklistUpdate={handleChecklistUpdate}
                  onAddItem={handleAddChecklistItem}
                  isUpdating={isUpdating}
                />
              )}
            </div>
          )}

          {/* Add Note */}
          <div className="bg-dark-800/50 p-6 border border-gray-700 rounded-xl">
            <h3 className="font-medium text-white mb-4 flex items-center">
              <MessageSquare size={20} className="mr-2 text-gold-400" />
              Добавить заметку
            </h3>
            <div className="flex space-x-4">
              <input
                type="text"
                value={newNote}
                onChange={(e) => setNewNote(e.target.value)}
                className="flex-1 p-3 bg-dark-800 border border-gray-600 text-white focus:outline-none focus:border-gold-400 rounded-lg"
                placeholder="Введите заметку к заказу..."
                onKeyPress={(e) => e.key === 'Enter' && handleAddNote()}
              />
              <Button
                variant="primary"
                onClick={handleAddNote}
                disabled={!newNote.trim() || isUpdating}
                className="flex items-center space-x-2"
              >
                <Plus size={16} />
                <span>Добавить</span>
              </Button>
            </div>
          </div>

          {/* Order Notes */}
          {order.notes && order.notes.length > 0 && (
            <div className="bg-dark-800/50 p-6 border border-gray-700 rounded-xl">
              <h3 className="font-medium text-white mb-4">История заказа</h3>
              <div className="space-y-3 max-h-40 overflow-y-auto">
                {order.notes.map((note, index) => (
                  <div key={index} className="flex items-start space-x-3">
                    <div className="w-2 h-2 bg-gold-400 rounded-full mt-2 flex-shrink-0"></div>
                    <p className="text-gray-300 text-sm">{note}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="sticky bottom-0 bg-dark-900 border-t border-gold-400/20 p-6 flex justify-end rounded-b-xl">
          <Button variant="outline" onClick={onClose}>
            Закрыть
          </Button>
        </div>
      </div>
    </div>
  );
};
