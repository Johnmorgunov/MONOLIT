import React, { useState } from 'react';
import { Eye, Phone, Mail, Calendar, Package, Search, Filter, X, User, Layers, Clock, Coins } from 'lucide-react';
import { Button } from '../ui/Button';
import { LoadingSpinner } from '../ui/LoadingSpinner';
import { collections, getPriceSegments, formatPrice } from '../../data/collections';
import type { Order } from '../../types/order';
import type { OrderFilter } from '../../types/admin';

interface OrdersTableProps {
  orders: Order[];
  isLoading: boolean;
  onViewOrder: (order: Order) => void;
  onFilterChange: (filter: OrderFilter) => void;
}

export const OrdersTable: React.FC<OrdersTableProps> = ({
  orders,
  isLoading,
  onViewOrder,
  onFilterChange
}) => {
  const [filter, setFilter] = useState<OrderFilter>({});
  const [showFilters, setShowFilters] = useState(false);

  const handleFilterChange = (newFilter: Partial<OrderFilter>) => {
    const updatedFilter = { ...filter, ...newFilter };
    setFilter(updatedFilter);
    onFilterChange(updatedFilter);
  };

  const clearFilters = () => {
    setFilter({});
    onFilterChange({});
  };

  const getActiveFiltersCount = () => {
    return Object.values(filter).filter(value => 
      value !== undefined && value !== null && value !== '' && value !== 'all'
    ).length;
  };

  const getCollectionName = (collectionId: string) => {
    const collection = collections.find(c => c.id === collectionId);
    return collection?.title || collectionId;
  };

  const getStatusColor = (progress: number) => {
    if (progress === 0) return 'text-gray-400';
    if (progress === 100) return 'text-green-400';
    return 'text-gold-400';
  };

  const getStatusText = (progress: number) => {
    if (progress === 0) return 'Ожидает';
    if (progress === 100) return 'Завершен';
    return 'В работе';
  };

  // Генерируем список месяцев для фильтра
  const getMonthOptions = () => {
    const months = [];
    const now = new Date();
    
    // Добавляем последние 12 месяцев
    for (let i = 0; i < 12; i++) {
      const date = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
      const monthLabel = date.toLocaleDateString('ru-RU', { 
        year: 'numeric', 
        month: 'long' 
      });
      
      months.push({ key: monthKey, label: monthLabel });
    }
    
    return months;
  };

  // Получаем динамические ценовые сегменты
  const priceSegments = getPriceSegments();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <LoadingSpinner size="lg" className="text-gold-400" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Фильтры */}
      <div className="bg-dark-900/50 backdrop-blur-sm border border-gold-400/10 p-6 rounded-xl">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-4">
            <h3 className="font-manrope text-lg font-medium text-white">
              Фильтры поиска
            </h3>
            {getActiveFiltersCount() > 0 && (
              <div className="flex items-center space-x-2">
                <span className="px-2 py-1 bg-gold-400/20 text-gold-400 text-xs rounded-full">
                  {getActiveFiltersCount()} активных
                </span>
                <button
                  onClick={clearFilters}
                  className="text-gray-400 hover:text-white transition-colors duration-200"
                  title="Очистить все фильтры"
                >
                  <X size={16} />
                </button>
              </div>
            )}
          </div>
          
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowFilters(!showFilters)}
            className="flex items-center space-x-2"
          >
            <Filter size={16} />
            <span>{showFilters ? 'Скрыть' : 'Показать'} фильтры</span>
          </Button>
        </div>

        {showFilters && (
          <div className="space-y-6">
            {/* Группа фильтров: Клиент */}
            <div className="border border-gray-700 rounded-lg p-4">
              <div className="flex items-center space-x-2 mb-4">
                <User size={16} className="text-gold-400" />
                <h4 className="font-medium text-white">Клиент</h4>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Номер телефона
                  </label>
                  <div className="relative">
                    <Phone size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                    <input
                      type="text"
                      value={filter.customerPhone || ''}
                      onChange={(e) => handleFilterChange({ customerPhone: e.target.value })}
                      className="w-full pl-10 pr-4 py-2 bg-dark-800 border border-gray-600 text-white focus:outline-none focus:border-gold-400 rounded-lg text-sm"
                      placeholder="+7 (999) 123-45-67"
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Email клиента
                  </label>
                  <div className="relative">
                    <Mail size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                    <input
                      type="email"
                      value={filter.customerEmail || ''}
                      onChange={(e) => handleFilterChange({ customerEmail: e.target.value })}
                      className="w-full pl-10 pr-4 py-2 bg-dark-800 border border-gray-600 text-white focus:outline-none focus:border-gold-400 rounded-lg text-sm"
                      placeholder="client@example.com"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Группа фильтров: Заказ */}
            <div className="border border-gray-700 rounded-lg p-4">
              <div className="flex items-center space-x-2 mb-4">
                <Package size={16} className="text-gold-400" />
                <h4 className="font-medium text-white">Заказ</h4>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Номер заказа
                  </label>
                  <div className="relative">
                    <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                    <input
                      type="text"
                      value={filter.orderNumber || ''}
                      onChange={(e) => handleFilterChange({ orderNumber: e.target.value })}
                      className="w-full pl-10 pr-4 py-2 bg-dark-800 border border-gray-600 text-white focus:outline-none focus:border-gold-400 rounded-lg text-sm"
                      placeholder="MNL-2025-001"
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Статус заказа
                  </label>
                  <select
                    value={filter.status || 'all'}
                    onChange={(e) => handleFilterChange({ status: e.target.value as any })}
                    className="w-full p-2 bg-dark-800 border border-gray-600 text-white focus:outline-none focus:border-gold-400 rounded-lg text-sm"
                  >
                    <option value="all">Все статусы</option>
                    <option value="pending">Ожидают начала</option>
                    <option value="active">В работе</option>
                    <option value="completed">Завершенные</option>
                    <option value="overdue">Просроченные</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Группа фильтров: Коллекция и цена */}
            <div className="border border-gray-700 rounded-lg p-4">
              <div className="flex items-center space-x-2 mb-4">
                <Layers size={16} className="text-gold-400" />
                <h4 className="font-medium text-white">Коллекция и стоимость</h4>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Коллекция кухни
                  </label>
                  <select
                    value={filter.collectionId || 'all'}
                    onChange={(e) => handleFilterChange({ collectionId: e.target.value === 'all' ? undefined : e.target.value })}
                    className="w-full p-2 bg-dark-800 border border-gray-600 text-white focus:outline-none focus:border-gold-400 rounded-lg text-sm"
                  >
                    <option value="all">Все коллекции</option>
                    {collections.map(collection => (
                      <option key={collection.id} value={collection.id}>
                        {collection.title} ({collection.price})
                      </option>
                    ))}
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Ценовой сегмент
                  </label>
                  <select
                    value={filter.priceRange || 'all'}
                    onChange={(e) => handleFilterChange({ priceRange: e.target.value === 'all' ? undefined : e.target.value as any })}
                    className="w-full p-2 bg-dark-800 border border-gray-600 text-white focus:outline-none focus:border-gold-400 rounded-lg text-sm"
                  >
                    <option value="all">Все ценовые сегменты</option>
                    <option value="budget">Бюджетные ({priceSegments.budget.label})</option>
                    <option value="medium">Средние ({priceSegments.medium.label})</option>
                    <option value="premium">Премиум ({priceSegments.premium.label})</option>
                  </select>
                </div>
              </div>

              {/* Точный диапазон цен */}
              <div className="border-t border-gray-700 pt-4">
                <div className="flex items-center space-x-2 mb-3">
                  <Coins size={16} className="text-gold-400" />
                  <span className="text-sm font-medium text-gray-300">Точный диапазон стоимости</span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs text-gray-400 mb-1">
                      Стоимость от (₽)
                    </label>
                    <input
                      type="number"
                      value={filter.priceFrom || ''}
                      onChange={(e) => handleFilterChange({ priceFrom: e.target.value ? parseInt(e.target.value) : undefined })}
                      className="w-full p-2 bg-dark-800 border border-gray-600 text-white focus:outline-none focus:border-gold-400 rounded-lg text-sm"
                      placeholder="249000"
                      min="0"
                      step="1000"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-xs text-gray-400 mb-1">
                      Стоимость до (₽)
                    </label>
                    <input
                      type="number"
                      value={filter.priceTo || ''}
                      onChange={(e) => handleFilterChange({ priceTo: e.target.value ? parseInt(e.target.value) : undefined })}
                      className="w-full p-2 bg-dark-800 border border-gray-600 text-white focus:outline-none focus:border-gold-400 rounded-lg text-sm"
                      placeholder="650000"
                      min="0"
                      step="1000"
                    />
                  </div>
                </div>
                
                {/* Быстрые фильтры по ценам */}
                <div className="mt-3">
                  <p className="text-xs text-gray-400 mb-2">Быстрые фильтры по стоимости:</p>
                  <div className="flex flex-wrap gap-2">
                    {Object.entries(priceSegments).map(([key, segment]) => (
                      <button
                        key={key}
                        onClick={() => {
                          handleFilterChange({
                            priceFrom: segment.min > 0 ? segment.min : undefined,
                            priceTo: segment.max < 1000000 ? segment.max : undefined,
                            priceRange: key as any
                          });
                        }}
                        className="px-3 py-1 bg-dark-700 hover:bg-dark-600 text-white text-xs rounded-full transition-colors duration-200"
                      >
                        {segment.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Группа фильтров: Даты */}
            <div className="border border-gray-700 rounded-lg p-4">
              <div className="flex items-center space-x-2 mb-4">
                <Clock size={16} className="text-gold-400" />
                <h4 className="font-medium text-white">Период создания</h4>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Месяц создания
                  </label>
                  <select
                    value={filter.createdMonth || 'all'}
                    onChange={(e) => handleFilterChange({ createdMonth: e.target.value === 'all' ? undefined : e.target.value })}
                    className="w-full p-2 bg-dark-800 border border-gray-600 text-white focus:outline-none focus:border-gold-400 rounded-lg text-sm"
                  >
                    <option value="all">Все месяцы</option>
                    {getMonthOptions().map(month => (
                      <option key={month.key} value={month.key}>
                        {month.label}
                      </option>
                    ))}
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Дата от
                  </label>
                  <input
                    type="date"
                    value={filter.dateFrom ? filter.dateFrom.toISOString().split('T')[0] : ''}
                    onChange={(e) => handleFilterChange({ 
                      dateFrom: e.target.value ? new Date(e.target.value) : undefined 
                    })}
                    className="w-full p-2 bg-dark-800 border border-gray-600 text-white focus:outline-none focus:border-gold-400 rounded-lg text-sm"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Дата до
                  </label>
                  <input
                    type="date"
                    value={filter.dateTo ? filter.dateTo.toISOString().split('T')[0] : ''}
                    onChange={(e) => handleFilterChange({ 
                      dateTo: e.target.value ? new Date(e.target.value) : undefined 
                    })}
                    className="w-full p-2 bg-dark-800 border border-gray-600 text-white focus:outline-none focus:border-gold-400 rounded-lg text-sm"
                  />
                </div>
              </div>
              
              {/* Быстрые фильтры по периодам */}
              <div className="mt-4 pt-4 border-t border-gray-700">
                <p className="text-sm text-gray-400 mb-2">Быстрые фильтры:</p>
                <div className="flex flex-wrap gap-2">
                  {[
                    { label: 'Сегодня', days: 0 },
                    { label: 'Вчера', days: 1 },
                    { label: 'Неделя', days: 7 },
                    { label: 'Месяц', days: 30 },
                    { label: '3 месяца', days: 90 }
                  ].map(period => (
                    <button
                      key={period.label}
                      onClick={() => {
                        const now = new Date();
                        const fromDate = new Date(now);
                        fromDate.setDate(now.getDate() - period.days);
                        
                        handleFilterChange({
                          dateFrom: period.days === 0 ? now : fromDate,
                          dateTo: now,
                          createdMonth: undefined
                        });
                      }}
                      className="px-3 py-1 bg-dark-700 hover:bg-dark-600 text-white text-xs rounded-full transition-colors duration-200"
                    >
                      {period.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Таблица заказов */}
      <div className="bg-dark-900/50 backdrop-blur-sm border border-gold-400/10 overflow-hidden rounded-xl">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-dark-800/50">
              <tr>
                <th className="px-6 py-4 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                  Заказ
                </th>
                <th className="px-6 py-4 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                  Клиент
                </th>
                <th className="px-6 py-4 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                  Коллекция
                </th>
                <th className="px-6 py-4 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                  Статус
                </th>
                <th className="px-6 py-4 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                  Прогресс
                </th>
                <th className="px-6 py-4 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                  Дата создания
                </th>
                <th className="px-6 py-4 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                  Действия
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-700">
              {orders.map((order) => (
                <tr key={order.id} className="hover:bg-dark-800/30 transition-colors duration-200">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <Package size={16} className="text-gold-400 mr-2" />
                      <div>
                        <div className="text-sm font-medium text-white">
                          {order.orderNumber}
                        </div>
                        <div className="text-xs text-gray-400">
                          ID: {order.id}
                        </div>
                      </div>
                    </div>
                  </td>
                  
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div>
                      <div className="text-sm font-medium text-white">
                        {order.customerName}
                      </div>
                      <div className="text-xs text-gray-400 flex items-center space-x-2">
                        <Phone size={12} />
                        <span>{order.customerPhone}</span>
                      </div>
                      {order.customerEmail && (
                        <div className="text-xs text-gray-400 flex items-center space-x-2">
                          <Mail size={12} />
                          <span>{order.customerEmail}</span>
                        </div>
                      )}
                    </div>
                  </td>
                  
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div>
                      <div className="text-sm text-white font-medium">
                        {getCollectionName(order.collectionId)}
                      </div>
                      <div className="text-xs text-gray-400">
                        {collections.find(c => c.id === order.collectionId)?.price}
                      </div>
                    </div>
                  </td>
                  
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex flex-col space-y-1">
                      <span className={`text-sm font-medium ${getStatusColor(order.totalProgress)}`}>
                        {getStatusText(order.totalProgress)}
                      </span>
                      {order.isOverdue && (
                        <span className="text-xs text-red-400 font-medium">
                          Просрочен
                        </span>
                      )}
                    </div>
                  </td>
                  
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center space-x-2">
                      <div className="w-16 bg-gray-700 h-2 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-gold-400 transition-all duration-300"
                          style={{ width: `${order.totalProgress}%` }}
                        />
                      </div>
                      <span className="text-xs text-gray-400">
                        {Math.round(order.totalProgress)}%
                      </span>
                    </div>
                  </td>
                  
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center text-sm text-gray-400">
                      <Calendar size={12} className="mr-1" />
                      {order.createdDate.toLocaleDateString('ru-RU')}
                    </div>
                  </td>
                  
                  <td className="px-6 py-4 whitespace-nowrap">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => onViewOrder(order)}
                      className="flex items-center space-x-1"
                    >
                      <Eye size={14} />
                      <span>Просмотр</span>
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {orders.length === 0 && (
          <div className="text-center py-12">
            <Package size={48} className="text-gray-600 mx-auto mb-4" />
            <p className="text-gray-400">Заказы не найдены</p>
            {getActiveFiltersCount() > 0 && (
              <Button
                variant="outline"
                size="sm"
                onClick={clearFilters}
                className="mt-4"
              >
                Сбросить фильтры
              </Button>
            )}
          </div>
        )}
      </div>
    </div>
  );
};