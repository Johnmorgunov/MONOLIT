import React, { useState } from 'react';
import { CheckSquare, Plus, Trash2, Clock, User, AlertCircle } from 'lucide-react';
import { Button } from '../ui/Button';
import type { OrderStage, ChecklistItem } from '../../types/order';

interface StageChecklistEditorProps {
  stage: OrderStage;
  onChecklistUpdate: (itemId: string, isCompleted: boolean) => void;
  onAddItem: (newItem: Omit<ChecklistItem, 'id' | 'isCompleted' | 'completedAt' | 'completedBy'>) => void;
  isUpdating: boolean;
}

export const StageChecklistEditor: React.FC<StageChecklistEditorProps> = ({
  stage,
  onChecklistUpdate,
  onAddItem,
  isUpdating
}) => {
  const [newItemForm, setNewItemForm] = useState({
    title: '',
    description: '',
    isRequired: true
  });
  const [showAddForm, setShowAddForm] = useState(false);

  const handleToggleItem = (itemId: string, currentStatus: boolean) => {
    onChecklistUpdate(itemId, !currentStatus);
  };

  const handleAddNewItem = () => {
    if (!newItemForm.title.trim()) return;
    
    onAddItem({
      title: newItemForm.title.trim(),
      description: newItemForm.description.trim() || undefined,
      isRequired: newItemForm.isRequired
    });
    
    setNewItemForm({ title: '', description: '', isRequired: true });
    setShowAddForm(false);
  };

  const getCompletionStats = () => {
    const total = stage.checklist.length;
    const completed = stage.checklist.filter(item => item.isCompleted).length;
    const requiredTotal = stage.checklist.filter(item => item.isRequired).length;
    const requiredCompleted = stage.checklist.filter(item => item.isRequired && item.isCompleted).length;
    
    return { total, completed, requiredTotal, requiredCompleted };
  };

  const stats = getCompletionStats();
  const canProceedToNextStage = stats.requiredCompleted === stats.requiredTotal;

  return (
    <div className="space-y-6">
      {/* Статистика выполнения */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-dark-700/50 p-4 border border-gray-600 rounded">
          <div className="flex items-center justify-between">
            <span className="text-gray-400 text-sm">Общий прогресс</span>
            <span className="text-gold-400 font-medium">{stats.completed}/{stats.total}</span>
          </div>
          <div className="w-full bg-gray-700 h-2 rounded-full mt-2">
            <div
              className="h-full bg-gold-400 rounded-full transition-all duration-300"
              style={{ width: `${(stats.completed / stats.total) * 100}%` }}
            />
          </div>
        </div>
        
        <div className="bg-dark-700/50 p-4 border border-gray-600 rounded">
          <div className="flex items-center justify-between">
            <span className="text-gray-400 text-sm">Обязательные задачи</span>
            <span className={`font-medium ${canProceedToNextStage ? 'text-green-400' : 'text-red-400'}`}>
              {stats.requiredCompleted}/{stats.requiredTotal}
            </span>
          </div>
          <div className="w-full bg-gray-700 h-2 rounded-full mt-2">
            <div
              className={`h-full rounded-full transition-all duration-300 ${canProceedToNextStage ? 'bg-green-400' : 'bg-red-400'}`}
              style={{ width: `${(stats.requiredCompleted / stats.requiredTotal) * 100}%` }}
            />
          </div>
        </div>
        
        <div className="bg-dark-700/50 p-4 border border-gray-600 rounded">
          <div className="flex items-center space-x-2">
            {canProceedToNextStage ? (
              <>
                <CheckSquare size={16} className="text-green-400" />
                <span className="text-green-400 text-sm">Готов к следующему этапу</span>
              </>
            ) : (
              <>
                <AlertCircle size={16} className="text-red-400" />
                <span className="text-red-400 text-sm">Требует завершения</span>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Список задач */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h4 className="font-medium text-white">Список задач</h4>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowAddForm(!showAddForm)}
            className="flex items-center space-x-2"
          >
            <Plus size={16} />
            <span>Добавить задачу</span>
          </Button>
        </div>

        {/* Форма добавления новой задачи */}
        {showAddForm && (
          <div className="bg-dark-700/50 p-4 border border-gray-600 rounded space-y-4">
            <div>
              <label className="block text-sm font-medium text-white mb-2">
                Название задачи *
              </label>
              <input
                type="text"
                value={newItemForm.title}
                onChange={(e) => setNewItemForm(prev => ({ ...prev, title: e.target.value }))}
                className="w-full p-3 bg-dark-800 border border-gray-600 text-white focus:outline-none focus:border-gold-400"
                placeholder="Введите название задачи..."
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-white mb-2">
                Описание (опционально)
              </label>
              <textarea
                value={newItemForm.description}
                onChange={(e) => setNewItemForm(prev => ({ ...prev, description: e.target.value }))}
                className="w-full p-3 bg-dark-800 border border-gray-600 text-white focus:outline-none focus:border-gold-400"
                placeholder="Дополнительное описание задачи..."
                rows={2}
              />
            </div>
            
            <div className="flex items-center space-x-3">
              <label className="flex items-center space-x-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={newItemForm.isRequired}
                  onChange={(e) => setNewItemForm(prev => ({ ...prev, isRequired: e.target.checked }))}
                  className="w-4 h-4 text-gold-400 bg-dark-800 border-gray-600 rounded focus:ring-gold-400"
                />
                <span className="text-white text-sm">Обязательная задача</span>
              </label>
            </div>
            
            <div className="flex space-x-3">
              <Button
                variant="primary"
                size="sm"
                onClick={handleAddNewItem}
                disabled={!newItemForm.title.trim() || isUpdating}
              >
                Добавить
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowAddForm(false)}
              >
                Отмена
              </Button>
            </div>
          </div>
        )}

        {/* Список существующих задач */}
        <div className="space-y-2">
          {stage.checklist.map((item) => (
            <div
              key={item.id}
              className={`p-4 border transition-all duration-300 ${
                item.isCompleted 
                  ? 'bg-green-900/20 border-green-500/30' 
                  : item.isRequired 
                    ? 'bg-dark-800/50 border-gray-600' 
                    : 'bg-dark-800/30 border-gray-700'
              }`}
            >
              <div className="flex items-start space-x-3">
                <button
                  onClick={() => handleToggleItem(item.id, item.isCompleted)}
                  disabled={isUpdating}
                  className={`mt-1 w-5 h-5 border-2 rounded transition-all duration-300 flex items-center justify-center ${
                    item.isCompleted
                      ? 'bg-green-400 border-green-400'
                      : 'border-gray-400 hover:border-gold-400'
                  }`}
                >
                  {item.isCompleted && (
                    <CheckSquare size={12} className="text-black" />
                  )}
                </button>
                
                <div className="flex-1">
                  <div className="flex items-center space-x-2 mb-1">
                    <h5 className={`font-medium ${item.isCompleted ? 'text-green-300 line-through' : 'text-white'}`}>
                      {item.title}
                    </h5>
                    {item.isRequired && (
                      <span className="px-2 py-1 bg-red-900/20 border border-red-500/30 text-red-300 text-xs rounded">
                        Обязательно
                      </span>
                    )}
                  </div>
                  
                  {item.description && (
                    <p className={`text-sm mb-2 ${item.isCompleted ? 'text-gray-400' : 'text-gray-300'}`}>
                      {item.description}
                    </p>
                  )}
                  
                  {item.isCompleted && item.completedAt && (
                    <div className="flex items-center space-x-4 text-xs text-gray-400">
                      <div className="flex items-center space-x-1">
                        <Clock size={12} />
                        <span>Выполнено: {item.completedAt.toLocaleDateString('ru-RU')} в {item.completedAt.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })}</span>
                      </div>
                      {item.completedBy && (
                        <div className="flex items-center space-x-1">
                          <User size={12} />
                          <span>Исполнитель: {item.completedBy}</span>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
          
          {stage.checklist.length === 0 && (
            <div className="text-center py-8 text-gray-400">
              <CheckSquare size={48} className="mx-auto mb-4 opacity-50" />
              <p>Нет задач для этого этапа</p>
              <p className="text-sm">Добавьте первую задачу, чтобы начать планирование</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
