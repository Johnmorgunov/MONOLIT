import React, { useState, useEffect } from 'react';
import { Calendar, Clock, Save, AlertTriangle, Calculator } from 'lucide-react';
import { Button } from '../ui/Button';
import { DatePicker } from '../ui/DatePicker';
import { addWorkingDays, getWorkingDaysBetween, formatWorkingDaysText } from '../../utils/workingDays';
import type { OrderStage, StageSchedule } from '../../types/order';

interface StageScheduleEditorProps {
  stage: OrderStage;
  allStages: OrderStage[];
  onScheduleUpdate: (schedule: Partial<StageSchedule>) => void;
  onCascadeUpdate?: (updates: { stageId: string; schedule: Partial<StageSchedule> }[]) => void;
  isUpdating: boolean;
}

export const StageScheduleEditor: React.FC<StageScheduleEditorProps> = ({
  stage,
  allStages,
  onScheduleUpdate,
  onCascadeUpdate,
  isUpdating
}) => {
  const [schedule, setSchedule] = useState<Partial<StageSchedule>>({
    plannedStartDate: stage.schedule?.plannedStartDate,
    plannedEndDate: stage.schedule?.plannedEndDate,
    actualStartDate: stage.schedule?.actualStartDate,
    actualEndDate: stage.schedule?.actualEndDate
  });

  const [hasChanges, setHasChanges] = useState(false);
  const [autoCalculateEnd, setAutoCalculateEnd] = useState(true);

  // Определяем, является ли этап "замером"
  const isMeasurementStage = stage.id === 'measurement';
  
  // Находим этап замера для расчетов
  const measurementStage = allStages.find(s => s.id === 'measurement');
  const currentStageIndex = allStages.findIndex(s => s.id === stage.id);

  useEffect(() => {
    const originalSchedule = stage.schedule || {};
    const hasChanged = 
      schedule.plannedStartDate?.getTime() !== originalSchedule.plannedStartDate?.getTime() ||
      schedule.plannedEndDate?.getTime() !== originalSchedule.plannedEndDate?.getTime() ||
      schedule.actualStartDate?.getTime() !== originalSchedule.actualStartDate?.getTime() ||
      schedule.actualEndDate?.getTime() !== originalSchedule.actualEndDate?.getTime();
    
    setHasChanges(hasChanged);
  }, [schedule, stage.schedule]);

  // Автоматический расчет планируемого завершения
  useEffect(() => {
    if (autoCalculateEnd && schedule.plannedStartDate && stage.estimatedDuration > 0) {
      const calculatedEndDate = addWorkingDays(schedule.plannedStartDate, stage.estimatedDuration);
      
      if (!schedule.plannedEndDate || schedule.plannedEndDate.getTime() !== calculatedEndDate.getTime()) {
        setSchedule(prev => ({
          ...prev,
          plannedEndDate: calculatedEndDate
        }));
      }
    }
  }, [schedule.plannedStartDate, stage.estimatedDuration, autoCalculateEnd]);

  const handleDateChange = (field: keyof StageSchedule, value: Date) => {
    setSchedule(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const calculateStageStartDate = (): Date | undefined => {
    if (isMeasurementStage) {
      // Для замера возвращаем текущую дату или уже установленную
      return schedule.plannedStartDate || new Date();
    }

    if (!measurementStage?.schedule?.plannedStartDate) {
      return undefined;
    }

    // Рассчитываем от этапа замера
    let workingDaysOffset = 0;
    
    // Суммируем длительность всех этапов до текущего (исключая свободные)
    for (let i = 0; i < currentStageIndex; i++) {
      const prevStage = allStages[i];
      if (!prevStage.isFlexibleTiming && prevStage.estimatedDuration > 0) {
        workingDaysOffset += prevStage.estimatedDuration;
      }
    }

    return addWorkingDays(measurementStage.schedule.plannedStartDate, workingDaysOffset);
  };

  const handleAutoCalculateStart = () => {
    const calculatedStart = calculateStageStartDate();
    if (calculatedStart) {
      handleDateChange('plannedStartDate', calculatedStart);
    }
  };

  const handleSave = () => {
    const updatedSchedule = { ...schedule };
    
    // Если это замер и изменилась дата начала, пересчитываем все последующие этапы
    if (isMeasurementStage && onCascadeUpdate && schedule.plannedStartDate) {
      const cascadeUpdates: { stageId: string; schedule: Partial<StageSchedule> }[] = [];
      let currentDate = schedule.plannedStartDate;
      
      allStages.forEach((stageItem, index) => {
        if (index === 0) return; // Пропускаем сам замер
        
        if (!stageItem.isFlexibleTiming && stageItem.estimatedDuration > 0) {
          const stageStart = new Date(currentDate);
          const stageEnd = addWorkingDays(stageStart, stageItem.estimatedDuration);
          
          cascadeUpdates.push({
            stageId: stageItem.id,
            schedule: {
              plannedStartDate: stageStart,
              plannedEndDate: stageEnd
            }
          });
          
          currentDate = stageEnd;
        }
      });
      
      onCascadeUpdate(cascadeUpdates);
    }
    
    onScheduleUpdate(updatedSchedule);
  };

  const getDaysUntilDeadline = () => {
    if (!schedule.plannedEndDate) return null;
    const now = new Date();
    const days = Math.ceil((schedule.plannedEndDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    return days;
  };

  const isOverdue = () => {
    if (!schedule.plannedEndDate) return false;
    return new Date() > schedule.plannedEndDate;
  };

  const getMinDate = () => {
    if (isMeasurementStage) {
      return new Date(); // Замер можно планировать от сегодня
    }
    return measurementStage?.schedule?.plannedStartDate || new Date();
  };

  return (
    <div className="space-y-8">
      {/* Статус и предупреждения */}
      <div className="flex items-center justify-between">
        <h4 className="font-medium text-white">Календарное планирование</h4>
        
        <div className="flex items-center space-x-4">
          {isOverdue() && (
            <div className="flex items-center space-x-2 px-3 py-1 bg-red-900/20 border border-red-500/30 rounded-full">
              <AlertTriangle size={16} className="text-red-400" />
              <span className="text-red-300 text-sm">Просрочен</span>
            </div>
          )}
          
          {getDaysUntilDeadline() !== null && !isOverdue() && (
            <div className="flex items-center space-x-2 px-3 py-1 bg-blue-900/20 border border-blue-500/30 rounded-full">
              <Clock size={16} className="text-blue-400" />
              <span className="text-blue-300 text-sm">
                {getDaysUntilDeadline()} дн. до дедлайна
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Информационная панель */}
      {!isMeasurementStage && (
        <div className="bg-blue-900/20 border border-blue-500/30 p-4 rounded-xl">
          <div className="flex items-start space-x-3">
            <Calculator size={20} className="text-blue-400 flex-shrink-0 mt-0.5" />
            <div className="text-blue-300 text-sm">
              <p className="font-medium mb-2">Автоматический расчет от этапа "Замер"</p>
              <p>Планируемое начало рассчитывается автоматически от даты замера с учетом длительности предыдущих этапов. Вы можете скорректировать дату вручную при необходимости.</p>
            </div>
          </div>
        </div>
      )}

      {/* Планируемые даты */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="space-y-6">
          <h5 className="font-medium text-white flex items-center">
            <Calendar size={16} className="mr-2 text-gold-400" />
            Планируемые даты
          </h5>
          
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="block text-sm font-medium text-white">
                Планируемое начало
              </label>
              {!isMeasurementStage && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleAutoCalculateStart}
                  className="text-xs px-2 py-1"
                >
                  Рассчитать от замера
                </Button>
              )}
            </div>
            <DatePicker
              value={schedule.plannedStartDate}
              onChange={(date) => handleDateChange('plannedStartDate', date)}
              placeholder="Выберите дату начала"
              minDate={getMinDate()}
            />
            {isMeasurementStage && (
              <p className="text-xs text-gray-400 mt-1">
                Ручной ввод даты начала замера
              </p>
            )}
          </div>
          
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="block text-sm font-medium text-white">
                Планируемое завершение
              </label>
              <label className="flex items-center space-x-2 text-xs">
                <input
                  type="checkbox"
                  checked={autoCalculateEnd}
                  onChange={(e) => setAutoCalculateEnd(e.target.checked)}
                  className="w-3 h-3 text-gold-400 bg-dark-800 border-gray-600 rounded focus:ring-gold-400"
                />
                <span className="text-gray-400">Авто-расчет</span>
              </label>
            </div>
            <DatePicker
              value={schedule.plannedEndDate}
              onChange={(date) => handleDateChange('plannedEndDate', date)}
              placeholder="Выберите дату завершения"
              disabled={autoCalculateEnd}
              minDate={schedule.plannedStartDate}
            />
            {autoCalculateEnd && stage.estimatedDuration > 0 && (
              <p className="text-xs text-gray-400 mt-1">
                Автоматически рассчитывается от длительности ({formatWorkingDaysText(stage.estimatedDuration)})
              </p>
            )}
          </div>
        </div>

        {/* Фактические даты */}
        <div className="space-y-6">
          <h5 className="font-medium text-white flex items-center">
            <Clock size={16} className="mr-2 text-green-400" />
            Фактические даты
          </h5>
          
          <div>
            <label className="block text-sm font-medium text-white mb-2">
              Фактическое начало
            </label>
            <DatePicker
              value={schedule.actualStartDate}
              onChange={(date) => handleDateChange('actualStartDate', date)}
              placeholder="Выберите дату начала"
              maxDate={new Date()}
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-white mb-2">
              Фактическое завершение
            </label>
            <DatePicker
              value={schedule.actualEndDate}
              onChange={(date) => handleDateChange('actualEndDate', date)}
              placeholder="Выберите дату завершения"
              minDate={schedule.actualStartDate}
              maxDate={new Date()}
            />
          </div>
        </div>
      </div>

      {/* Информация о длительности */}
      {schedule.plannedStartDate && schedule.plannedEndDate && (
        <div className="bg-dark-700/50 p-6 border border-gray-600 rounded-xl">
          <h6 className="font-medium text-white mb-4">Расчет длительности</h6>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-sm">
            <div>
              <span className="text-gray-400">Планируемая длительность:</span>
              <div className="text-white font-medium">
                {getWorkingDaysBetween(schedule.plannedStartDate, schedule.plannedEndDate)} рабочих дней
              </div>
              <div className="text-xs text-gray-500">
                Эталон: {formatWorkingDaysText(stage.estimatedDuration)}
              </div>
            </div>
            
            {schedule.actualStartDate && schedule.actualEndDate && (
              <div>
                <span className="text-gray-400">Фактическая длительность:</span>
                <div className="text-white font-medium">
                  {getWorkingDaysBetween(schedule.actualStartDate, schedule.actualEndDate)} рабочих дней
                </div>
              </div>
            )}
            
            {schedule.actualStartDate && !schedule.actualEndDate && (
              <div>
                <span className="text-gray-400">Длительность на данный момент:</span>
                <div className="text-white font-medium">
                  {getWorkingDaysBetween(schedule.actualStartDate, new Date())} рабочих дней
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Каскадное обновление для замера */}
      {isMeasurementStage && hasChanges && (
        <div className="bg-orange-900/20 border border-orange-500/30 p-4 rounded-xl">
          <div className="flex items-start space-x-3">
            <AlertTriangle size={20} className="text-orange-400 flex-shrink-0 mt-0.5" />
            <div className="text-orange-300 text-sm">
              <p className="font-medium mb-1">Внимание: Каскадное обновление</p>
              <p>Изменение даты замера автоматически пересчитает планируемые даты всех последующих этапов.</p>
            </div>
          </div>
        </div>
      )}

      {/* Кнопка сохранения */}
      {hasChanges && (
        <div className="flex justify-end">
          <Button
            variant="primary"
            onClick={handleSave}
            disabled={isUpdating}
            className="flex items-center space-x-2"
          >
            <Save size={16} />
            <span>
              {isMeasurementStage ? 'Сохранить и пересчитать этапы' : 'Сохранить расписание'}
            </span>
          </Button>
        </div>
      )}
    </div>
  );
};
