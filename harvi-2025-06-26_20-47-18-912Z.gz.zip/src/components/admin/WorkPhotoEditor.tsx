import React, { useState, useEffect } from 'react';
import { Save, Eye, EyeOff } from 'lucide-react';
import { Button } from '../ui/Button';
import { FormField } from '../ui/FormField';
import { contentService } from '../../services/contentService';
import type { WorkPhoto, Collection } from '../../types';

interface WorkPhotoEditorProps {
  photo?: WorkPhoto;
  onSave: () => void;
  onCancel: () => void;
}

export const WorkPhotoEditor: React.FC<WorkPhotoEditorProps> = ({
  photo,
  onSave,
  onCancel
}) => {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    imageUrl: '',
    category: 'kitchen' as WorkPhoto['category'],
    collectionId: '',
    tags: '',
    isPublished: true
  });

  const [collections, setCollections] = useState<Collection[]>([]);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const categoryOptions = [
    { value: 'kitchen', label: 'Готовые кухни' },
    { value: 'design', label: 'Дизайн-проекты' },
    { value: 'installation', label: 'Процесс установки' },
    { value: 'materials', label: 'Материалы и образцы' }
  ];

  useEffect(() => {
    setCollections(contentService.getCollections());
    
    if (photo) {
      setFormData({
        title: photo.title,
        description: photo.description,
        imageUrl: photo.imageUrl,
        category: photo.category,
        collectionId: photo.collectionId || '',
        tags: photo.tags.join(', '),
        isPublished: photo.isPublished
      });
    }
  }, [photo]);

  const handleInputChange = (field: string, value: string | boolean) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    
    // Очистка ошибки при изменении поля
    if (errors[field]) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[field];
        return newErrors;
      });
    }
  };

  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.title.trim()) {
      newErrors.title = 'Название обязательно';
    }
    
    if (!formData.description.trim()) {
      newErrors.description = 'Описание обязательно';
    }
    
    if (!formData.imageUrl.trim()) {
      newErrors.imageUrl = 'URL изображения обязателен';
    } else {
      try {
        new URL(formData.imageUrl);
      } catch {
        newErrors.imageUrl = 'Некорректный URL изображения';
      }
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;
    
    setIsSubmitting(true);
    
    try {
      const photoData = {
        ...(photo && { id: photo.id }),
        title: formData.title.trim(),
        description: formData.description.trim(),
        imageUrl: formData.imageUrl.trim(),
        category: formData.category,
        collectionId: formData.collectionId || undefined,
        tags: formData.tags.split(',').map(tag => tag.trim()).filter(tag => tag),
        isPublished: formData.isPublished
      };
      
      contentService.saveWorkPhoto(photoData);
      onSave();
    } catch (error) {
      setErrors({ submit: `Ошибка сохранения: ${error}` });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="bg-dark-900/50 backdrop-blur-sm border border-gold-400/10 p-8 rounded-xl">
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <FormField label="Название" error={errors.title} required>
            <input
              type="text"
              value={formData.title}
              onChange={(e) => handleInputChange('title', e.target.value)}
              className="w-full p-3 bg-dark-800 border border-gray-600 text-white focus:outline-none focus:border-gold-400 rounded-lg"
              placeholder="Название фотографии"
            />
          </FormField>

          <FormField label="URL изображения" error={errors.imageUrl} required>
            <input
              type="url"
              value={formData.imageUrl}
              onChange={(e) => handleInputChange('imageUrl', e.target.value)}
              className="w-full p-3 bg-dark-800 border border-gray-600 text-white focus:outline-none focus:border-gold-400 rounded-lg"
              placeholder="https://example.com/image.jpg"
            />
          </FormField>
        </div>

        <FormField label="Описание" error={errors.description} required>
          <textarea
            value={formData.description}
            onChange={(e) => handleInputChange('description', e.target.value)}
            className="w-full p-3 bg-dark-800 border border-gray-600 text-white focus:outline-none focus:border-gold-400 rounded-lg"
            rows={4}
            placeholder="Подробное описание фотографии"
          />
        </FormField>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <FormField label="Категория" error={errors.category} required>
            <select
              value={formData.category}
              onChange={(e) => handleInputChange('category', e.target.value)}
              className="w-full p-3 bg-dark-800 border border-gray-600 text-white focus:outline-none focus:border-gold-400 rounded-lg"
            >
              {categoryOptions.map(option => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
          </FormField>

          <FormField label="Коллекция (опционально)" error={errors.collectionId}>
            <select
              value={formData.collectionId}
              onChange={(e) => handleInputChange('collectionId', e.target.value)}
              className="w-full p-3 bg-dark-800 border border-gray-600 text-white focus:outline-none focus:border-gold-400 rounded-lg"
            >
              <option value="">Не привязано к коллекции</option>
              {collections.map(collection => (
                <option key={collection.id} value={collection.id}>
                  {collection.title}
                </option>
              ))}
            </select>
          </FormField>
        </div>

        <FormField label="Теги (через запятую)" error={errors.tags}>
          <input
            type="text"
            value={formData.tags}
            onChange={(e) => handleInputChange('tags', e.target.value)}
            className="w-full p-3 bg-dark-800 border border-gray-600 text-white focus:outline-none focus:border-gold-400 rounded-lg"
            placeholder="минимализм, современный стиль, белый цвет"
          />
        </FormField>

        <div className="flex items-center space-x-3">
          <label className="flex items-center space-x-2 cursor-pointer">
            <input
              type="checkbox"
              checked={formData.isPublished}
              onChange={(e) => handleInputChange('isPublished', e.target.checked)}
              className="w-4 h-4 text-gold-400 bg-dark-800 border-gray-600 rounded focus:ring-gold-400"
            />
            <span className="text-white flex items-center space-x-2">
              {formData.isPublished ? <Eye size={16} /> : <EyeOff size={16} />}
              <span>{formData.isPublished ? 'Опубликовано' : 'Скрыто'}</span>
            </span>
          </label>
        </div>

        {/* Preview */}
        {formData.imageUrl && (
          <div className="border border-gray-700 rounded-lg p-4">
            <h4 className="text-white font-medium mb-3">Предварительный просмотр:</h4>
            <div className="aspect-video max-w-md overflow-hidden rounded-lg">
              <img
                src={formData.imageUrl}
                alt="Предварительный просмотр"
                className="w-full h-full object-cover"
                onError={(e) => {
                  (e.target as HTMLImageElement).style.display = 'none';
                }}
              />
            </div>
          </div>
        )}

        {errors.submit && (
          <div className="p-4 bg-red-900/20 border border-red-500/30 text-red-300 rounded-lg">
            {errors.submit}
          </div>
        )}

        <div className="flex justify-end space-x-4 pt-6 border-t border-gray-700">
          <Button
            type="button"
            variant="outline"
            onClick={onCancel}
            disabled={isSubmitting}
          >
            Отмена
          </Button>
          <Button
            type="submit"
            variant="primary"
            disabled={isSubmitting}
            className="flex items-center space-x-2"
          >
            <Save size={16} />
            <span>{isSubmitting ? 'Сохранение...' : 'Сохранить'}</span>
          </Button>
        </div>
      </form>
    </div>
  );
};