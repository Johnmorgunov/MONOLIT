import React, { useState, useEffect, useCallback, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ChevronLeft, ChevronRight, Check, Save, Package, AlertCircle } from 'lucide-react';
import { getCollectionBySlug } from '../../data/collections';
import { briefSteps, mdfDecors, ldspDecors } from '../../data/briefQuestions';
import { AnimatedSection } from '../ui/AnimatedSection';
import { Button } from '../ui/Button';
import { DataProcessingConsent } from '../ui/DataProcessingConsent';
import { FormField } from '../ui/FormField';
import { LoadingSpinner } from '../ui/LoadingSpinner';
import { ErrorMessage } from '../ui/ErrorMessage';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { validatePhone, validateEmail, validateName, getValidationError, sanitizeInput } from '../../utils/validation';
import { orderService } from '../../services/orderService';
import type { BriefAnswer, BriefResult, DataProcessingConsent as ConsentType } from '../../types';

export const BriefForm: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  
  const [currentStep, setCurrentStep] = useState(0);
  const [answers, setAnswers, removeAnswers, { error: storageError, isLoading: storageLoading }] = useLocalStorage<BriefAnswer[]>(`brief_answers_${slug}`, []);
  const [isCompleted, setIsCompleted] = useState(false);
  const [createdOrderNumber, setCreatedOrderNumber] = useState<string | null>(null);
  const [dataProcessingConsent, setDataProcessingConsent] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [validationErrors, setValidationErrors] = useState<Record<string, string>>({});
  const [lastSaved, setLastSaved] = useState<Date | null>(null);
  const [isInitialized, setIsInitialized] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  
  // Refs для отслеживания изменений и предотвращения race conditions
  const lastSavedAnswers = useRef<string>('');
  const lastSavedStep = useRef<number>(0);
  const saveTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const isSubmittingRef = useRef(false);

  const collection = slug ? getCollectionBySlug(slug) : null;

  // Валидация входных данных
  const isValidStep = useCallback((step: number): boolean => {
    return step >= 0 && step < briefSteps.length && briefSteps.length > 0;
  }, []);

  // Безопасное получение данных текущего шага
  const getCurrentStepData = useCallback(() => {
    if (!isValidStep(currentStep)) {
      console.warn(`Некорректный шаг: ${currentStep}. Возвращаемся к первому шагу.`);
      return briefSteps[0] || null;
    }
    return briefSteps[currentStep];
  }, [currentStep, isValidStep]);

  const currentStepData = getCurrentStepData();

  // Проверка корректности данных при загрузке
  useEffect(() => {
    if (!collection) {
      setFormError('Коллекция не найдена');
      navigate('/');
      return;
    }

    if (!briefSteps || briefSteps.length === 0) {
      setFormError('Данные брифа недоступны');
      console.error('briefSteps пустой или не определен');
      navigate('/');
      return;
    }

    setFormError(null);
  }, [collection, navigate]);

  // Восстановление прогресса при загрузке с валидацией
  useEffect(() => {
    if (!slug || !briefSteps || briefSteps.length === 0 || isInitialized) return;

    const savedProgress = localStorage.getItem(`brief_progress_${slug}`);
    if (savedProgress) {
      try {
        const { currentStep: savedStep, answers: savedAnswers, timestamp } = JSON.parse(savedProgress);
        
        // Проверяем актуальность сохраненных данных (не старше 24 часов)
        const saveTime = new Date(timestamp);
        const now = new Date();
        const hoursDiff = (now.getTime() - saveTime.getTime()) / (1000 * 60 * 60);
        
        if (hoursDiff > 24) {
          console.warn('Сохраненные данные устарели, сбрасываем прогресс');
          localStorage.removeItem(`brief_progress_${slug}`);
          removeAnswers();
        } else if (
          typeof savedStep === 'number' && 
          savedStep >= 0 && 
          savedStep < briefSteps.length && 
          Array.isArray(savedAnswers)
        ) {
          setCurrentStep(savedStep);
          setAnswers(savedAnswers);
          
          // Обновляем refs для корректного отслеживания изменений
          lastSavedAnswers.current = JSON.stringify(savedAnswers);
          lastSavedStep.current = savedStep;
          
          setLastSaved(saveTime);
        } else {
          console.warn('Некорректные сохраненные данные, сбрасываем прогресс');
          localStorage.removeItem(`brief_progress_${slug}`);
          removeAnswers();
        }
      } catch (error) {
        console.warn('Ошибка восстановления прогресса:', error);
        localStorage.removeItem(`brief_progress_${slug}`);
        removeAnswers();
      }
    }
    
    setIsInitialized(true);
  }, [slug, setAnswers, removeAnswers, isInitialized]);

  // Проверка необходимости сохранения
  const needsSaving = useCallback(() => {
    if (!isInitialized || answers.length === 0) return false;
    
    const currentAnswersString = JSON.stringify(answers);
    const stepChanged = currentStep !== lastSavedStep.current;
    const answersChanged = currentAnswersString !== lastSavedAnswers.current;
    
    return stepChanged || answersChanged;
  }, [answers, currentStep, isInitialized]);

  // Автосохранение с защитой от ошибок
  const saveProgress = useCallback(() => {
    if (!slug || !isValidStep(currentStep) || !needsSaving() || isSubmittingRef.current) return;

    try {
      const progressData = {
        currentStep,
        answers,
        timestamp: new Date().toISOString()
      };
      
      localStorage.setItem(`brief_progress_${slug}`, JSON.stringify(progressData));
      
      // Обновляем refs для отслеживания изменений
      lastSavedAnswers.current = JSON.stringify(answers);
      lastSavedStep.current = currentStep;
      
      setLastSaved(new Date());
      setFormError(null);
    } catch (error) {
      console.warn('Ошибка сохранения прогресса:', error);
      setFormError('Ошибка сохранения данных. Проверьте свободное место на устройстве.');
    }
  }, [currentStep, answers, slug, needsSaving, isValidStep]);

  // Debounced автосохранение
  const debouncedSave = useCallback(() => {
    if (saveTimeoutRef.current) {
      clearTimeout(saveTimeoutRef.current);
    }
    
    saveTimeoutRef.current = setTimeout(() => {
      saveProgress();
    }, 1000);
  }, [saveProgress]);

  // Автосохранение при изменениях
  useEffect(() => {
    if (isInitialized && needsSaving() && !isSubmittingRef.current) {
      debouncedSave();
    }
    
    return () => {
      if (saveTimeoutRef.current) {
        clearTimeout(saveTimeoutRef.current);
      }
    };
  }, [answers, currentStep, debouncedSave, needsSaving, isInitialized]);

  // Обработка ошибок localStorage
  useEffect(() => {
    if (storageError) {
      setFormError(`Ошибка работы с локальным хранилищем: ${storageError}`);
    }
  }, [storageError]);

  // Ранний выход если нет необходимых данных
  if (formError) {
    return (
      <div className="min-h-screen bg-dark-950 pt-20 flex items-center justify-center">
        <div className="text-center max-w-md mx-auto p-6">
          <AlertCircle size={48} className="text-red-400 mx-auto mb-4" />
          <h2 className="text-xl font-medium text-white mb-4">Ошибка загрузки</h2>
          <p className="text-gray-300 mb-6">{formError}</p>
          <Button variant="primary" onClick={() => navigate('/')}>
            Вернуться на главную
          </Button>
        </div>
      </div>
    );
  }

  if (!collection || !briefSteps || briefSteps.length === 0 || !currentStepData) {
    return (
      <div className="min-h-screen bg-dark-950 pt-20 flex items-center justify-center">
        <div className="text-center">
          <LoadingSpinner size="lg" className="text-gold-400 mx-auto mb-4" />
          <p className="text-white">Загрузка брифа...</p>
        </div>
      </div>
    );
  }

  const totalSteps = briefSteps.length;
  const progress = ((currentStep + 1) / totalSteps) * 100;
  const isLastStep = currentStep === totalSteps - 1;

  const handleAnswer = useCallback((questionId: string, value: string | string[] | number) => {
    // Санитизация текстовых данных
    const sanitizedValue = typeof value === 'string' ? sanitizeInput(value) : value;
    
    setAnswers(prev => {
      const existing = prev.find(a => a.questionId === questionId);
      if (existing) {
        return prev.map(a => 
          a.questionId === questionId ? { ...a, value: sanitizedValue } : a
        );
      }
      return [...prev, { questionId, value: sanitizedValue }];
    });

    // Очистка ошибки валидации при изменении значения
    setValidationErrors(prev => {
      if (prev[questionId]) {
        const newErrors = { ...prev };
        delete newErrors[questionId];
        return newErrors;
      }
      return prev;
    });
  }, [setAnswers]);

  const getAnswer = useCallback((questionId: string) => {
    return answers.find(a => a.questionId === questionId)?.value;
  }, [answers]);

  const validateCurrentStep = useCallback(() => {
    if (!currentStepData || !currentStepData.questions) {
      return false;
    }

    const errors: Record<string, string> = {};
    
    currentStepData.questions.forEach(question => {
      if (question.required) {
        const answer = getAnswer(question.id);
        
        if (answer === undefined || answer === null || (Array.isArray(answer) && answer.length === 0) || answer === '') {
          errors[question.id] = 'Это поле обязательно для заполнения';
          return;
        }

        // Специальная валидация для контактных данных
        if (typeof answer === 'string') {
          const validationError = getValidationError(question.id.replace('client_', ''), answer);
          if (validationError) {
            errors[question.id] = validationError;
          }
        }

        // Валидация для множественного выбора декоров
        if (question.id === 'facade_decors' && Array.isArray(answer) && answer.length > 3) {
          errors[question.id] = 'Можно выбрать максимум 3 декора';
        }
      }
    });

    // На последнем шаге проверяем согласие
    if (isLastStep && !dataProcessingConsent) {
      errors['consent'] = 'Необходимо дать согласие на обработку персональных данных';
    }

    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  }, [currentStepData, getAnswer, isLastStep, dataProcessingConsent]);

  const handleNext = useCallback(() => {
    if (!validateCurrentStep()) {
      // Прокручиваем к первой ошибке
      const firstErrorElement = document.querySelector('[data-error="true"]');
      if (firstErrorElement) {
        firstErrorElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
      return;
    }

    if (currentStep < totalSteps - 1) {
      const nextStep = currentStep + 1;
      if (isValidStep(nextStep)) {
        setCurrentStep(nextStep);
        // Принудительно сохраняем при переходе на следующий шаг
        setTimeout(() => saveProgress(), 100);
        
        // Прокручиваем к началу формы
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    } else {
      handleSubmit();
    }
  }, [validateCurrentStep, currentStep, totalSteps, saveProgress, isValidStep]);

  const handlePrev = useCallback(() => {
    if (currentStep > 0) {
      const prevStep = currentStep - 1;
      if (isValidStep(prevStep)) {
        setCurrentStep(prevStep);
        // Принудительно сохраняем при переходе на предыдущий шаг
        setTimeout(() => saveProgress(), 100);
        
        // Прокручиваем к началу формы
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    }
  }, [currentStep, saveProgress, isValidStep]);

  const handleSubmit = async () => {
    if (!dataProcessingConsent || !validateCurrentStep() || isSubmittingRef.current) return;

    setIsSubmitting(true);
    isSubmittingRef.current = true;

    try {
      const briefResult: BriefResult = {
        collectionId: collection.id,
        answers,
        timestamp: new Date(),
        dataProcessingConsent: true,
        consentTimestamp: new Date()
      };

      // Сохраняем результат брифа
      localStorage.setItem('briefResult', JSON.stringify(briefResult));

      // Сохраняем согласие на обработку данных
      const consent: ConsentType = {
        id: `brief_${Date.now()}`,
        type: 'brief',
        timestamp: new Date(),
        userAgent: navigator.userAgent,
        collectionId: collection.id
      };

      const existingConsents = JSON.parse(localStorage.getItem('dataProcessingConsents') || '[]');
      existingConsents.push(consent);
      localStorage.setItem('dataProcessingConsents', JSON.stringify(existingConsents));

      // СОЗДАЕМ ЗАКАЗ НА ОСНОВЕ БРИФА
      const newOrder = orderService.createOrderFromBrief(briefResult);
      setCreatedOrderNumber(newOrder.orderNumber);

      // Очищаем сохраненный прогресс
      if (slug) {
        localStorage.removeItem(`brief_progress_${slug}`);
        removeAnswers();
      }

      // Имитация отправки данных на сервер
      await new Promise(resolve => setTimeout(resolve, 1500));

      setIsCompleted(true);
    } catch (error) {
      console.error('Ошибка отправки брифа:', error);
      setValidationErrors({ submit: 'Произошла ошибка при отправке. Попробуйте еще раз.' });
    } finally {
      setIsSubmitting(false);
      isSubmittingRef.current = false;
    }
  };

  const renderQuestion = (question: any) => {
    const answer = getAnswer(question.id);
    const error = validationErrors[question.id];

    // Динамическое обновление опций для декоров фасадов
    if (question.id === 'facade_decors') {
      const facadeMaterial = getAnswer('facade_material');
      if (facadeMaterial === 'mdf') {
        question.options = mdfDecors;
      } else if (facadeMaterial === 'ldsp') {
        question.options = ldspDecors;
      } else {
        question.options = [];
      }
    }

    switch (question.type) {
      case 'single':
        return (
          <FormField 
            label={question.question} 
            error={error} 
            required={question.required}
            className={error ? 'data-error' : ''}
          >
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {question.options?.map((option: any) => (
                <label
                  key={option.id}
                  className={`
                    block border cursor-pointer transition-all duration-300 rounded-xl overflow-hidden
                    ${answer === option.id 
                      ? 'border-gold-400 bg-gold-400/10 shadow-lg shadow-gold-400/20' 
                      : 'border-gray-600 hover:border-gold-400/50 hover:shadow-md'
                    }
                    ${error ? 'border-red-500/50' : ''}
                  `}
                >
                  <input
                    type="radio"
                    name={question.id}
                    value={option.id}
                    checked={answer === option.id}
                    onChange={(e) => handleAnswer(question.id, e.target.value)}
                    className="sr-only"
                    aria-describedby={error ? `${question.id}-error` : undefined}
                  />
                  
                  {/* Изображение опции */}
                  {option.image && (
                    <div className="aspect-video bg-dark-800 overflow-hidden">
                      <img
                        src={option.image}
                        alt={option.label}
                        className="w-full h-full object-cover"
                        loading="lazy"
                      />
                    </div>
                  )}
                  
                  <div className="p-4">
                    <div className="flex items-start">
                      <div className={`
                        w-4 h-4 rounded-full border-2 mr-3 mt-1 flex-shrink-0
                        ${answer === option.id 
                          ? 'border-gold-400 bg-gold-400' 
                          : 'border-gray-400'
                        }
                      `}>
                        {answer === option.id && (
                          <div className="w-full h-full rounded-full bg-white scale-50"></div>
                        )}
                      </div>
                      <div className="flex-1">
                        <div className="font-medium text-white mb-1">{option.label}</div>
                        {option.description && (
                          <div className="text-sm text-gray-400">{option.description}</div>
                        )}
                      </div>
                    </div>
                  </div>
                </label>
              ))}
            </div>
          </FormField>
        );

      case 'multiple':
        const multiAnswer = Array.isArray(answer) ? answer : [];
        const maxSelections = question.id === 'facade_decors' ? 3 : undefined;
        
        return (
          <FormField 
            label={question.question} 
            error={error} 
            required={question.required}
            className={error ? 'data-error' : ''}
          >
            {maxSelections && (
              <div className="mb-4 text-sm text-gray-400">
                Выбрано: {multiAnswer.length} из {maxSelections}
              </div>
            )}
            
            {question.options?.length === 0 && question.id === 'facade_decors' && (
              <div className="text-center py-8 text-gray-400">
                <p>Сначала выберите материал фасада</p>
              </div>
            )}
            
            {question.options?.length > 0 && (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {question.options?.map((option: any) => {
                  const isSelected = multiAnswer.includes(option.id);
                  const isDisabled = maxSelections && !isSelected && multiAnswer.length >= maxSelections;
                  
                  return (
                    <label
                      key={option.id}
                      className={`
                        block border cursor-pointer transition-all duration-300 rounded-xl overflow-hidden
                        ${isSelected
                          ? 'border-gold-400 bg-gold-400/10 shadow-lg shadow-gold-400/20' 
                          : isDisabled
                          ? 'border-gray-700 opacity-50 cursor-not-allowed'
                          : 'border-gray-600 hover:border-gold-400/50 hover:shadow-md'
                        }
                        ${error ? 'border-red-500/50' : ''}
                      `}
                    >
                      <input
                        type="checkbox"
                        value={option.id}
                        checked={isSelected}
                        disabled={isDisabled}
                        onChange={(e) => {
                          const newAnswer = e.target.checked
                            ? [...multiAnswer, option.id]
                            : multiAnswer.filter(id => id !== option.id);
                          handleAnswer(question.id, newAnswer);
                        }}
                        className="sr-only"
                        aria-describedby={error ? `${question.id}-error` : undefined}
                      />
                      
                      {/* Изображение опции */}
                      {option.image && (
                        <div className="aspect-video bg-dark-800 overflow-hidden">
                          <img
                            src={option.image}
                            alt={option.label}
                            className="w-full h-full object-cover"
                            loading="lazy"
                          />
                        </div>
                      )}
                      
                      <div className="p-4">
                        <div className="flex items-start">
                          <div className={`
                            w-4 h-4 border-2 mr-3 mt-1 flex-shrink-0 rounded
                            ${isSelected
                              ? 'border-gold-400 bg-gold-400' 
                              : 'border-gray-400'
                            }
                          `}>
                            {isSelected && (
                              <Check size={12} className="text-black" />
                            )}
                          </div>
                          <div className="flex-1">
                            <div className="font-medium text-white mb-1">{option.label}</div>
                            {option.description && (
                              <div className="text-sm text-gray-400">{option.description}</div>
                            )}
                          </div>
                        </div>
                      </div>
                    </label>
                  );
                })}
              </div>
            )}
          </FormField>
        );

      case 'range':
        // Устанавливаем значение по умолчанию равное минимальному значению, если ответа нет
        const rangeValue = answer !== undefined ? answer : question.min;
        
        return (
          <FormField 
            label={question.question} 
            error={error} 
            required={question.required}
            className={error ? 'data-error' : ''}
          >
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-gray-400">{question.min} {question.unit}</span>
                <span className="text-gold-400 font-medium text-lg">
                  {rangeValue} {question.unit}
                </span>
                <span className="text-gray-400">{question.max} {question.unit}</span>
              </div>
              <input
                type="range"
                min={question.min}
                max={question.max}
                step={question.unit === 'м' ? 0.1 : 1}
                value={rangeValue}
                onChange={(e) => handleAnswer(question.id, parseFloat(e.target.value))}
                className="w-full h-3 bg-gray-600 rounded-lg appearance-none cursor-pointer slider"
                aria-describedby={error ? `${question.id}-error` : undefined}
              />
              {question.min === 0 && (
                <div className="text-xs text-gray-400 mt-2">
                  Установите значение 0, если данный тип модулей не нужен
                </div>
              )}
            </div>
          </FormField>
        );

      case 'text':
        return (
          <FormField 
            label={question.question} 
            error={error} 
            required={question.required}
            className={error ? 'data-error' : ''}
          >
            <input
              type="text"
              value={answer || ''}
              onChange={(e) => handleAnswer(question.id, e.target.value)}
              className={`
                w-full p-4 bg-dark-800 border text-white focus:outline-none transition-colors duration-300 rounded-xl
                ${error 
                  ? 'border-red-500 focus:border-red-400' 
                  : 'border-gray-600 focus:border-gold-400'
                }
              `}
              placeholder="Введите ответ..."
              aria-describedby={error ? `${question.id}-error` : undefined}
            />
          </FormField>
        );

      default:
        return null;
    }
  };

  if (isCompleted) {
    return (
      <div className="min-h-screen bg-dark-950 pt-20 flex items-center justify-center">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <AnimatedSection>
            <div className="max-w-2xl mx-auto text-center">
              <div className="w-20 h-20 bg-gold-400 rounded-full flex items-center justify-center mx-auto mb-8">
                <Check size={40} className="text-black" />
              </div>
              <h1 className="font-manrope text-3xl lg:text-4xl font-medium text-white mb-6">
                Спасибо за ваши ответы!
              </h1>
              <p className="text-lg text-gray-300 mb-6">
                Мы получили вашу информацию и подготовим персональное предложение 
                для коллекции {collection.title}. Наш специалист свяжется с вами в ближайшее время.
              </p>
              
              {/* Информация о созданном заказе */}
              {createdOrderNumber && (
                <div className="bg-gold-400/20 border border-gold-400/30 p-6 mb-8 rounded-xl">
                  <div className="flex items-center justify-center space-x-3 mb-4">
                    <Package size={24} className="text-gold-400" />
                    <h2 className="font-manrope text-xl font-medium text-white">
                      Заказ создан!
                    </h2>
                  </div>
                  <p className="text-white mb-4">
                    Ваш номер заказа: <span className="font-bold text-gold-400">{createdOrderNumber}</span>
                  </p>
                  <p className="text-gray-300 text-sm mb-4">
                    Сохраните этот номер для отслеживания статуса заказа
                  </p>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => navigate(`/order/${createdOrderNumber}`)}
                    className="mb-2"
                  >
                    Отследить заказ
                  </Button>
                </div>
              )}
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button
                  variant="primary"
                  size="lg"
                  onClick={() => navigate(`/collection/${collection.slug}`)}
                >
                  Вернуться к коллекции
                </Button>
                <Button
                  variant="outline"
                  size="lg"
                  onClick={() => navigate('/')}
                >
                  На главную
                </Button>
              </div>
            </div>
          </AnimatedSection>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-dark-950 pt-20">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Header */}
        <AnimatedSection>
          <div className="max-w-4xl mx-auto mb-12">
            <div className="flex items-center justify-between mb-6">
              <h1 className="font-manrope text-2xl lg:text-3xl font-medium text-white">
                Бриф для коллекции {collection.title}
              </h1>
              <div className="flex items-center space-x-4">
                <div className="text-sm text-gray-400">
                  {currentStep + 1} из {totalSteps}
                </div>
                {lastSaved && (
                  <div className="flex items-center text-xs text-green-400">
                    <Save size={14} className="mr-1" />
                    <span>Сохранено {lastSaved.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })}</span>
                  </div>
                )}
                {storageLoading && (
                  <LoadingSpinner size="sm" className="text-gold-400" />
                )}
              </div>
            </div>
            
            {/* Progress Bar */}
            <div className="w-full bg-gray-700 h-2 rounded-full overflow-hidden">
              <div 
                className="h-full bg-gold-400 transition-all duration-500 ease-out"
                style={{ width: `${progress}%` }}
                role="progressbar"
                aria-valuenow={progress}
                aria-valuemin={0}
                aria-valuemax={100}
                aria-label={`Прогресс: ${Math.round(progress)}%`}
              ></div>
            </div>
          </div>
        </AnimatedSection>

        {/* Step Content */}
        <AnimatedSection>
          <div className="max-w-6xl mx-auto">
            <div className="bg-dark-900/50 backdrop-blur-sm border border-gold-400/10 p-8 lg:p-12 rounded-xl">
              <div className="mb-8">
                <h2 className="font-manrope text-xl lg:text-2xl font-medium text-white mb-4">
                  {currentStepData.title}
                </h2>
                <p className="text-gray-300">
                  {currentStepData.description}
                </p>
              </div>

              <div className="space-y-8">
                {currentStepData.questions?.map((question) => (
                  <div key={question.id}>
                    {question.description && (
                      <p className="text-sm text-gray-400 mb-4">
                        {question.description}
                      </p>
                    )}
                    {renderQuestion(question)}
                  </div>
                ))}

                {/* Data Processing Consent on Last Step */}
                {isLastStep && (
                  <div className="pt-6 border-t border-gray-700">
                    <DataProcessingConsent
                      isChecked={dataProcessingConsent}
                      onChange={setDataProcessingConsent}
                      required={true}
                    />
                    {validationErrors['consent'] && (
                      <ErrorMessage message={validationErrors['consent']} className="mt-2" />
                    )}
                  </div>
                )}

                {/* Submit Error */}
                {validationErrors['submit'] && (
                  <ErrorMessage 
                    message={validationErrors['submit']} 
                    onRetry={() => setValidationErrors(prev => {
                      const newErrors = { ...prev };
                      delete newErrors['submit'];
                      return newErrors;
                    })}
                  />
                )}
              </div>

              {/* Navigation */}
              <div className="flex items-center justify-between mt-12 pt-8 border-t border-gray-700">
                <Button
                  variant="outline"
                  onClick={handlePrev}
                  disabled={currentStep === 0 || isSubmitting}
                  className={`flex items-center space-x-2 ${
                    currentStep === 0 ? 'opacity-50 cursor-not-allowed' : ''
                  }`}
                >
                  <ChevronLeft size={20} />
                  <span>Назад</span>
                </Button>

                <Button
                  variant="primary"
                  onClick={handleNext}
                  disabled={isSubmitting || storageLoading}
                  className="flex items-center space-x-2"
                >
                  {isSubmitting ? (
                    <>
                      <LoadingSpinner size="sm" />
                      <span>Создание заказа...</span>
                    </>
                  ) : (
                    <>
                      <span>{isLastStep ? 'Создать заказ' : 'Далее'}</span>
                      {!isLastStep && <ChevronRight size={20} />}
                    </>
                  )}
                </Button>
              </div>
            </div>
          </div>
        </AnimatedSection>
      </div>
    </div>
  );
};