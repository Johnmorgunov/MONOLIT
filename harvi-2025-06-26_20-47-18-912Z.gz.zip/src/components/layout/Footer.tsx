import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="py-12 bg-dark-950 border-t border-gold-400/20">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <p className="text-sm text-gray-400 font-light tracking-wider">
          © 2025 MONOLIT. Премиальные кухни по оптимальной цене. Все права защищены.
        </p>
      </div>
    </footer>
  );
};
