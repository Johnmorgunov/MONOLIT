import React, { useState, useEffect } from 'react';
import { Menu, X, ArrowLeft, Home } from 'lucide-react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useSmoothScroll } from '../../hooks/useSmoothScroll';

export const Header: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { scrollToSection } = useSmoothScroll();
  const location = useLocation();
  const navigate = useNavigate();

  // Определяем тип страницы для правильной навигации
  const pageType = React.useMemo(() => {
    const path = location.pathname;
    
    if (path === '/') return 'home';
    if (path === '/collections') return 'collections';
    if (path === '/useful') return 'useful';
    if (path.startsWith('/collection/') && path.endsWith('/brief')) return 'brief';
    if (path.startsWith('/collection/')) return 'collection';
    if (path.startsWith('/order/')) return 'order';
    if (path === '/admin') return 'admin';
    
    return 'other';
  }, [location.pathname]);

  const isHomePage = pageType === 'home';
  const isCollectionPage = pageType === 'collection';
  const isBriefPage = pageType === 'brief';
  const isOrderTrackingPage = pageType === 'order';
  const isCollectionsPage = pageType === 'collections';
  const isUsefulPage = pageType === 'useful';
  const isAdminPage = pageType === 'admin';

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Закрываем мобильное меню при смене маршрута
  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [location.pathname]);

  const navItems = [
    { label: 'Коллекции', href: 'collections', isLink: true },
    { label: 'Полезное', href: 'useful', isLink: true },
    { label: 'Отследить заказ', href: '/order/search', isLink: true },
    { label: 'Контакты', href: 'contact' },
  ];

  const handleNavClick = (item: typeof navItems[0]) => {
    setIsMobileMenuOpen(false);
    
    if (item.isLink) {
      // Для ссылок на отдельные страницы
      return;
    }
    
    if (isHomePage) {
      scrollToSection(item.href);
    } else {
      navigate(`/#${item.href}`);
    }
  };

  const handleBackClick = () => {
    if (isBriefPage) {
      // Из брифа возвращаемся к коллекции
      const collectionSlug = location.pathname.split('/')[2];
      navigate(`/collection/${collectionSlug}`);
    } else if (isCollectionPage || isOrderTrackingPage || isUsefulPage) {
      // Из коллекции, отслеживания заказа или полезного на главную
      navigate('/');
    } else if (isCollectionsPage) {
      // Из списка коллекций на главную
      navigate('/');
    } else {
      // Общий случай - назад в истории
      window.history.back();
    }
  };

  const getBackButtonText = () => {
    if (isBriefPage) return 'К коллекции';
    if (isCollectionPage || isOrderTrackingPage || isUsefulPage) return 'На главную';
    if (isCollectionsPage) return 'На главную';
    return 'Назад';
  };

  // Не показываем хедер на админ-странице
  if (isAdminPage) {
    return null;
  }

  return (
    <header className={`
      fixed top-0 left-0 w-full z-50 transition-all duration-300
      ${isScrolled 
        ? 'bg-dark-900/95 backdrop-blur-lg border-b border-gold-400/20' 
        : 'bg-dark-900/70 backdrop-blur-sm'
      }
    `}>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 lg:h-20">
          {/* Back Button для не-главных страниц */}
          {!isHomePage && (
            <button
              onClick={handleBackClick}
              className="flex items-center space-x-2 text-white hover:text-gold-400 transition-colors duration-300 mr-4 group"
              aria-label={getBackButtonText()}
            >
              <ArrowLeft size={20} className="group-hover:-translate-x-1 transition-transform duration-300" />
              <span className="hidden sm:inline text-sm uppercase tracking-wider">
                {getBackButtonText()}
              </span>
            </button>
          )}

          {/* Logo */}
          <Link 
            to="/"
            className="font-manrope text-xl lg:text-2xl font-semibold text-gold-400 uppercase tracking-widest hover:text-gold-300 transition-colors duration-300 group"
            aria-label="MONOLIT - На главную страницу"
          >
            <span className="group-hover:scale-105 transition-transform duration-300 inline-block">
              MONOLIT
            </span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center space-x-8" role="navigation">
            {navItems.map((item) => (
              item.isLink ? (
                <Link
                  key={item.href}
                  to={item.href.startsWith('/') ? item.href : `/${item.href}`}
                  className="text-sm text-white hover:text-gold-400 transition-colors duration-300 uppercase tracking-wider font-light relative group"
                  aria-label={item.label}
                >
                  {item.label}
                  <span className="absolute -bottom-1 left-0 w-0 h-px bg-gold-400 transition-all duration-300 group-hover:w-full"></span>
                </Link>
              ) : (
                <button
                  key={item.href}
                  onClick={() => handleNavClick(item)}
                  className="text-sm text-white hover:text-gold-400 transition-colors duration-300 uppercase tracking-wider font-light relative group"
                  aria-label={item.label}
                >
                  {item.label}
                  <span className="absolute -bottom-1 left-0 w-0 h-px bg-gold-400 transition-all duration-300 group-hover:w-full"></span>
                </button>
              )
            ))}
          </nav>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="lg:hidden p-2 text-white hover:text-gold-400 transition-colors duration-300 relative z-50"
            aria-label={isMobileMenuOpen ? 'Закрыть меню' : 'Открыть меню'}
            aria-expanded={isMobileMenuOpen}
          >
            <div className="relative w-6 h-6">
              <Menu 
                size={24} 
                className={`absolute inset-0 transition-all duration-300 ${
                  isMobileMenuOpen ? 'opacity-0 rotate-90' : 'opacity-100 rotate-0'
                }`} 
              />
              <X 
                size={24} 
                className={`absolute inset-0 transition-all duration-300 ${
                  isMobileMenuOpen ? 'opacity-100 rotate-0' : 'opacity-0 -rotate-90'
                }`} 
              />
            </div>
          </button>
        </div>

        {/* Mobile Navigation */}
        <div className={`
          lg:hidden absolute top-full left-0 w-full bg-dark-900/95 backdrop-blur-lg border-b border-gold-400/20
          transition-all duration-300 ease-out
          ${isMobileMenuOpen 
            ? 'opacity-100 translate-y-0 pointer-events-auto' 
            : 'opacity-0 -translate-y-4 pointer-events-none'
          }
        `}>
          <nav className="px-4 py-6 space-y-4" role="navigation">
            {/* Кнопка "На главную" для мобильного меню на не-главных страницах */}
            {!isHomePage && (
              <Link
                to="/"
                className="flex items-center space-x-3 w-full text-left text-white hover:text-gold-400 transition-colors duration-300 uppercase tracking-wider text-sm font-light py-2 border-b border-gray-700"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                <Home size={16} />
                <span>Главная</span>
              </Link>
            )}
            
            {navItems.map((item) => (
              item.isLink ? (
                <Link
                  key={item.href}
                  to={item.href.startsWith('/') ? item.href : `/${item.href}`}
                  className="block w-full text-left text-white hover:text-gold-400 transition-colors duration-300 uppercase tracking-wider text-sm font-light py-2"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  {item.label}
                </Link>
              ) : (
                <button
                  key={item.href}
                  onClick={() => handleNavClick(item)}
                  className="block w-full text-left text-white hover:text-gold-400 transition-colors duration-300 uppercase tracking-wider text-sm font-light py-2"
                >
                  {item.label}
                </button>
              )
            ))}
          </nav>
        </div>
      </div>
    </header>
  );
};