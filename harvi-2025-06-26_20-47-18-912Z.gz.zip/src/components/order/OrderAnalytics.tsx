import React from 'react';
import { TrendingUp, Clock, CheckCircle, BarChart3 } from 'lucide-react';
import { AnimatedSection } from '../ui/AnimatedSection';
import { formatWorkingDaysText, getWorkingDaysBetween } from '../../utils/workingDays';
import type { Order } from '../../types/order';

interface OrderAnalyticsProps {
  order: Order;
}

export const OrderAnalytics: React.FC<OrderAnalyticsProps> = ({ order }) => {
  const completedStages = order.stages.filter(stage => stage.status === 'completed').length;
  const totalStages = order.stages.length;
  
  // Рассчитываем оставшиеся рабочие дни
  const now = new Date();
  const remainingWorkingDays = getWorkingDaysBetween(now, order.estimatedCompletionDate);

  const currentStage = order.stages.find(s => s.status === 'current');
  const nextEstimatedDate = currentStage?.estimatedEndDate;
  
  // Общая длительность проекта в рабочих днях (исключая свободные этапы)
  const totalProjectDays = order.stages
    .filter(stage => !stage.isFlexibleTiming)
    .reduce((sum, stage) => sum + stage.estimatedDuration, 0);

  const analytics = [
    {
      icon: <TrendingUp size={24} className="text-gold-400" />,
      title: 'Общий прогресс',
      value: `${Math.round(order.totalProgress)}%`,
      description: `${completedStages} из ${totalStages} этапов завершено`
    },
    {
      icon: <Clock size={24} className="text-blue-400" />,
      title: 'Осталось времени',
      value: remainingWorkingDays > 0 ? formatWorkingDaysText(remainingWorkingDays) : 'Завершен',
      description: nextEstimatedDate 
        ? `Следующий этап до ${nextEstimatedDate.toLocaleDateString('ru-RU')}`
        : `До ${order.estimatedCompletionDate.toLocaleDateString('ru-RU')}`
    },
    {
      icon: <CheckCircle size={24} className="text-green-400" />,
      title: 'Текущий этап',
      value: currentStage?.title || 'Завершен',
      description: 'Активная фаза проекта'
    },
    {
      icon: <BarChart3 size={24} className="text-purple-400" />,
      title: 'Общая длительность',
      value: formatWorkingDaysText(totalProjectDays),
      description: 'Полный цикл изготовления (только рабочие дни)'
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {analytics.map((item, index) => (
        <AnimatedSection key={index}>
          <div className="bg-dark-900/50 backdrop-blur-sm border border-gold-400/10 p-6 hover:border-gold-400/30 transition-all duration-300">
            <div className="flex items-center mb-4">
              {item.icon}
              <h3 className="font-manrope text-sm font-medium text-white ml-3">
                {item.title}
              </h3>
            </div>
            <div className="text-2xl font-bold text-white mb-2">
              {item.value}
            </div>
            <p className="text-xs text-gray-400">
              {item.description}
            </p>
          </div>
        </AnimatedSection>
      ))}
    </div>
  );
};
