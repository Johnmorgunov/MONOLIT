import React from 'react';
import { AnimatedSection } from '../ui/AnimatedSection';
import { formatWorkingDaysText } from '../../utils/workingDays';
import type { Order } from '../../types/order';

interface OrderProgressChartProps {
  order: Order;
}

export const OrderProgressChart: React.FC<OrderProgressChartProps> = ({ order }) => {
  const totalStages = order.stages.length;
  const stageWidth = 100 / totalStages;

  return (
    <AnimatedSection>
      <div className="bg-dark-900/50 backdrop-blur-sm border border-gold-400/10 p-8">
        <h3 className="font-manrope text-xl font-medium text-white mb-6 text-center">
          График выполнения заказа
        </h3>

        {/* Progress Bar */}
        <div className="relative mb-8">
          <div className="w-full bg-gray-700 h-4 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-gold-400 to-green-400 transition-all duration-1000 ease-out"
              style={{ width: `${order.totalProgress}%` }}
            />
          </div>
          
          {/* Stage Markers */}
          <div className="absolute top-0 w-full h-4 flex">
            {order.stages.map((stage, index) => (
              <div
                key={stage.id}
                className="relative border-r border-dark-950"
                style={{ width: `${stageWidth}%` }}
              >
                {/* Stage Marker */}
                <div
                  className={`
                    absolute -top-2 -right-2 w-8 h-8 rounded-full border-2 flex items-center justify-center text-xs font-bold
                    ${stage.status === 'completed' 
                      ? 'bg-green-400 border-green-400 text-black' 
                      : stage.status === 'current' || stage.status === 'in-progress'
                      ? 'bg-gold-400 border-gold-400 text-black'
                      : 'bg-gray-600 border-gray-600 text-white'
                    }
                  `}
                >
                  {index + 1}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Stage Labels */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {order.stages.map((stage, index) => (
            <div key={stage.id} className="text-center">
              <div className={`
                text-xs font-medium mb-1
                ${stage.status === 'completed' 
                  ? 'text-green-400' 
                  : stage.status === 'current' || stage.status === 'in-progress'
                  ? 'text-gold-400'
                  : 'text-gray-400'
                }
              `}>
                {stage.title}
              </div>
              <div className="text-xs text-gray-500 mb-1">
                {Math.round(((index + 1) / totalStages) * 100)}%
              </div>
              <div className="text-xs text-gray-600">
                {formatWorkingDaysText(stage.estimatedDuration)}
              </div>
            </div>
          ))}
        </div>

        {/* Progress Summary */}
        <div className="mt-8 text-center">
          <div className="text-3xl font-bold text-white mb-2">
            {Math.round(order.totalProgress)}%
          </div>
          <p className="text-gray-300 mb-2">
            Ваш заказ выполнен на {Math.round(order.totalProgress)}% от общего объема работ
          </p>
          <p className="text-sm text-gray-400">
            * Все сроки указаны в рабочих днях (понедельник-пятница, исключая праздники)
          </p>
        </div>
      </div>
    </AnimatedSection>
  );
};
