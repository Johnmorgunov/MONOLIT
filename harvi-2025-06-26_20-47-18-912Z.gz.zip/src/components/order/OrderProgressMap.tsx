import React from 'react';
import { CheckCircle, Clock, Circle, ArrowRight, Check, X } from 'lucide-react';
import { AnimatedSection } from '../ui/AnimatedSection';
import { Button } from '../ui/Button';
import { formatWorkingDaysText } from '../../utils/workingDays';
import type { OrderStage } from '../../types/order';

interface OrderProgressMapProps {
  stages: OrderStage[];
  onStageClick?: (stageId: string) => void;
  onMarkComplete?: (stageId: string) => void;
  onUnmarkComplete?: (stageId: string) => void;
  isEditable?: boolean;
}

export const OrderProgressMap: React.FC<OrderProgressMapProps> = ({
  stages,
  onStageClick,
  onMarkComplete,
  onUnmarkComplete,
  isEditable = false
}) => {
  const getStageIcon = (status: OrderStage['status']) => {
    switch (status) {
      case 'completed':
        return <CheckCircle size={24} className="text-green-400" />;
      case 'current':
      case 'in-progress':
        return <Clock size={24} className="text-gold-400" />;
      default:
        return <Circle size={24} className="text-gray-500" />;
    }
  };

  const getStageStyles = (status: OrderStage['status']) => {
    switch (status) {
      case 'completed':
        return 'border-green-400 bg-green-400/10';
      case 'current':
      case 'in-progress':
        return 'border-gold-400 bg-gold-400/10';
      default:
        return 'border-gray-600 bg-dark-800/50';
    }
  };

  return (
    <div className="space-y-6">
      {stages.map((stage, index) => (
        <AnimatedSection key={stage.id}>
          <div className="flex items-center">
            {/* Stage Card */}
            <div
              className={`
                flex-1 p-6 border-2 transition-all duration-300 cursor-pointer
                hover:scale-[1.02] hover:shadow-lg
                ${getStageStyles(stage.status)}
                ${onStageClick ? 'hover:border-gold-400/50' : ''}
              `}
              onClick={() => onStageClick?.(stage.id)}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  {getStageIcon(stage.status)}
                  <div className="flex-1">
                    <h3 className="font-manrope text-lg font-medium text-white mb-1">
                      {stage.title}
                    </h3>
                    <p className="text-gray-300 text-sm mb-2">
                      {stage.description}
                    </p>
                    <div className="flex flex-wrap items-center gap-4 text-xs text-gray-400">
                      <span>Длительность: {formatWorkingDaysText(stage.estimatedDuration)}</span>
                      {stage.estimatedStartDate && (
                        <span>
                          Планируемое начало: {stage.estimatedStartDate.toLocaleDateString('ru-RU')}
                        </span>
                      )}
                      {stage.estimatedEndDate && (
                        <span>
                          Планируемое завершение: {stage.estimatedEndDate.toLocaleDateString('ru-RU')}
                        </span>
                      )}
                      {stage.isFlexibleTiming && (
                        <span className="text-blue-400">Гибкий график</span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Progress and Actions */}
                <div className="text-right flex flex-col items-end space-y-2">
                  <div className="text-2xl font-bold text-white mb-1">
                    {Math.round(((index + 1) / stages.length) * 100)}%
                  </div>
                  <div className="text-xs text-gray-400 mb-2">
                    Этап {index + 1} из {stages.length}
                  </div>
                  
                  {/* Action Buttons */}
                  {isEditable && (
                    <div className="flex flex-col gap-2">
                      {/* Mark Complete Button */}
                      {stage.canMarkComplete && stage.status !== 'completed' && (
                        <Button
                          variant="primary"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            onMarkComplete?.(stage.id);
                          }}
                          className="flex items-center space-x-1 text-xs"
                        >
                          <Check size={14} />
                          <span>Отметить выполненным</span>
                        </Button>
                      )}
                      
                      {/* Unmark Complete Button */}
                      {stage.canUnmarkComplete && stage.status === 'completed' && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            onUnmarkComplete?.(stage.id);
                          }}
                          className="flex items-center space-x-1 text-xs border-red-500 text-red-400 hover:bg-red-500 hover:text-white"
                        >
                          <X size={14} />
                          <span>Отменить выполнение</span>
                        </Button>
                      )}
                    </div>
                  )}
                </div>
              </div>

              {/* Stage Progress Bar */}
              {(stage.status === 'current' || stage.status === 'in-progress') && (
                <div className="mt-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs text-gray-400">Прогресс этапа</span>
                    <span className="text-xs text-gold-400">{stage.progress}%</span>
                  </div>
                  <div className="w-full bg-gray-700 h-2 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gold-400 transition-all duration-500"
                      style={{ width: `${stage.progress}%` }}
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Arrow Connector */}
            {index < stages.length - 1 && (
              <div className="flex items-center justify-center w-12">
                <ArrowRight 
                  size={20} 
                  className={`
                    ${stage.status === 'completed' ? 'text-green-400' : 'text-gray-500'}
                  `} 
                />
              </div>
            )}
          </div>
        </AnimatedSection>
      ))}
    </div>
  );
};
