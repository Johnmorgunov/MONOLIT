import React, { useState } from 'react';
import { Search, Phone, AlertCircle } from 'lucide-react';
import { Button } from '../ui/Button';
import { LoadingSpinner } from '../ui/LoadingSpinner';
import { adminService } from '../../services/adminService';
import type { Order } from '../../types/order';

interface OrderSearchProps {
  onOrderFound: (orders: Order[]) => void;
  onError: (error: string) => void;
}

export const OrderSearch: React.FC<OrderSearchProps> = ({ onOrderFound, onError }) => {
  const [searchValue, setSearchValue] = useState('');
  const [isSearching, setIsSearching] = useState(false);

  const handleSearch = async () => {
    if (!searchValue.trim()) {
      onError('Введите номер телефона или номер заказа');
      return;
    }

    setIsSearching(true);
    
    try {
      let orders: Order[] = [];
      
      // Определяем тип поиска
      if (searchValue.includes('MNL-') || searchValue.includes('mnl-')) {
        // Поиск по номеру заказа
        const order = await adminService.getOrderByNumber(searchValue.toUpperCase());
        if (order) {
          orders = [order];
        }
      } else {
        // Поиск по телефону
        orders = await adminService.getOrderByPhone(searchValue);
      }

      if (orders.length === 0) {
        onError('Заказы не найдены. Проверьте правильность введенных данных.');
      } else {
        onOrderFound(orders);
      }
    } catch (error) {
      onError('Ошибка поиска. Попробуйте еще раз.');
    } finally {
      setIsSearching(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };

  return (
    <div className="bg-dark-900/50 backdrop-blur-sm border border-gold-400/10 p-8">
      <div className="max-w-2xl mx-auto">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-gold-400 rounded-full flex items-center justify-center mx-auto mb-4">
            <Search size={32} className="text-black" />
          </div>
          <h2 className="font-manrope text-2xl font-medium text-white mb-4">
            Найти заказ
          </h2>
          <p className="text-gray-300">
            Введите номер телефона или номер заказа для отслеживания
          </p>
        </div>

        <div className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-white mb-2">
              Номер телефона или номер заказа
            </label>
            <div className="relative">
              <div className="absolute left-3 top-1/2 -translate-y-1/2">
                {searchValue.includes('MNL-') || searchValue.includes('mnl-') ? (
                  <Search size={20} className="text-gray-400" />
                ) : (
                  <Phone size={20} className="text-gray-400" />
                )}
              </div>
              <input
                type="text"
                value={searchValue}
                onChange={(e) => setSearchValue(e.target.value)}
                onKeyPress={handleKeyPress}
                className="w-full pl-12 pr-4 py-4 bg-dark-800 border border-gray-600 text-white focus:outline-none focus:border-gold-400 transition-colors duration-300"
                placeholder="+7 (999) 123-45-67 или MNL-2025-001"
              />
            </div>
          </div>

          <Button
            variant="primary"
            size="lg"
            onClick={handleSearch}
            disabled={isSearching || !searchValue.trim()}
            className="w-full flex items-center justify-center space-x-2"
          >
            {isSearching ? (
              <>
                <LoadingSpinner size="sm" />
                <span>Поиск...</span>
              </>
            ) : (
              <>
                <Search size={20} />
                <span>Найти заказ</span>
              </>
            )}
          </Button>

          <div className="bg-blue-900/20 border border-blue-500/30 p-4 rounded">
            <div className="flex items-start space-x-3">
              <AlertCircle size={20} className="text-blue-400 flex-shrink-0 mt-0.5" />
              <div className="text-blue-300 text-sm">
                <p className="font-medium mb-2">Способы поиска:</p>
                <ul className="space-y-1 text-xs">
                  <li>• По номеру телефона: введите полный или частичный номер</li>
                  <li>• По номеру заказа: введите номер в формате MNL-2025-XXX</li>
                  <li>• Поиск работает для всех заказов в системе</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
