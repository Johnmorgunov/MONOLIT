import React from 'react';
import { Package, Phone, Mail, Calendar, ArrowRight } from 'lucide-react';
import { Button } from '../ui/Button';
import { AnimatedSection } from '../ui/AnimatedSection';
import { collections } from '../../data/collections';
import type { Order } from '../../types/order';

interface OrderSearchResultsProps {
  orders: Order[];
  onSelectOrder: (order: Order) => void;
  onNewSearch: () => void;
}

export const OrderSearchResults: React.FC<OrderSearchResultsProps> = ({
  orders,
  onSelectOrder,
  onNewSearch
}) => {
  const getCollectionName = (collectionId: string) => {
    const collection = collections.find(c => c.id === collectionId);
    return collection?.title || collectionId;
  };

  const getStatusColor = (progress: number) => {
    if (progress === 0) return 'text-gray-400';
    if (progress === 100) return 'text-green-400';
    return 'text-gold-400';
  };

  const getStatusText = (progress: number) => {
    if (progress === 0) return 'Ожидает начала';
    if (progress === 100) return 'Завершен';
    return 'В работе';
  };

  return (
    <div className="space-y-6">
      <AnimatedSection>
        <div className="text-center mb-8">
          <h2 className="font-manrope text-2xl font-medium text-white mb-4">
            Найденные заказы ({orders.length})
          </h2>
          <Button
            variant="outline"
            onClick={onNewSearch}
            className="text-sm"
          >
            Новый поиск
          </Button>
        </div>
      </AnimatedSection>

      <div className="space-y-4">
        {orders.map((order) => (
          <AnimatedSection key={order.id}>
            <div className="bg-dark-900/50 backdrop-blur-sm border border-gold-400/10 p-6 hover:border-gold-400/30 transition-all duration-300">
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-4">
                    <Package size={20} className="text-gold-400" />
                    <h3 className="font-manrope text-lg font-medium text-white">
                      Заказ {order.orderNumber}
                    </h3>
                    <span className={`text-sm font-medium ${getStatusColor(order.totalProgress)}`}>
                      {getStatusText(order.totalProgress)}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
                    <div>
                      <p className="text-xs text-gray-400 mb-1">Клиент</p>
                      <p className="text-white font-medium">{order.customerName}</p>
                    </div>
                    
                    <div>
                      <p className="text-xs text-gray-400 mb-1">Коллекция</p>
                      <p className="text-white">{getCollectionName(order.collectionId)}</p>
                    </div>
                    
                    <div>
                      <p className="text-xs text-gray-400 mb-1">Дата создания</p>
                      <div className="flex items-center text-white">
                        <Calendar size={14} className="mr-1" />
                        {order.createdDate.toLocaleDateString('ru-RU')}
                      </div>
                    </div>
                    
                    <div>
                      <p className="text-xs text-gray-400 mb-1">Контакты</p>
                      <div className="space-y-1">
                        <div className="flex items-center text-white text-sm">
                          <Phone size={12} className="mr-1" />
                          {order.customerPhone}
                        </div>
                        {order.customerEmail && (
                          <div className="flex items-center text-white text-sm">
                            <Mail size={12} className="mr-1" />
                            {order.customerEmail}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Progress Bar */}
                  <div className="mb-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm text-gray-400">Общий прогресс</span>
                      <span className="text-sm text-gold-400">{Math.round(order.totalProgress)}%</span>
                    </div>
                    <div className="w-full bg-gray-700 h-2 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gold-400 transition-all duration-500"
                        style={{ width: `${order.totalProgress}%` }}
                      />
                    </div>
                  </div>

                  {/* Current Stage */}
                  <div className="mb-4">
                    <p className="text-xs text-gray-400 mb-1">Текущий этап</p>
                    <p className="text-white">
                      {order.stages.find(s => s.status === 'current')?.title || 
                       order.stages.find(s => s.status === 'in-progress')?.title || 
                       'Все этапы завершены'}
                    </p>
                  </div>
                </div>

                <div className="ml-6">
                  <Button
                    variant="primary"
                    onClick={() => onSelectOrder(order)}
                    className="flex items-center space-x-2"
                  >
                    <span>Подробнее</span>
                    <ArrowRight size={16} />
                  </Button>
                </div>
              </div>
            </div>
          </AnimatedSection>
        ))}
      </div>
    </div>
  );
};
