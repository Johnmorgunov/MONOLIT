import React from 'react';
import { SectionTitle } from '../ui/SectionTitle';
import { AnimatedSection } from '../ui/AnimatedSection';

export const About: React.FC = () => {
  return (
    <section id="about" className="py-20 lg:py-32 bg-dark-900">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <AnimatedSection>
            <SectionTitle>Идея MONOLIT</SectionTitle>
          </AnimatedSection>

          <div className="space-y-8">
            <AnimatedSection>
              <p className="text-lg lg:text-xl text-gray-300 leading-relaxed font-light">
                Мы создаем кухни, где премиальное качество встречается с разумной ценой. 
                Наш секрет — в идеальном балансе между роскошными материалами, 
                индивидуальным подходом и эффективным модульным производством.
              </p>
            </AnimatedSection>

            <AnimatedSection>
              <p className="text-lg lg:text-xl text-gray-300 leading-relaxed font-light">
                MONOLIT — это не просто кухни, это умный подход к созданию пространства, 
                где каждая деталь продумана, а цена оптимизирована без ущерба для качества.
              </p>
            </AnimatedSection>
          </div>
        </div>
      </div>
    </section>
  );
};
