import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { SectionTitle } from '../ui/SectionTitle';
import { AnimatedSection } from '../ui/AnimatedSection';
import { OptimizedImage } from '../ui/OptimizedImage';
import { Button } from '../ui/Button';
import { collections } from '../../data/collections';

export const Collections: React.FC = () => {
  return (
    <section id="collections" className="py-20 lg:py-32 bg-dark-800">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <AnimatedSection>
            <SectionTitle>Наши коллекции</SectionTitle>
          </AnimatedSection>

          <AnimatedSection>
            <p className="text-lg text-gray-300 max-w-4xl mx-auto leading-relaxed font-light mb-8">
              Каждая коллекция создается с учетом современных тенденций и технологий производства, 
              что позволяет нам предлагать премиальное качество по конкурентной цене.
            </p>
          </AnimatedSection>

          <AnimatedSection>
            <Link to="/collections">
              <Button variant="outline" size="lg" className="mb-12">
                Посмотреть все коллекции
              </Button>
            </Link>
          </AnimatedSection>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 lg:gap-12">
          {collections.map((collection, index) => (
            <AnimatedSection key={collection.id} className="group">
              <Link to={`/collection/${collection.slug}`}>
                <div className="relative overflow-hidden bg-dark-900 shadow-2xl hover:shadow-3xl transition-all duration-500 hover:scale-[1.02] cursor-pointer rounded-xl">
                  <OptimizedImage
                    src={collection.image}
                    alt={collection.title}
                    className="aspect-[4/5] group-hover:scale-110 transition-transform duration-700 rounded-xl"
                    loading={index === 0 ? 'eager' : 'lazy'}
                    aspectRatio="4/5"
                  />
                  
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent group-hover:from-black/95 transition-all duration-500 rounded-xl"></div>
                  
                  <div className="absolute bottom-0 left-0 right-0 p-6 lg:p-8 text-white">
                    <h3 className="font-manrope text-2xl lg:text-3xl font-semibold mb-3 text-white group-hover:text-gold-400 transition-colors duration-300 drop-shadow-lg">
                      {collection.title}
                    </h3>
                    <p className="text-gray-100 mb-6 font-light leading-relaxed text-base drop-shadow-md">
                      {collection.description}
                    </p>
                    <div className="flex items-center justify-between">
                      <div className="bg-gold-400 text-black px-4 py-2 font-semibold text-sm uppercase tracking-wider rounded-lg shadow-lg">
                        {collection.price}
                      </div>
                      <div className="flex items-center text-gold-400 group-hover:text-white transition-colors duration-300">
                        <span className="text-sm font-medium uppercase tracking-wider mr-2 drop-shadow-md">Подробнее</span>
                        <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform duration-300 drop-shadow-md" />
                      </div>
                    </div>
                  </div>
                </div>
              </Link>
            </AnimatedSection>
          ))}
        </div>
      </div>
    </section>
  );
};
