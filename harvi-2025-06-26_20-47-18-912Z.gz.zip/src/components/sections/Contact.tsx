import React, { useState } from 'react';
import { MessageCircle, MapPin, Phone, Mail, ArrowRight, Send } from 'lucide-react';
import { Link } from 'react-router-dom';
import { SectionTitle } from '../ui/SectionTitle';
import { AnimatedSection } from '../ui/AnimatedSection';
import { Button } from '../ui/Button';
import { ConsentModal } from '../ui/ConsentModal';

export const Contact: React.FC = () => {
  const [consentModal, setConsentModal] = useState<{
    isOpen: boolean;
    type: 'consultation' | 'messenger' | 'telegram';
  }>({ isOpen: false, type: 'consultation' });

  const handleMessengerClick = () => {
    setConsentModal({ isOpen: true, type: 'messenger' });
  };

  const handleTelegramClick = () => {
    setConsentModal({ isOpen: true, type: 'telegram' });
  };

  const handleConsentConfirm = () => {
    if (consentModal.type === 'messenger') {
      window.open('https://wa.me/78005553535');
    } else if (consentModal.type === 'telegram') {
      window.open('https://t.me/monolit_kitchen');
    }
  };

  const closeConsentModal = () => {
    setConsentModal({ isOpen: false, type: 'consultation' });
  };

  return (
    <section id="contact" className="py-20 lg:py-32 bg-dark-800">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <AnimatedSection>
            <SectionTitle>Один шаг к вашей кухне</SectionTitle>
          </AnimatedSection>
        </div>

        <div className="max-w-2xl mx-auto text-center">
          <AnimatedSection>
            <p className="text-xl lg:text-2xl text-gray-200 mb-12 font-light">
              Узнайте, как премиальное качество может быть доступным
            </p>
          </AnimatedSection>

          <AnimatedSection>
            <div className="mb-12">
              <Link to="/collections">
                <Button
                  variant="primary"
                  size="lg"
                  className="inline-flex items-center space-x-2 mb-8"
                >
                  <span>Шаг вперед</span>
                  <ArrowRight size={20} />
                </Button>
              </Link>
            </div>
          </AnimatedSection>

          <div className="space-y-6 mb-12">
            <AnimatedSection className="flex items-center justify-center space-x-4">
              <MapPin className="text-gold-400 flex-shrink-0" size={24} />
              <p className="text-lg text-gray-300">г. Калининград, ул. Выдуманная, 15А</p>
            </AnimatedSection>

            <AnimatedSection className="flex items-center justify-center space-x-4">
              <Phone className="text-gold-400 flex-shrink-0" size={24} />
              <a 
                href="tel:+78005553535" 
                className="text-lg text-gray-300 hover:text-gold-400 transition-colors duration-300"
              >
                +7 (800) 555-35-35
              </a>
            </AnimatedSection>

            <AnimatedSection className="flex items-center justify-center space-x-4">
              <Mail className="text-gold-400 flex-shrink-0" size={24} />
              <a 
                href="mailto:info@monolit.ru" 
                className="text-lg text-gray-300 hover:text-gold-400 transition-colors duration-300"
              >
                info@monolit.ru
              </a>
            </AnimatedSection>
          </div>

          <AnimatedSection>
            <div className="flex justify-center space-x-4">
              <button
                onClick={handleMessengerClick}
                className="group flex items-center justify-center w-16 h-16 border-2 border-gold-400 rounded-full text-gold-400 hover:bg-gold-400 hover:text-black transition-all duration-300 hover:scale-110 hover:shadow-lg hover:shadow-gold-400/25"
                aria-label="Написать в WhatsApp"
              >
                <MessageCircle size={24} />
              </button>
              
              <button
                onClick={handleTelegramClick}
                className="group flex items-center justify-center w-16 h-16 border-2 border-gold-400 rounded-full text-gold-400 hover:bg-gold-400 hover:text-black transition-all duration-300 hover:scale-110 hover:shadow-lg hover:shadow-gold-400/25"
                aria-label="Написать в Telegram"
              >
                <Send size={24} />
              </button>
            </div>
          </AnimatedSection>
        </div>
      </div>

      {/* Consent Modal */}
      <ConsentModal
        isOpen={consentModal.isOpen}
        onClose={closeConsentModal}
        type={consentModal.type}
        onConfirm={handleConsentConfirm}
      />
    </section>
  );
};
