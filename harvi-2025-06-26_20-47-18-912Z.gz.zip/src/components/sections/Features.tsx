import React from 'react';
import { 
  Tag, 
  Gem, 
  Settings, 
  Clock, 
  Puzzle, 
  Award,
  LucideIcon
} from 'lucide-react';
import { SectionTitle } from '../ui/SectionTitle';
import { AnimatedSection } from '../ui/AnimatedSection';
import { features } from '../../data/features';

const iconMap: Record<string, LucideIcon> = {
  Tag,
  Gem,
  Settings,
  Clock,
  PuzzleIcon: Puzzle,
  Award,
};

export const Features: React.FC = () => {
  return (
    <section id="features" className="py-20 lg:py-32 bg-dark-950">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <AnimatedSection>
            <SectionTitle>Почему MONOLIT — это выгодно</SectionTitle>
          </AnimatedSection>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 lg:gap-12">
          {features.map((feature, index) => {
            const IconComponent = iconMap[feature.icon];
            
            return (
              <AnimatedSection key={feature.id} className="group">
                <div className="bg-dark-900/50 backdrop-blur-sm border border-gold-400/10 p-8 lg:p-10 text-center hover:border-gold-400/30 hover:bg-dark-900/70 transition-all duration-500 hover:scale-[1.02] hover:shadow-xl hover:shadow-gold-400/5">
                  <div className="mb-6">
                    {IconComponent && (
                      <IconComponent 
                        size={48} 
                        className="text-gold-400 mx-auto group-hover:scale-110 transition-transform duration-300" 
                      />
                    )}
                  </div>
                  
                  <h3 className="font-manrope text-xl lg:text-2xl font-medium text-white mb-4 group-hover:text-gold-400 transition-colors duration-300">
                    {feature.title}
                  </h3>
                  
                  <p className="text-gray-300 leading-relaxed font-light">
                    {feature.description}
                  </p>
                </div>
              </AnimatedSection>
            );
          })}
        </div>
      </div>
    </section>
  );
};
