import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '../ui/Button';
import { AnimatedSection } from '../ui/AnimatedSection';

export const Hero: React.FC = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: 'url(https://www.gaudino.it/shared/2019/07/046-cucine-gaudino-modulnova.jpg)'
        }}
      >
        {/* Overlay */}
        <div className="absolute inset-0 bg-black/60"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 sm:px-6 lg:px-8 text-center lg:text-left">
        <div className="max-w-4xl mx-auto lg:mx-0">
          <AnimatedSection animation="slideInLeft">
            <h1 className="font-manrope text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-medium text-white mb-6 lg:mb-8 leading-tight">
              <span className="text-gold-400">Премиальные кухни</span>
              <br />
              по оптимальной цене
            </h1>
          </AnimatedSection>

          <AnimatedSection className="mb-6 lg:mb-8">
            <div className="inline-block bg-gold-400/20 border-l-4 border-gold-400 px-6 py-4 mb-6 backdrop-blur-sm">
              <p className="text-white font-medium text-lg">
                На 30% доступнее традиционных кухонь за счет модульной системы
              </p>
            </div>
          </AnimatedSection>

          <AnimatedSection className="mb-8 lg:mb-12">
            <p className="text-lg lg:text-xl text-gray-200 max-w-3xl mx-auto lg:mx-0 leading-relaxed font-light">
              MONOLIT делает комфорт доступнее — мы предлагаем кухни премиум-класса по разумной цене 
              благодаря инновационному модульному подходу и оптимизированному производству.
            </p>
          </AnimatedSection>

          <AnimatedSection>
            <Link to="/collections">
              <Button
                variant="outline"
                size="lg"
                className="hover:scale-105 transform transition-transform duration-300"
              >
                Выбрать кухню
              </Button>
            </Link>
          </AnimatedSection>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-white/50 rounded-full flex justify-center">
          <div className="w-1 h-3 bg-white/50 rounded-full mt-2 animate-pulse"></div>
        </div>
      </div>
    </section>
  );
};