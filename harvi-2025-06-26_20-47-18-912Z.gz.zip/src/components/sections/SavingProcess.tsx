import React from 'react';
import { SectionTitle } from '../ui/SectionTitle';
import { AnimatedSection } from '../ui/AnimatedSection';
import { processSteps } from '../../data/processSteps';

export const SavingProcess: React.FC = () => {
  return (
    <section id="saving" className="py-20 lg:py-32 bg-dark-900">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <AnimatedSection>
            <SectionTitle>Как мы оптимизируем цену?</SectionTitle>
          </AnimatedSection>

          <AnimatedSection>
            <p className="text-lg text-gray-300 max-w-4xl mx-auto leading-relaxed font-light">
              Наш подход к производству позволяет предложить вам кухни премиум-класса по доступной цене:
            </p>
          </AnimatedSection>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-6">
          {processSteps.map((step, index) => (
            <AnimatedSection key={step.id} className="group">
              <div className="relative bg-dark-800/50 backdrop-blur-sm border border-gold-400/20 p-6 lg:p-8 text-center hover:bg-dark-800/70 hover:border-gold-400/40 transition-all duration-500 hover:scale-[1.02]">
                {/* Step Number */}
                <div className="absolute -top-5 left-1/2 transform -translate-x-1/2">
                  <div className="w-10 h-10 bg-gold-400 text-black rounded-full flex items-center justify-center font-bold text-lg group-hover:scale-110 transition-transform duration-300">
                    {step.number}
                  </div>
                </div>

                <div className="pt-6">
                  <h3 className="font-manrope text-lg lg:text-xl font-medium text-white mb-4 group-hover:text-gold-400 transition-colors duration-300">
                    {step.title}
                  </h3>
                  
                  <p className="text-gray-300 text-sm lg:text-base leading-relaxed font-light">
                    {step.description}
                  </p>
                </div>

                {/* Connection Line for Desktop */}
                {index < processSteps.length - 1 && (
                  <div className="hidden lg:block absolute top-1/2 -right-3 w-6 h-px bg-gold-400/30"></div>
                )}
              </div>
            </AnimatedSection>
          ))}
        </div>
      </div>
    </section>
  );
};
