import React from 'react';
import { useScrollAnimation } from '../../hooks/useScrollAnimation';

interface AnimatedSectionProps {
  children: React.ReactNode;
  className?: string;
  animation?: 'fadeInUp' | 'slideInLeft';
}

export const AnimatedSection: React.FC<AnimatedSectionProps> = ({
  children,
  className = '',
  animation = 'fadeInUp'
}) => {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section
      ref={ref}
      className={`
        transition-all duration-800 ease-out
        ${isVisible ? 'opacity-100 translate-y-0 translate-x-0' : 'opacity-0'}
        ${animation === 'fadeInUp' && !isVisible ? 'translate-y-8' : ''}
        ${animation === 'slideInLeft' && !isVisible ? '-translate-x-12' : ''}
        ${className}
      `}
    >
      {children}
    </section>
  );
};
