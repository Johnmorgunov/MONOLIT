import React from 'react';

interface ButtonProps {
  children: React.ReactNode;
  variant?: 'primary' | 'secondary' | 'outline';
  size?: 'sm' | 'md' | 'lg';
  onClick?: () => void;
  className?: string;
  href?: string;
  disabled?: boolean;
}

export const Button: React.FC<ButtonProps> = ({
  children,
  variant = 'primary',
  size = 'md',
  onClick,
  className = '',
  href,
  disabled = false
}) => {
  const baseClasses = 'inline-block font-medium transition-all duration-300 text-center uppercase tracking-wider';
  
  const variantClasses = {
    primary: 'bg-gold-400 text-black hover:bg-gold-500 hover:shadow-lg hover:shadow-gold-400/25',
    secondary: 'bg-white text-black hover:bg-gray-100',
    outline: 'border border-gold-400 text-white hover:bg-gold-400 hover:text-black hover:shadow-lg hover:shadow-gold-400/25'
  };

  const sizeClasses = {
    sm: 'px-4 py-2 text-sm',
    md: 'px-8 py-4 text-sm',
    lg: 'px-10 py-5 text-base'
  };

  const disabledClasses = disabled ? 'opacity-50 cursor-not-allowed' : '';

  const classes = `${baseClasses} ${variantClasses[variant]} ${sizeClasses[size]} ${disabledClasses} ${className}`;

  if (href) {
    return (
      <a href={href} className={classes}>
        {children}
      </a>
    );
  }

  return (
    <button onClick={onClick} className={classes} disabled={disabled}>
      {children}
    </button>
  );
};
