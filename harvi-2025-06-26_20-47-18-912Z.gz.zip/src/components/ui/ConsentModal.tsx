import React, { useState } from 'react';
import { X, Phone, MessageCircle, Send } from 'lucide-react';
import { Button } from './Button';
import { DataProcessingConsent } from './DataProcessingConsent';
import type { DataProcessingConsent as ConsentType } from '../../types';

interface ConsentModalProps {
  isOpen: boolean;
  onClose: () => void;
  type: 'consultation' | 'messenger' | 'telegram';
  onConfirm: () => void;
  collectionId?: string;
}

export const ConsentModal: React.FC<ConsentModalProps> = ({
  isOpen,
  onClose,
  type,
  onConfirm,
  collectionId
}) => {
  const [isConsentGiven, setIsConsentGiven] = useState(false);

  if (!isOpen) return null;

  const handleConfirm = () => {
    if (!isConsentGiven) return;

    // Сохраняем согласие
    const consent: ConsentType = {
      id: `${type}_${Date.now()}`,
      type,
      timestamp: new Date(),
      userAgent: navigator.userAgent,
      collectionId
    };

    const existingConsents = JSON.parse(localStorage.getItem('dataProcessingConsents') || '[]');
    existingConsents.push(consent);
    localStorage.setItem('dataProcessingConsents', JSON.stringify(existingConsents));

    onConfirm();
    onClose();
    setIsConsentGiven(false);
  };

  const getModalContent = () => {
    switch (type) {
      case 'consultation':
        return {
          title: 'Заказ консультации',
          description: 'Для заказа консультации нам необходимо ваше согласие на обработку персональных данных. Мы используем эти данные исключительно для связи с вами и предоставления услуг.',
          icon: <Phone size={24} className="text-gold-400" />,
          actionText: 'Заказать консультацию'
        };
      case 'messenger':
        return {
          title: 'Переход в WhatsApp',
          description: 'Для перехода в WhatsApp и дальнейшего общения нам необходимо ваше согласие на обработку персональных данных в рамках предоставления консультационных услуг.',
          icon: <MessageCircle size={24} className="text-gold-400" />,
          actionText: 'Перейти в WhatsApp'
        };
      case 'telegram':
        return {
          title: 'Переход в Telegram',
          description: 'Для перехода в Telegram и дальнейшего общения нам необходимо ваше согласие на обработку персональных данных в рамках предоставления консультационных услуг.',
          icon: <Send size={24} className="text-gold-400" />,
          actionText: 'Перейти в Telegram'
        };
      default:
        return {
          title: 'Согласие на обработку данных',
          description: 'Необходимо ваше согласие на обработку персональных данных.',
          icon: null,
          actionText: 'Продолжить'
        };
    }
  };

  const content = getModalContent();

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-dark-900 border border-gold-400/20 max-w-md w-full p-6 relative rounded-xl">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-white transition-colors duration-300"
          aria-label="Закрыть"
        >
          <X size={20} />
        </button>

        {/* Header */}
        <div className="flex items-center space-x-3 mb-6">
          {content.icon}
          <h2 className="font-manrope text-xl font-medium text-white">
            {content.title}
          </h2>
        </div>

        {/* Description */}
        <p className="text-gray-300 mb-6 leading-relaxed">
          {content.description}
        </p>

        {/* Consent Checkbox */}
        <div className="mb-6">
          <DataProcessingConsent
            isChecked={isConsentGiven}
            onChange={setIsConsentGiven}
            required={true}
          />
        </div>

        {/* Actions */}
        <div className="flex flex-col sm:flex-row gap-3">
          <Button
            variant="outline"
            onClick={onClose}
            className="flex-1"
          >
            Отмена
          </Button>
          <Button
            variant="primary"
            onClick={handleConfirm}
            disabled={!isConsentGiven}
            className={`flex-1 ${!isConsentGiven ? 'opacity-50 cursor-not-allowed' : ''}`}
          >
            {content.actionText}
          </Button>
        </div>
      </div>
    </div>
  );
};
