import React from 'react';

interface DataProcessingConsentProps {
  isChecked: boolean;
  onChange: (checked: boolean) => void;
  className?: string;
  required?: boolean;
}

export const DataProcessingConsent: React.FC<DataProcessingConsentProps> = ({
  isChecked,
  onChange,
  className = '',
  required = true
}) => {
  return (
    <div className={`flex items-start space-x-3 ${className}`}>
      <div className="flex-shrink-0 mt-1">
        <label className="relative inline-flex items-center cursor-pointer">
          <input
            type="checkbox"
            checked={isChecked}
            onChange={(e) => onChange(e.target.checked)}
            className="sr-only"
            required={required}
          />
          <div className={`
            w-5 h-5 border-2 transition-all duration-300
            ${isChecked 
              ? 'border-gold-400 bg-gold-400' 
              : 'border-gray-400 hover:border-gold-400/50'
            }
          `}>
            {isChecked && (
              <svg 
                className="w-3 h-3 text-black mx-auto mt-0.5" 
                fill="currentColor" 
                viewBox="0 0 20 20"
              >
                <path 
                  fillRule="evenodd" 
                  d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" 
                  clipRule="evenodd" 
                />
              </svg>
            )}
          </div>
        </label>
      </div>
      <div className="text-sm text-gray-300 leading-relaxed">
        <span>Я согласен(а) на </span>
        <button
          type="button"
          className="text-gold-400 hover:text-gold-300 underline transition-colors duration-300"
          onClick={() => window.open('/privacy-policy', '_blank')}
        >
          обработку персональных данных
        </button>
        <span> в соответствии с политикой конфиденциальности</span>
        {required && <span className="text-gold-400 ml-1">*</span>}
      </div>
    </div>
  );
};
