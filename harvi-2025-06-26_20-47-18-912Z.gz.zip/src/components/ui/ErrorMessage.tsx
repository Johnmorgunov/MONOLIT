import React from 'react';
import { AlertCircle } from 'lucide-react';

interface ErrorMessageProps {
  message: string;
  className?: string;
  onRetry?: () => void;
}

export const ErrorMessage: React.FC<ErrorMessageProps> = ({ 
  message, 
  className = '',
  onRetry 
}) => {
  return (
    <div className={`flex items-center space-x-3 p-4 bg-red-900/20 border border-red-500/30 text-red-300 ${className}`}>
      <AlertCircle size={20} className="flex-shrink-0" />
      <div className="flex-1">
        <p className="text-sm">{message}</p>
        {onRetry && (
          <button
            onClick={onRetry}
            className="mt-2 text-xs text-red-400 hover:text-red-300 underline transition-colors duration-300"
          >
            Попробовать снова
          </button>
        )}
      </div>
    </div>
  );
};
