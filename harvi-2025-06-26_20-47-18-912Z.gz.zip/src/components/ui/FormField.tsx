import React from 'react';
import { ErrorMessage } from './ErrorMessage';

interface FormFieldProps {
  label: string;
  error?: string | null;
  required?: boolean;
  children: React.ReactNode;
  className?: string;
}

export const FormField: React.FC<FormFieldProps> = ({
  label,
  error,
  required = false,
  children,
  className = ''
}) => {
  return (
    <div className={`space-y-2 ${className}`}>
      <label className="block text-sm font-medium text-white">
        {label}
        {required && <span className="text-gold-400 ml-1">*</span>}
      </label>
      {children}
      {error && (
        <ErrorMessage message={error} className="text-xs p-2" />
      )}
    </div>
  );
};
