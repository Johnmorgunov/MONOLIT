import React from 'react';

interface SectionTitleProps {
  children: React.ReactNode;
  className?: string;
  centered?: boolean;
}

export const SectionTitle: React.FC<SectionTitleProps> = ({
  children,
  className = '',
  centered = true
}) => {
  return (
    <h2 className={`
      font-manrope text-3xl md:text-4xl lg:text-5xl font-medium text-white mb-12 lg:mb-16
      ${centered ? 'text-center' : ''}
      relative inline-block
      after:content-[''] after:absolute after:-bottom-4 after:left-1/2 after:-translate-x-1/2 
      after:w-20 after:h-0.5 after:bg-gold-400
      ${className}
    `}>
      {children}
    </h2>
  );
};
