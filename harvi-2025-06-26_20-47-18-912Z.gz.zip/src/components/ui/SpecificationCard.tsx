import React from 'react';

interface SpecificationCardProps {
  title: string;
  items: string[];
  icon?: React.ReactNode;
}

export const SpecificationCard: React.FC<SpecificationCardProps> = ({
  title,
  items,
  icon
}) => {
  return (
    <div className="bg-dark-900/50 backdrop-blur-sm border border-gold-400/10 p-6 hover:border-gold-400/30 transition-all duration-300">
      <div className="flex items-center mb-4">
        {icon && <div className="text-gold-400 mr-3">{icon}</div>}
        <h3 className="font-manrope text-lg font-medium text-white">
          {title}
        </h3>
      </div>
      <ul className="space-y-2">
        {items.map((item, index) => (
          <li key={index} className="text-gray-300 text-sm font-light flex items-start">
            <span className="text-gold-400 mr-2 mt-1">•</span>
            {item}
          </li>
        ))}
      </ul>
    </div>
  );
};
