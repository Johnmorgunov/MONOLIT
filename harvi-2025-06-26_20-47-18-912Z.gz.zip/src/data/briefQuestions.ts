import type { BriefStep } from '../types';

export const briefSteps: BriefStep[] = [
  {
    id: 'layout',
    title: 'Планировка кухни',
    description: 'Выберите тип планировки и укажите габариты помещения',
    questions: [
      {
        id: 'layout_type',
        type: 'single',
        question: 'Выберите тип планировки кухни',
        description: 'Выберите наиболее подходящий тип планировки для вашего помещения',
        options: [
          { 
            id: 'linear', 
            label: 'Линейная', 
            description: 'Кухня вдоль одной стены',
            image: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=300&h=200&fit=crop'
          },
          { 
            id: 'corner', 
            label: 'Угловая (Г-образная)', 
            description: 'Г-образная планировка',
            image: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=300&h=200&fit=crop'
          },
          { 
            id: 'u_shaped', 
            label: 'П-образная', 
            description: 'Кухня вдоль трех стен',
            image: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=300&h=200&fit=crop'
          },
          { 
            id: 'island', 
            label: 'Островная', 
            description: 'С центральным островом',
            image: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=300&h=200&fit=crop'
          },
          { 
            id: 'peninsula', 
            label: 'Полуостровная', 
            description: 'С полуостровом',
            image: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=300&h=200&fit=crop'
          },
          { 
            id: 'parallel', 
            label: 'Параллельная', 
            description: 'Две параллельные линии',
            image: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=300&h=200&fit=crop'
          }
        ],
        required: true
      },
      {
        id: 'kitchen_width',
        type: 'range',
        question: 'Ширина кухни',
        description: 'Укажите ширину помещения в метрах',
        min: 1.5,
        max: 8.0,
        unit: 'м',
        required: true
      },
      {
        id: 'kitchen_height',
        type: 'range',
        question: 'Высота потолков',
        description: 'Укажите высоту потолков в метрах',
        min: 2.2,
        max: 4.0,
        unit: 'м',
        required: true
      },
      {
        id: 'kitchen_depth',
        type: 'range',
        question: 'Глубина кухни',
        description: 'Укажите глубину помещения в метрах',
        min: 1.5,
        max: 6.0,
        unit: 'м',
        required: true
      }
    ]
  },
  {
    id: 'modules',
    title: 'Модули кухни',
    description: 'Определите количество модулей по типам',
    questions: [
      {
        id: 'lower_modules',
        type: 'range',
        question: 'Нижние модули',
        description: 'Количество напольных шкафов и тумб (0 если не нужны)',
        min: 0,
        max: 15,
        unit: 'шт.',
        required: true
      },
      {
        id: 'upper_modules',
        type: 'range',
        question: 'Верхние модули',
        description: 'Количество навесных шкафов (0 если не нужны)',
        min: 0,
        max: 12,
        unit: 'шт.',
        required: true
      },
      {
        id: 'tall_modules',
        type: 'range',
        question: 'Пенальные модули',
        description: 'Высокие шкафы-колонны для техники и хранения (0 если не нужны)',
        min: 0,
        max: 6,
        unit: 'шт.',
        required: true
      },
      {
        id: 'custom_modules',
        type: 'range',
        question: 'Индивидуальные модули',
        description: 'Специальные модули под конкретные задачи (0 если не нужны)',
        min: 0,
        max: 8,
        unit: 'шт.',
        required: true
      }
    ]
  },
  {
    id: 'countertops',
    title: 'Столешницы',
    description: 'Выберите материал столешницы',
    questions: [
      {
        id: 'countertop_material',
        type: 'single',
        question: 'Материал столешницы',
        description: 'Выберите подходящий материал для столешницы',
        options: [
          { 
            id: 'postforming', 
            label: 'Постформинг', 
            description: 'ЛДСП с пластиковым покрытием. Бюджетный вариант с хорошими эксплуатационными свойствами.',
            image: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=300&h=200&fit=crop'
          },
          { 
            id: 'hpl_plastic', 
            label: 'HPL-пластик', 
            description: 'Высокопрочный слоистый пластик. Устойчив к царапинам, влаге и высоким температурам.',
            image: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=300&h=200&fit=crop'
          },
          { 
            id: 'acrylic', 
            label: 'Акрил', 
            description: 'Искусственный камень на основе акриловых смол. Премиальный материал с возможностью реставрации.',
            image: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=300&h=200&fit=crop'
          }
        ],
        required: true
      }
    ]
  },
  {
    id: 'facades',
    title: 'Фасады',
    description: 'Выберите материал и декор фасадов',
    questions: [
      {
        id: 'facade_material',
        type: 'single',
        question: 'Выберите материал фасада',
        description: 'Основной материал для изготовления фасадов',
        options: [
          { 
            id: 'mdf', 
            label: 'МДФ', 
            description: 'Плита средней плотности. Экологичный материал с отличными эксплуатационными характеристиками.',
            image: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=300&h=200&fit=crop'
          },
          { 
            id: 'ldsp', 
            label: 'ЛДСП', 
            description: 'Ламинированная древесно-стружечная плита. Практичный и доступный вариант.',
            image: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=300&h=200&fit=crop'
          }
        ],
        required: true
      },
      {
        id: 'facade_decors',
        type: 'multiple',
        question: 'Выберите декоры фасадов',
        description: 'Выберите до 3 понравившихся декоров для выбранного материала',
        options: [], // Будет заполняться динамически в зависимости от выбора материала
        required: true
      }
    ]
  },
  {
    id: 'filling',
    title: 'Наполнение кухни',
    description: 'Определим функциональные потребности',
    questions: [
      {
        id: 'family_size',
        type: 'range',
        question: 'Количество человек в семье',
        description: 'Для расчета необходимого объема хранения и функционала',
        min: 1,
        max: 8,
        unit: 'чел.',
        required: true
      },
      {
        id: 'special_items',
        type: 'multiple',
        question: 'Есть ли нестандартная посуда или техника?',
        description: 'Отметьте, что нужно учесть при планировании',
        options: [
          { id: 'large_pots', label: 'Большие кастрюли и сковороды', description: 'Требуют глубокие ящики' },
          { id: 'wine_collection', label: 'Коллекция вин', description: 'Нужен винный шкаф' },
          { id: 'coffee_machine', label: 'Кофемашина', description: 'Встраиваемая или отдельностоящая' },
          { id: 'bread_maker', label: 'Хлебопечка', description: 'Требует специальное место' },
          { id: 'mixer', label: 'Планетарный миксер', description: 'Тяжелая техника' },
          { id: 'steamer', label: 'Пароварка', description: 'Встраиваемая техника' },
          { id: 'large_dishes', label: 'Большие блюда и противни', description: 'Вертикальное хранение' },
          { id: 'spices', label: 'Большая коллекция специй', description: 'Специальные органайзеры' }
        ],
        required: false
      },
      {
        id: 'appliance_package',
        type: 'single',
        question: 'Техника для кухни',
        description: 'Определите вариант комплектации техникой',
        options: [
          { 
            id: 'need_package', 
            label: 'Нужен комплект техники', 
            description: 'Поможем подобрать и предложим скидку на комплект' 
          },
          { 
            id: 'have_appliances', 
            label: 'Техника уже выбрана', 
            description: 'Спланируем кухню под ваши приборы' 
          },
          { 
            id: 'partial_package', 
            label: 'Частично есть, частично нужно', 
            description: 'Дополним недостающими приборами' 
          }
        ],
        required: true
      },
      {
        id: 'space_organization',
        type: 'single',
        question: 'Услуга организации пространства',
        description: 'Профессиональная организация хранения увеличивает полезное пространство на 40%',
        options: [
          { 
            id: 'need_organization', 
            label: 'Да, интересует', 
            description: 'Максимально эффективное использование каждого сантиметра' 
          },
          { 
            id: 'no_organization', 
            label: 'Нет, справлюсь сам', 
            description: 'Стандартное наполнение модулей' 
          },
          { 
            id: 'maybe_organization', 
            label: 'Расскажите подробнее', 
            description: 'Хочу узнать больше о преимуществах' 
          }
        ],
        required: true
      }
    ]
  },
  {
    id: 'contact',
    title: 'Контактная информация',
    description: 'Оставьте контакты для получения персонального предложения',
    questions: [
      {
        id: 'client_name',
        type: 'text',
        question: 'Ваше имя',
        description: 'Как к вам обращаться?',
        required: true
      },
      {
        id: 'client_phone',
        type: 'text',
        question: 'Номер телефона',
        description: 'Для связи с вами',
        required: true
      },
      {
        id: 'client_email',
        type: 'text',
        question: 'Email',
        description: 'Для отправки персонального предложения',
        required: false
      },
      {
        id: 'preferred_contact',
        type: 'single',
        question: 'Предпочитаемый способ связи',
        description: 'Как вам удобнее получить обратную связь?',
        options: [
          { id: 'phone', label: 'Телефонный звонок', description: 'Перезвоним в удобное время' },
          { id: 'whatsapp', label: 'WhatsApp', description: 'Сообщение в мессенджере' },
          { id: 'telegram', label: 'Telegram', description: 'Сообщение в Telegram' },
          { id: 'email', label: 'Email', description: 'Письмо с предложением' }
        ],
        required: true
      },
      {
        id: 'project_timeline',
        type: 'single',
        question: 'Когда планируете реализовать проект?',
        description: 'Это поможет нам лучше спланировать работу',
        options: [
          { id: 'urgent', label: 'В течение месяца', description: 'Срочно нужна кухня' },
          { id: 'soon', label: '1-3 месяца', description: 'В ближайшее время' },
          { id: 'planned', label: '3-6 месяцев', description: 'Планирую заранее' },
          { id: 'future', label: 'Более 6 месяцев', description: 'Пока изучаю варианты' }
        ],
        required: true
      }
    ]
  }
];

// Декоры для МДФ
export const mdfDecors = [
  { 
    id: 'mdf_white_premium', 
    label: 'Белый премиум', 
    description: 'Классический белый с легким перламутром',
    image: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=300&h=200&fit=crop'
  },
  { 
    id: 'mdf_oak_natural', 
    label: 'Дуб натуральный', 
    description: 'Теплый натуральный оттенок дерева',
    image: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=300&h=200&fit=crop'
  },
  { 
    id: 'mdf_graphite_matt', 
    label: 'Графит матовый', 
    description: 'Современный темно-серый оттенок',
    image: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=300&h=200&fit=crop'
  },
  { 
    id: 'mdf_sage_green', 
    label: 'Шалфей', 
    description: 'Модный зеленый оттенок',
    image: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=300&h=200&fit=crop'
  },
  { 
    id: 'mdf_navy_blue', 
    label: 'Темно-синий', 
    description: 'Глубокий синий цвет',
    image: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=300&h=200&fit=crop'
  },
  { 
    id: 'mdf_cream_beige', 
    label: 'Кремовый беж', 
    description: 'Теплый нейтральный оттенок',
    image: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=300&h=200&fit=crop'
  },
  { 
    id: 'mdf_walnut_dark', 
    label: 'Орех темный', 
    description: 'Благородный темный орех',
    image: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=300&h=200&fit=crop'
  },
  { 
    id: 'mdf_concrete_grey', 
    label: 'Бетон серый', 
    description: 'Индустриальный стиль',
    image: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=300&h=200&fit=crop'
  },
  { 
    id: 'mdf_burgundy_wine', 
    label: 'Бургунди', 
    description: 'Насыщенный винный оттенок',
    image: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=300&h=200&fit=crop'
  },
  { 
    id: 'mdf_black_matt', 
    label: 'Черный матовый', 
    description: 'Элегантный черный',
    image: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=300&h=200&fit=crop'
  },
  { 
    id: 'mdf_terracotta', 
    label: 'Терракота', 
    description: 'Теплый земляной оттенок',
    image: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=300&h=200&fit=crop'
  },
  { 
    id: 'mdf_pearl_white', 
    label: 'Жемчужно-белый', 
    description: 'Изысканный белый с переливом',
    image: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=300&h=200&fit=crop'
  }
];

// Декоры для ЛДСП
export const ldspDecors = [
  { 
    id: 'ldsp_white_alpine', 
    label: 'Белый альпийский', 
    description: 'Чистый белый цвет',
    image: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=300&h=200&fit=crop'
  },
  { 
    id: 'ldsp_oak_sonoma', 
    label: 'Дуб сонома', 
    description: 'Светлый дуб с выраженной текстурой',
    image: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=300&h=200&fit=crop'
  },
  { 
    id: 'ldsp_wenge_dark', 
    label: 'Венге темный', 
    description: 'Темный венге с контрастными прожилками',
    image: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=300&h=200&fit=crop'
  },
  { 
    id: 'ldsp_grey_craft', 
    label: 'Серый крафт', 
    description: 'Современный серый с текстурой',
    image: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=300&h=200&fit=crop'
  },
  { 
    id: 'ldsp_beech_natural', 
    label: 'Бук натуральный', 
    description: 'Теплый бук с естественной текстурой',
    image: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=300&h=200&fit=crop'
  },
  { 
    id: 'ldsp_cherry_oxford', 
    label: 'Вишня оксфорд', 
    description: 'Благородная вишня',
    image: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=300&h=200&fit=crop'
  },
  { 
    id: 'ldsp_maple_light', 
    label: 'Клен светлый', 
    description: 'Светлый клен с мягкой текстурой',
    image: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=300&h=200&fit=crop'
  },
  { 
    id: 'ldsp_anthracite', 
    label: 'Антрацит', 
    description: 'Глубокий темно-серый цвет',
    image: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=300&h=200&fit=crop'
  },
  { 
    id: 'ldsp_oak_craft_gold', 
    label: 'Дуб крафт золотой', 
    description: 'Дуб с золотистым оттенком',
    image: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=300&h=200&fit=crop'
  },
  { 
    id: 'ldsp_concrete_chicago', 
    label: 'Бетон чикаго', 
    description: 'Имитация бетона',
    image: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=300&h=200&fit=crop'
  },
  { 
    id: 'ldsp_pine_andersen', 
    label: 'Сосна андерсен', 
    description: 'Светлая сосна с выраженными кольцами',
    image: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=300&h=200&fit=crop'
  },
  { 
    id: 'ldsp_black_edition', 
    label: 'Черный эдишн', 
    description: 'Глубокий черный цвет',
    image: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=300&h=200&fit=crop'
  }
];
