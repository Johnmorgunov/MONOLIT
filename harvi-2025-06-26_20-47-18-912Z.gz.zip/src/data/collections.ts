import type { Collection } from '../types';
import { contentService } from '../services/contentService';

// Базовые коллекции для инициализации
export const initialCollections: Collection[] = [
  {
    id: 'urban',
    title: 'URBAN',
    description: 'Современный минимализм с элементами роскоши',
    price: 'от 249 000 ₽',
    startingPrice: 249000,
    image: 'https://cdn2.antstat.ru/1c/c816a965-5015-4ebf-a4e3-d4f71025eb29/Siel_06_autox900.jpg',
    slug: 'urban-collection',
    detailedDescription: 'Коллекция URBAN воплощает философию современного минимализма, где каждая деталь имеет свое предназначение. Чистые линии, благородные материалы и продуманная эргономика создают пространство, которое вдохновляет на кулинарные эксперименты и объединяет семью за общим столом.',
    features: [
      'Фасады из натурального шпона дуба',
      'Интегрированные LED-светильники',
      'Система плавного закрывания',
      'Скрытые ручки с технологией Push-to-Open',
      'Столешница из искусственного камня',
      'Встроенная система хранения'
    ],
    specifications: {
      materials: ['Натуральный шпон дуба', 'Искусственный камень Corian', 'Алюминиевые профили'],
      colors: ['Дуб натуральный', 'Дуб беленый', 'Дуб графит', 'Белый матовый'],
      sizes: ['Линейная от 2.4м', 'Угловая от 2.8м', 'П-образная от 3.2м', 'Островная от 4.0м'],
      warranty: '14 месяцев полная гарантия'
    },
    gallery: [
      'https://cdn2.antstat.ru/1c/c816a965-5015-4ebf-a4e3-d4f71025eb29/Siel_06_autox900.jpg',
      'https://www.gaudino.it/shared/2019/07/046-cucine-gaudino-modulnova.jpg',
      'https://avatars.mds.yandex.net/get-altay/11400839/2a0000018c49e3e5aa5514c30f726720f569/XXXL',
      'https://www.tehnika24.ru/UserFiles/Image/219/1015143_13_big.jpg'
    ]
  },
  {
    id: 'classic',
    title: 'CLASSIC',
    description: 'Вечная элегантность в современном исполнении',
    price: 'от 299 000 ₽',
    startingPrice: 299000,
    image: 'https://www.tehnika24.ru/UserFiles/Image/219/1015143_13_big.jpg',
    slug: 'classic-collection',
    detailedDescription: 'Коллекция CLASSIC сочетает в себе традиционные формы и современные технологии. Элегантные фрезеровки, благородная фурнитура и тщательно подобранные пропорции создают атмосферу уюта и респектабельности, которая никогда не выйдет из моды.',
    features: [
      'Фасады с классической фрезеровкой',
      'Фурнитура премиум-класса Blum',
      'Натуральные деревянные элементы',
      'Витринные секции с подсветкой',
      'Мраморная столешница',
      'Декоративные молдинги и карнизы'
    ],
    specifications: {
      materials: ['Массив дуба', 'Натуральный мрамор', 'Латунная фурнитура'],
      colors: ['Дуб классик', 'Орех американский', 'Вишня', 'Белый с патиной'],
      sizes: ['Линейная от 2.6м', 'Угловая от 3.0м', 'П-образная от 3.5м', 'Островная от 4.2м'],
      warranty: '14 месяцев полная гарантия'
    },
    gallery: [
      'https://www.tehnika24.ru/UserFiles/Image/219/1015143_13_big.jpg',
      'https://cdn2.antstat.ru/1c/c816a965-5015-4ebf-a4e3-d4f71025eb29/Siel_06_autox900.jpg',
      'https://avatars.mds.yandex.net/get-altay/11400839/2a0000018c49e3e5aa5514c30f726720f569/XXXL',
      'https://www.gaudino.it/shared/2019/07/046-cucine-gaudino-modulnova.jpg'
    ]
  },
  {
    id: 'smart',
    title: 'SMART',
    description: 'Технологии будущего в премиальном исполнении',
    price: 'от 349 000 ₽',
    startingPrice: 349000,
    image: 'https://avatars.mds.yandex.net/get-altay/11400839/2a0000018c49e3e5aa5514c30f726720f569/XXXL',
    slug: 'smart-collection',
    detailedDescription: 'Коллекция SMART представляет будущее кухонного пространства уже сегодня. Интеллектуальные системы управления, инновационные материалы и передовые технологии создают кухню, которая думает вместе с вами и адаптируется под ваш образ жизни.',
    features: [
      'Умная система управления освещением',
      'Встроенные беспроводные зарядки',
      'Сенсорные фасады с подсветкой',
      'Автоматические выдвижные ящики',
      'Интегрированная аудиосистема',
      'Система климат-контроля для хранения'
    ],
    specifications: {
      materials: ['Акриловые панели', 'Закаленное стекло', 'Нержавеющая сталь'],
      colors: ['Белый глянец', 'Черный мат', 'Серый металлик', 'Синий сапфир'],
      sizes: ['Линейная от 2.8м', 'Угловая от 3.2м', 'П-образная от 3.8м', 'Островная от 4.5м'],
      warranty: '14 месяцев полная гарантия + 2 года на электронику'
    },
    gallery: [
      'https://avatars.mds.yandex.net/get-altay/11400839/2a0000018c49e3e5aa5514c30f726720f569/XXXL',
      'https://www.gaudino.it/shared/2019/07/046-cucine-gaudino-modulnova.jpg',
      'https://cdn2.antstat.ru/1c/c816a965-5015-4ebf-a4e3-d4f71025eb29/Siel_06_autox900.jpg',
      'https://www.tehnika24.ru/UserFiles/Image/219/1015143_13_big.jpg'
    ]
  }
];

// Функции для работы с коллекциями через contentService
export const collections = contentService.getCollections();

export const getCollectionBySlug = (slug: string): Collection | undefined => {
  return contentService.getCollectionBySlug(slug);
};

// Утилиты для работы с ценами
export const getPriceSegments = () => {
  const currentCollections = contentService.getCollections();
  const prices = currentCollections.map(c => c.startingPrice).sort((a, b) => a - b);
  
  if (prices.length === 0) return {
    budget: { min: 0, max: 299000, label: 'до 299 000 ₽' },
    medium: { min: 299000, max: 349000, label: '299 000 - 349 000 ₽' },
    premium: { min: 349000, max: 1000000, label: 'от 349 000 ₽' }
  };
  
  const lowestPrice = prices[0];
  const middlePrice = prices[Math.floor(prices.length / 2)];
  const highestPrice = prices[prices.length - 1];
  
  return {
    budget: { min: 0, max: middlePrice - 1, label: `до ${formatPrice(middlePrice - 1)}` },
    medium: { min: middlePrice, max: highestPrice - 1, label: `${formatPrice(middlePrice)} - ${formatPrice(highestPrice - 1)}` },
    premium: { min: highestPrice, max: 1000000, label: `от ${formatPrice(highestPrice)}` }
  };
};

export const formatPrice = (price: number): string => {
  return new Intl.NumberFormat('ru-RU').format(price);
};

export const getCollectionsByPriceSegment = (segment: 'budget' | 'medium' | 'premium') => {
  const segments = getPriceSegments();
  const targetSegment = segments[segment];
  const currentCollections = contentService.getCollections();
  
  return currentCollections.filter(collection => {
    const price = collection.startingPrice;
    return price >= targetSegment.min && price <= targetSegment.max;
  });
};