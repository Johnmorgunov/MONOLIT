import type { Feature } from '../types';

export const features: Feature[] = [
  {
    id: 'price',
    icon: 'Tag',
    title: 'Доступная цена',
    description: 'Модульная система позволяет снизить стоимость на 25-30% без ущерба качеству'
  },
  {
    id: 'materials',
    icon: 'Gem',
    title: 'Премиальные материалы',
    description: 'Используем те же материалы, что и в премиальных кухнях на заказ, но с умной оптимизацией'
  },
  {
    id: 'production',
    icon: 'Settings',
    title: 'Оптимизированное производство',
    description: 'Собственные технологии сборки сокращают затраты, а не качество'
  },
  {
    id: 'speed',
    icon: 'Clock',
    title: 'Быстрые сроки',
    description: 'Модульный подход сокращает время изготовления до 3-4 недель'
  },
  {
    id: 'flexibility',
    icon: 'PuzzleIcon',
    title: 'Гибкость конфигурации',
    description: 'Легко адаптируем под ваше пространство и бюджет'
  },
  {
    id: 'warranty',
    icon: 'Award',
    title: 'Гарантия 14 месяцев',
    description: 'Уверенность в качестве каждого модуля'
  }
];
