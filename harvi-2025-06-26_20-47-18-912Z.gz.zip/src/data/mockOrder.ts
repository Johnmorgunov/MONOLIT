import type { Order, ChecklistItem } from '../types/order';
import { orderStages } from './orderStages';
import { addWorkingDays, getProjectEndDate, calculateProjectDuration } from '../utils/workingDays';

// Мок-данные для демонстрации
export const createMockOrder = (): Order => {
  const now = new Date();
  const totalWorkingDays = calculateProjectDuration(orderStages);
  
  const stages = orderStages.map((stageTemplate, index) => {
    let status: 'pending' | 'in-progress' | 'completed' | 'current';
    let progress = 0;
    let estimatedStartDate: Date | undefined;
    let estimatedEndDate: Date | undefined;
    let canMarkComplete = false;
    let canUnmarkComplete = false;

    // Рассчитываем предварительные даты
    if (stageTemplate.isFlexibleTiming) {
      // Для свободного этапа не устанавливаем конкретные даты
      estimatedStartDate = undefined;
      estimatedEndDate = undefined;
    } else {
      // Рассчитываем предварительные даты в рабочих днях для остальных этапов
      let workingDayOffset = 0;
      for (let i = 0; i < index; i++) {
        if (!orderStages[i].isFlexibleTiming) {
          workingDayOffset += orderStages[i].estimatedDuration;
        }
      }

      estimatedStartDate = addWorkingDays(now, workingDayOffset);
      estimatedEndDate = addWorkingDays(estimatedStartDate, stageTemplate.estimatedDuration);
    }

    // Создаем чек-лист для этапа
    const checklist: ChecklistItem[] = getDefaultChecklistForStage(stageTemplate.id, index);
    const completedItems = checklist.filter(item => item.isCompleted).length;
    const checklistProgress = checklist.length > 0 ? (completedItems / checklist.length) * 100 : 100;

    // Календарное планирование
    const schedule = {
      plannedStartDate: estimatedStartDate,
      plannedEndDate: estimatedEndDate,
      actualStartDate: index === 0 ? now : undefined,
      actualEndDate: index === 0 ? addWorkingDays(now, 1) : undefined,
      isOverdue: false,
      daysUntilDeadline: estimatedEndDate ? Math.ceil((estimatedEndDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)) : undefined
    };

    if (index < 1) {
      // Первый этап завершен
      status = 'completed';
      progress = 100;
      canUnmarkComplete = true;
      // Отмечаем все обязательные пункты как выполненные
      checklist.forEach(item => {
        if (item.isRequired) {
          item.isCompleted = true;
          item.completedAt = new Date(now.getTime() - Math.random() * 24 * 60 * 60 * 1000);
          item.completedBy = 'admin';
        }
      });
    } else if (index === 1) {
      // Текущий этап
      status = 'current';
      progress = 60;
      canMarkComplete = true;
      // Частично выполняем чек-лист
      checklist.slice(0, Math.floor(checklist.length * 0.6)).forEach(item => {
        item.isCompleted = true;
        item.completedAt = new Date(now.getTime() - Math.random() * 12 * 60 * 60 * 1000);
        item.completedBy = 'manager';
      });
    } else {
      // Будущие этапы
      status = 'pending';
      progress = 0;
      canMarkComplete = false;
      canUnmarkComplete = false;
    }

    // Пересчитываем прогресс чек-листа
    const updatedCompletedItems = checklist.filter(item => item.isCompleted).length;
    const updatedChecklistProgress = checklist.length > 0 ? (updatedCompletedItems / checklist.length) * 100 : 100;

    return {
      ...stageTemplate,
      status,
      progress,
      estimatedStartDate,
      estimatedEndDate,
      canMarkComplete,
      canUnmarkComplete,
      schedule,
      checklist,
      checklistProgress: updatedChecklistProgress
    };
  });

  const completedStages = stages.filter(s => s.status === 'completed').length;
  const currentStageProgress = stages.find(s => s.status === 'current')?.progress || 0;
  const totalProgress = (completedStages * 100 + currentStageProgress) / stages.length;

  // Проверяем просрочку
  const currentStage = stages.find(s => s.status === 'current');
  const isOverdue = currentStage?.schedule?.plannedEndDate ? 
    new Date() > currentStage.schedule.plannedEndDate : false;

  const nextDeadline = stages
    .filter(s => s.status !== 'completed' && s.schedule?.plannedEndDate)
    .sort((a, b) => (a.schedule!.plannedEndDate!.getTime() - b.schedule!.plannedEndDate!.getTime()))[0]?.schedule?.plannedEndDate;

  return {
    id: 'order-001',
    orderNumber: 'MNL-2025-001',
    collectionId: 'urban',
    customerName: 'Иван Петров',
    customerPhone: '+7 (999) 123-45-67',
    customerEmail: 'ivan.petrov@example.com',
    createdDate: new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000), // 7 дней назад
    estimatedCompletionDate: getProjectEndDate(now, totalWorkingDays),
    currentStage: 'measurement',
    stages,
    totalProgress,
    notes: [
      'Заказ принят в работу',
      'Обсуждение проекта и сбор информации завершены успешно'
    ],
    isOverdue,
    nextDeadline
  };
};

// Функция для создания дефолтного чек-листа для каждого этапа
function getDefaultChecklistForStage(stageId: string, index: number): ChecklistItem[] {
  const baseId = `${stageId}_${Date.now()}`;
  
  switch (stageId) {
    case 'project-discussion-and-info':
      return [
        {
          id: `${baseId}_1`,
          title: 'Провести консультацию с клиентом',
          description: 'Обсудить пожелания, бюджет и требования',
          isCompleted: false,
          isRequired: true
        },
        {
          id: `${baseId}_2`,
          title: 'Определить стиль и материалы',
          description: 'Выбрать коллекцию и основные материалы',
          isCompleted: false,
          isRequired: true
        },
        {
          id: `${baseId}_3`,
          title: 'Согласовать функциональные решения',
          description: 'Обсудить планировку и техническое оснащение',
          isCompleted: false,
          isRequired: true
        },
        {
          id: `${baseId}_4`,
          title: 'Подготовить предварительную смету',
          description: 'Рассчитать примерную стоимость проекта',
          isCompleted: false,
          isRequired: false
        }
      ];

    case 'measurement':
      return [
        {
          id: `${baseId}_1`,
          title: 'Согласовать время замера с клиентом',
          description: 'Назначить удобное время для выезда',
          isCompleted: false,
          isRequired: true
        },
        {
          id: `${baseId}_2`,
          title: 'Провести точные замеры помещения',
          description: 'Измерить все размеры и особенности планировки',
          isCompleted: false,
          isRequired: true
        },
        {
          id: `${baseId}_3`,
          title: 'Сфотографировать помещение',
          description: 'Сделать фото для дизайн-проекта',
          isCompleted: false,
          isRequired: true
        },
        {
          id: `${baseId}_4`,
          title: 'Проверить коммуникации',
          description: 'Оценить состояние электрики, водопровода, газа',
          isCompleted: false,
          isRequired: true
        }
      ];

    case 'design-project':
      return [
        {
          id: `${baseId}_1`,
          title: 'Создать планировочное решение',
          description: 'Разработать оптимальную планировку кухни',
          isCompleted: false,
          isRequired: true
        },
        {
          id: `${baseId}_2`,
          title: 'Подготовить 3D-визуализацию',
          description: 'Создать реалистичные изображения будущей кухни',
          isCompleted: false,
          isRequired: true
        },
        {
          id: `${baseId}_3`,
          title: 'Составить спецификацию материалов',
          description: 'Детальный список всех материалов и комплектующих',
          isCompleted: false,
          isRequired: true
        },
        {
          id: `${baseId}_4`,
          title: 'Согласовать проект с клиентом',
          description: 'Получить одобрение дизайна и внести правки',
          isCompleted: false,
          isRequired: true
        },
        {
          id: `${baseId}_5`,
          title: 'Подготовить чертежи для производства',
          description: 'Технические чертежи для изготовления',
          isCompleted: false,
          isRequired: true
        }
      ];

    case 'production':
      return [
        {
          id: `${baseId}_1`,
          title: 'Заказать материалы и комплектующие',
          description: 'Оформить заказ у поставщиков',
          isCompleted: false,
          isRequired: true
        },
        {
          id: `${baseId}_2`,
          title: 'Распилить детали корпусов',
          description: 'Раскрой ЛДСП и других материалов',
          isCompleted: false,
          isRequired: true
        },
        {
          id: `${baseId}_3`,
          title: 'Изготовить фасады',
          description: 'Производство фасадов согласно проекту',
          isCompleted: false,
          isRequired: true
        },
        {
          id: `${baseId}_4`,
          title: 'Собрать корпуса',
          description: 'Сборка каркасов шкафов',
          isCompleted: false,
          isRequired: true
        },
        {
          id: `${baseId}_5`,
          title: 'Установить фурнитуру',
          description: 'Монтаж петель, направляющих, ручек',
          isCompleted: false,
          isRequired: true
        },
        {
          id: `${baseId}_6`,
          title: 'Контроль качества',
          description: 'Проверка готовых изделий перед отгрузкой',
          isCompleted: false,
          isRequired: true
        }
      ];

    case 'installation':
      return [
        {
          id: `${baseId}_1`,
          title: 'Согласовать дату доставки',
          description: 'Назначить удобное время для клиента',
          isCompleted: false,
          isRequired: true
        },
        {
          id: `${baseId}_2`,
          title: 'Доставить кухню на объект',
          description: 'Транспортировка всех элементов кухни',
          isCompleted: false,
          isRequired: true
        },
        {
          id: `${baseId}_3`,
          title: 'Установить корпуса',
          description: 'Монтаж каркасов и навесных шкафов',
          isCompleted: false,
          isRequired: true
        },
        {
          id: `${baseId}_4`,
          title: 'Установить столешницу',
          description: 'Монтаж и подгонка столешницы',
          isCompleted: false,
          isRequired: true
        },
        {
          id: `${baseId}_5`,
          title: 'Навесить фасады',
          description: 'Установка дверок и ящиков',
          isCompleted: false,
          isRequired: true
        },
        {
          id: `${baseId}_6`,
          title: 'Подключить технику',
          description: 'Подключение встроенной техники',
          isCompleted: false,
          isRequired: false
        },
        {
          id: `${baseId}_7`,
          title: 'Финальная приемка с клиентом',
          description: 'Сдача готового объекта клиенту',
          isCompleted: false,
          isRequired: true
        }
      ];

    default:
      return [
        {
          id: `${baseId}_1`,
          title: 'Выполнить основные работы этапа',
          description: 'Основные задачи данного этапа',
          isCompleted: false,
          isRequired: true
        }
      ];
  }
}
