import type { OrderStage } from '../types/order';

export const orderStages: Omit<OrderStage, 'status' | 'startDate' | 'endDate' | 'progress'>[] = [
  {
    id: 'project-discussion-and-info',
    title: 'Обсуждение проекта и сбор информации',
    description: 'Консультация по дизайну, материалам, функциональным решениям и детализация всех требований',
    estimatedDuration: 0, // свободное время, не привязано к рабочим дням
    isFlexibleTiming: true
  },
  {
    id: 'measurement',
    title: 'Замер',
    description: 'Точные замеры для создания дизайн-проекта',
    estimatedDuration: 1 // рабочий день
  },
  {
    id: 'design-project',
    title: 'Дизайн-проект',
    description: 'Создание 3D-визуализации и дизайн-проекта кухни',
    estimatedDuration: 3 // рабочих дня
  },
  {
    id: 'production',
    title: 'Производство',
    description: 'Изготовление кухонной мебели на производстве',
    estimatedDuration: 20 // рабочих дней
  },
  {
    id: 'installation',
    title: 'Установка',
    description: 'Доставка и монтаж кухни в вашем доме',
    estimatedDuration: 1 // рабочий день
  }
];

export const getTotalEstimatedDuration = (): number => {
  return orderStages
    .filter(stage => !stage.isFlexibleTiming)
    .reduce((total, stage) => total + stage.estimatedDuration, 0);
};

export const getStageProgress = (stageIndex: number): number => {
  return ((stageIndex + 1) / orderStages.length) * 100;
};
