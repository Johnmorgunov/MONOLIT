import type { ProcessStep } from '../types';

export const processSteps: ProcessStep[] = [
  {
    id: 'standardization',
    number: 1,
    title: 'Стандартизация',
    description: 'Использование унифицированных модулей сокращает затраты на проектирование и производство'
  },
  {
    id: 'direct-supply',
    number: 2,
    title: 'Прямые поставки',
    description: 'Работаем напрямую с крупными поставщиками, исключая посредников'
  },
  {
    id: 'automation',
    number: 3,
    title: 'Автоматизация',
    description: 'Современное оборудование и технологии снижает себестоимость без потери качества'
  },
  {
    id: 'logistics',
    number: 4,
    title: 'Логистика',
    description: 'Оптимизированная система доставки и сборки экономит ваши деньги'
  }
];
