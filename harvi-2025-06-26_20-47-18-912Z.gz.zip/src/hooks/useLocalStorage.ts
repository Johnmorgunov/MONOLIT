import { useState, useEffect, useCallback, useRef } from 'react';

export function useLocalStorage<T>(key: string, initialValue: T) {
  const [storedValue, setStoredValue] = useState<T>(() => {
    try {
      if (typeof window === 'undefined') return initialValue;
      
      const item = window.localStorage.getItem(key);
      return item ? JSON.parse(item) : initialValue;
    } catch (error) {
      console.warn(`Error reading localStorage key "${key}":`, error);
      return initialValue;
    }
  });

  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  
  // Используем ref для предотвращения race conditions
  const isUpdatingRef = useRef(false);

  // Функция для установки значения с защитой от race conditions
  const setValue = useCallback((value: T | ((val: T) => T)) => {
    if (isUpdatingRef.current) return;
    
    setIsLoading(true);
    setError(null);
    
    try {
      isUpdatingRef.current = true;
      
      // Позволяем передавать функцию как в useState
      const valueToStore = value instanceof Function ? value(storedValue) : value;
      
      // Проверяем, изменилось ли значение
      const currentValueString = JSON.stringify(storedValue);
      const newValueString = JSON.stringify(valueToStore);
      
      if (currentValueString !== newValueString) {
        setStoredValue(valueToStore);
        
        if (typeof window !== 'undefined') {
          window.localStorage.setItem(key, newValueString);
        }
      }
    } catch (error) {
      const errorMessage = `Error setting localStorage key "${key}": ${error}`;
      console.warn(errorMessage);
      setError(errorMessage);
    } finally {
      isUpdatingRef.current = false;
      setIsLoading(false);
    }
  }, [key, storedValue]);

  // Функция для удаления значения
  const removeValue = useCallback(() => {
    if (isUpdatingRef.current) return;
    
    setIsLoading(true);
    setError(null);
    
    try {
      isUpdatingRef.current = true;
      
      if (typeof window !== 'undefined') {
        window.localStorage.removeItem(key);
      }
      setStoredValue(initialValue);
    } catch (error) {
      const errorMessage = `Error removing localStorage key "${key}": ${error}`;
      console.warn(errorMessage);
      setError(errorMessage);
    } finally {
      isUpdatingRef.current = false;
      setIsLoading(false);
    }
  }, [key, initialValue]);

  // Функция для принудительного обновления из localStorage
  const refreshValue = useCallback(() => {
    if (isUpdatingRef.current) return;
    
    setIsLoading(true);
    setError(null);
    
    try {
      if (typeof window !== 'undefined') {
        const item = window.localStorage.getItem(key);
        const newValue = item ? JSON.parse(item) : initialValue;
        setStoredValue(newValue);
      }
    } catch (error) {
      const errorMessage = `Error refreshing localStorage key "${key}": ${error}`;
      console.warn(errorMessage);
      setError(errorMessage);
    } finally {
      setIsLoading(false);
    }
  }, [key, initialValue]);

  // Синхронизация с localStorage при изменениях в других вкладках
  useEffect(() => {
    if (typeof window === 'undefined') return;
    
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === key && e.newValue !== null && !isUpdatingRef.current) {
        try {
          const newValue = JSON.parse(e.newValue);
          setStoredValue(newValue);
        } catch (error) {
          console.warn(`Error parsing localStorage value for key "${key}":`, error);
          setError(`Error parsing localStorage value for key "${key}"`);
        }
      }
    };

    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, [key]);

  // Проверка доступности localStorage
  const isAvailable = useCallback(() => {
    try {
      if (typeof window === 'undefined') return false;
      
      const testKey = '__localStorage_test__';
      window.localStorage.setItem(testKey, 'test');
      window.localStorage.removeItem(testKey);
      return true;
    } catch {
      return false;
    }
  }, []);

  return [
    storedValue, 
    setValue, 
    removeValue, 
    { 
      error, 
      isLoading, 
      isAvailable: isAvailable(), 
      refreshValue 
    }
  ] as const;
}