import React, { useState, useEffect } from 'react';
import { Package, BookOpen, BarChart3 } from 'lucide-react';
import { AdminLogin } from '../components/admin/AdminLogin';
import { AdminHeader } from '../components/admin/AdminHeader';
import { AdminStats } from '../components/admin/AdminStats';
import { OrdersTable } from '../components/admin/OrdersTable';
import { OrderDetailsModal } from '../components/admin/OrderDetailsModal';
import { ContentManagement } from '../components/admin/ContentManagement';
import { AnimatedSection } from '../components/ui/AnimatedSection';
import { adminService } from '../services/adminService';
import type { AdminSession, OrderFilter, AdminStats as StatsType } from '../types/admin';
import type { Order } from '../types/order';

type AdminTab = 'orders' | 'content' | 'stats';

export const AdminPage: React.FC = () => {
  const [session, setSession] = useState<AdminSession | null>(null);
  const [activeTab, setActiveTab] = useState<AdminTab>('orders');
  const [orders, setOrders] = useState<Order[]>([]);
  const [stats, setStats] = useState<StatsType | null>(null);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [currentFilter, setCurrentFilter] = useState<OrderFilter>({});

  useEffect(() => {
    // Проверяем существующую сессию при загрузке
    const existingSession = adminService.getCurrentSession();
    if (existingSession) {
      setSession(existingSession);
    }
  }, []);

  useEffect(() => {
    if (session && activeTab === 'orders') {
      loadOrdersData();
    } else if (session && activeTab === 'stats') {
      loadStatsData();
    }
  }, [session, activeTab, currentFilter]);

  const loadOrdersData = async () => {
    setIsLoading(true);
    try {
      const ordersData = await adminService.getOrders(currentFilter);
      setOrders(ordersData);
    } catch (error) {
      console.error('Ошибка загрузки заказов:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const loadStatsData = async () => {
    setIsLoading(true);
    try {
      const statsData = await adminService.getStatistics();
      setStats(statsData);
    } catch (error) {
      console.error('Ошибка загрузки статистики:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogin = (newSession: AdminSession) => {
    setSession(newSession);
  };

  const handleLogout = () => {
    adminService.logout();
    setSession(null);
    setOrders([]);
    setStats(null);
    setSelectedOrder(null);
    setActiveTab('orders');
  };

  const handleFilterChange = (filter: OrderFilter) => {
    setCurrentFilter(filter);
  };

  const handleViewOrder = (order: Order) => {
    setSelectedOrder(order);
  };

  const handleOrderUpdate = (updatedOrder: Order) => {
    setOrders(prevOrders => 
      prevOrders.map(order => 
        order.id === updatedOrder.id ? updatedOrder : order
      )
    );
    setSelectedOrder(updatedOrder);
    
    // Перезагружаем статистику если она загружена
    if (stats) {
      adminService.getStatistics().then(setStats);
    }
  };

  const handleCloseModal = () => {
    setSelectedOrder(null);
  };

  // Если не авторизован, показываем форму входа
  if (!session) {
    return <AdminLogin onLogin={handleLogin} />;
  }

  const tabs = [
    { key: 'orders', label: 'Заказы', icon: <Package size={16} /> },
    { key: 'content', label: 'Контент', icon: <BookOpen size={16} /> },
    { key: 'stats', label: 'Статистика', icon: <BarChart3 size={16} /> }
  ];

  return (
    <div className="min-h-screen bg-dark-950">
      <AdminHeader session={session} onLogout={handleLogout} />
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <AnimatedSection>
          <div className="mb-8">
            <h1 className="font-manrope text-3xl font-medium text-white mb-2">
              Административная панель
            </h1>
            <p className="text-gray-400">
              Управление заказами, контентом и статистикой
            </p>
          </div>
        </AnimatedSection>

        {/* Tabs */}
        <AnimatedSection>
          <div className="flex space-x-1 bg-dark-800 p-1 rounded-lg mb-8">
            {tabs.map(tab => (
              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key as AdminTab)}
                className={`flex items-center space-x-2 px-6 py-3 rounded-md transition-all duration-200 ${
                  activeTab === tab.key
                    ? 'bg-gold-400 text-black'
                    : 'text-white hover:bg-dark-700'
                }`}
              >
                {tab.icon}
                <span>{tab.label}</span>
              </button>
            ))}
          </div>
        </AnimatedSection>

        {/* Content */}
        {activeTab === 'orders' && (
          <>
            {/* Статистика для заказов */}
            {stats && (
              <div className="mb-8">
                <AdminStats stats={stats} />
              </div>
            )}

            {/* Таблица заказов */}
            <AnimatedSection>
              <OrdersTable
                orders={orders}
                isLoading={isLoading}
                onViewOrder={handleViewOrder}
                onFilterChange={handleFilterChange}
              />
            </AnimatedSection>

            {/* Модальное окно деталей заказа */}
            {selectedOrder && (
              <OrderDetailsModal
                order={selectedOrder}
                isOpen={true}
                onClose={handleCloseModal}
                onOrderUpdate={handleOrderUpdate}
              />
            )}
          </>
        )}

        {activeTab === 'content' && (
          <ContentManagement />
        )}

        {activeTab === 'stats' && (
          <AnimatedSection>
            {stats ? (
              <AdminStats stats={stats} />
            ) : (
              <div className="text-center py-12">
                <p className="text-gray-400">Загрузка статистики...</p>
              </div>
            )}
          </AnimatedSection>
        )}
      </div>
    </div>
  );
};