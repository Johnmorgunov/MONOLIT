import React from 'react';
import { BriefForm } from '../components/brief/BriefForm';

export const BriefPage: React.FC = () => {
  return <BriefForm />;
};
