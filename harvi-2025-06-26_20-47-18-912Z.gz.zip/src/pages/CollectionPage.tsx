import React, { useState } from 'react';
import { useParams, Navigate, Link } from 'react-router-dom';
import { 
  Palette, 
  Ruler, 
  Package, 
  Shield, 
  Phone, 
  MessageCircle,
  FileText,
  Send
} from 'lucide-react';
import { getCollectionBySlug, formatPrice } from '../data/collections';
import { AnimatedSection } from '../components/ui/AnimatedSection';
import { Button } from '../components/ui/Button';
import { ImageGallery } from '../components/ui/ImageGallery';
import { SpecificationCard } from '../components/ui/SpecificationCard';
import { ConsentModal } from '../components/ui/ConsentModal';
import { OptimizedImage } from '../components/ui/OptimizedImage';

export const CollectionPage: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const [consentModal, setConsentModal] = useState<{
    isOpen: boolean;
    type: 'consultation' | 'messenger' | 'telegram';
  }>({ isOpen: false, type: 'consultation' });
  
  if (!slug) {
    return <Navigate to="/" replace />;
  }

  const collection = getCollectionBySlug(slug);

  if (!collection) {
    return <Navigate to="/" replace />;
  }

  const handleConsultationClick = () => {
    setConsentModal({ isOpen: true, type: 'consultation' });
  };

  const handleMessengerClick = () => {
    setConsentModal({ isOpen: true, type: 'messenger' });
  };

  const handleTelegramClick = () => {
    setConsentModal({ isOpen: true, type: 'telegram' });
  };

  const handleConsentConfirm = () => {
    if (consentModal.type === 'consultation') {
      window.open('tel:+78005553535');
    } else if (consentModal.type === 'messenger') {
      window.open('https://wa.me/78005553535');
    } else if (consentModal.type === 'telegram') {
      window.open('https://t.me/monolit_kitchen');
    }
  };

  const closeConsentModal = () => {
    setConsentModal({ isOpen: false, type: 'consultation' });
  };

  return (
    <div className="min-h-screen bg-dark-950 pt-20">
      {/* Hero Section */}
      <section className="py-20 lg:py-32">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-start">
            {/* Content */}
            <div>
              <AnimatedSection>
                <h1 className="font-manrope text-4xl lg:text-6xl font-medium text-white mb-6">
                  Коллекция <span className="text-gold-400">{collection.title}</span>
                </h1>
              </AnimatedSection>

              <AnimatedSection>
                <p className="text-xl text-gray-300 mb-8 leading-relaxed font-light">
                  {collection.detailedDescription}
                </p>
              </AnimatedSection>

              <AnimatedSection>
                <div className="bg-gold-400/20 border-l-4 border-gold-400 p-6 mb-8 rounded-xl">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-white font-medium text-lg mb-2">
                        Стоимость коллекции
                      </p>
                      <p className="text-2xl font-bold text-gold-400">
                        {collection.price}
                      </p>
                      <p className="text-sm text-gray-300 mt-1">
                        Финальная стоимость зависит от размеров и комплектации
                      </p>
                    </div>
                  </div>
                </div>
              </AnimatedSection>

              {/* Action Buttons - Центрированные */}
              <AnimatedSection>
                <div className="space-y-6">
                  {/* Основная кнопка - центрированная */}
                  <div className="text-center">
                    <Link to={`/collection/${collection.slug}/brief`}>
                      <Button
                        variant="primary"
                        size="lg"
                        className="inline-flex items-center justify-center space-x-2 px-12 py-4"
                      >
                        <FileText size={20} />
                        <span>Пройти бриф (5 минут)</span>
                      </Button>
                    </Link>
                  </div>
                  
                  {/* Дополнительные кнопки */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <Button
                      variant="outline"
                      size="md"
                      onClick={handleConsultationClick}
                      className="flex items-center justify-center space-x-2"
                    >
                      <Phone size={18} />
                      <span>Консультация</span>
                    </Button>
                    <Button
                      variant="outline"
                      size="md"
                      onClick={handleMessengerClick}
                      className="flex items-center justify-center space-x-2"
                    >
                      <MessageCircle size={18} />
                      <span>WhatsApp</span>
                    </Button>
                    <Button
                      variant="outline"
                      size="md"
                      onClick={handleTelegramClick}
                      className="flex items-center justify-center space-x-2"
                    >
                      <Send size={18} />
                      <span>Telegram</span>
                    </Button>
                  </div>
                </div>
              </AnimatedSection>
            </div>

            {/* Main Image */}
            <AnimatedSection>
              <OptimizedImage
                src={collection.image}
                alt={collection.title}
                className="aspect-[4/5] shadow-2xl rounded-xl"
                loading="eager"
                aspectRatio="4/5"
              />
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* Brief CTA Section */}
      <section className="py-16 bg-dark-900/50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <AnimatedSection>
            <div className="max-w-4xl mx-auto text-center">
              <h2 className="font-manrope text-2xl lg:text-3xl font-medium text-white mb-6">
                Получите персональное предложение
              </h2>
              <p className="text-lg text-gray-300 mb-8">
                Пройдите короткий бриф, и мы подготовим индивидуальный проект кухни 
                с учетом ваших потребностей и бюджета
              </p>
              <Link to={`/collection/${collection.slug}/brief`}>
                <Button variant="primary" size="lg" className="inline-flex items-center space-x-2">
                  <FileText size={20} />
                  <span>Начать бриф (5 минут)</span>
                </Button>
              </Link>
            </div>
          </AnimatedSection>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-dark-900">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <AnimatedSection>
            <h2 className="font-manrope text-3xl lg:text-4xl font-medium text-white mb-12 text-center">
              Особенности коллекции
            </h2>
          </AnimatedSection>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {collection.features.map((feature, index) => (
              <AnimatedSection key={index}>
                <div className="bg-dark-800/50 backdrop-blur-sm border border-gold-400/10 p-6 hover:border-gold-400/30 transition-all duration-300 rounded-xl">
                  <div className="flex items-start">
                    <span className="text-gold-400 mr-3 mt-1">✓</span>
                    <p className="text-gray-300 font-light">{feature}</p>
                  </div>
                </div>
              </AnimatedSection>
            ))}
          </div>
        </div>
      </section>

      {/* Specifications Section */}
      <section className="py-20 bg-dark-800">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <AnimatedSection>
            <h2 className="font-manrope text-3xl lg:text-4xl font-medium text-white mb-12 text-center">
              Технические характеристики
            </h2>
          </AnimatedSection>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <AnimatedSection>
              <SpecificationCard
                title="Материалы"
                items={collection.specifications.materials}
                icon={<Package size={24} />}
              />
            </AnimatedSection>

            <AnimatedSection>
              <SpecificationCard
                title="Цветовые решения"
                items={collection.specifications.colors}
                icon={<Palette size={24} />}
              />
            </AnimatedSection>

            <AnimatedSection>
              <SpecificationCard
                title="Размеры"
                items={collection.specifications.sizes}
                icon={<Ruler size={24} />}
              />
            </AnimatedSection>

            <AnimatedSection>
              <SpecificationCard
                title="Гарантия"
                items={[collection.specifications.warranty]}
                icon={<Shield size={24} />}
              />
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* Gallery Section */}
      <section className="py-20 bg-dark-950">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <AnimatedSection>
            <h2 className="font-manrope text-3xl lg:text-4xl font-medium text-white mb-12 text-center">
              Галерея проектов
            </h2>
          </AnimatedSection>

          <AnimatedSection>
            <ImageGallery images={collection.gallery} title={collection.title} />
          </AnimatedSection>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-dark-900">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <AnimatedSection>
            <h2 className="font-manrope text-3xl lg:text-4xl font-medium text-white mb-8">
              Готовы обсудить ваш проект?
            </h2>
          </AnimatedSection>

          <AnimatedSection>
            <p className="text-lg text-gray-300 mb-12 max-w-2xl mx-auto font-light">
              Наши специалисты помогут подобрать оптимальную конфигурацию и рассчитают точную стоимость 
              с учетом ваших пожеланий и особенностей помещения.
            </p>
          </AnimatedSection>

          <AnimatedSection>
            <div className="space-y-6">
              {/* Основная кнопка - центрированная */}
              <div className="text-center">
                <Link to={`/collection/${collection.slug}/brief`}>
                  <Button
                    variant="primary"
                    size="lg"
                    className="inline-flex items-center justify-center space-x-2 px-12 py-4"
                  >
                    <FileText size={20} />
                    <span>Пройти бриф</span>
                  </Button>
                </Link>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button
                  variant="outline"
                  size="lg"
                  onClick={handleConsultationClick}
                  className="flex items-center justify-center space-x-2"
                >
                  <Phone size={20} />
                  <span>+7 (800) 555-35-35</span>
                </Button>
                <Button
                  variant="outline"
                  size="lg"
                  onClick={handleMessengerClick}
                  className="flex items-center justify-center space-x-2"
                >
                  <MessageCircle size={20} />
                  <span>WhatsApp</span>
                </Button>
                <Button
                  variant="outline"
                  size="lg"
                  onClick={handleTelegramClick}
                  className="flex items-center justify-center space-x-2"
                >
                  <Send size={20} />
                  <span>Telegram</span>
                </Button>
              </div>
            </div>
          </AnimatedSection>
        </div>
      </section>

      {/* Consent Modal */}
      <ConsentModal
        isOpen={consentModal.isOpen}
        onClose={closeConsentModal}
        type={consentModal.type}
        onConfirm={handleConsentConfirm}
        collectionId={collection.id}
      />
    </div>
  );
};