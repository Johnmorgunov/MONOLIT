import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Filter, Grid, List, Search, MessageCircle, Send } from 'lucide-react';
import { AnimatedSection } from '../components/ui/AnimatedSection';
import { OptimizedImage } from '../components/ui/OptimizedImage';
import { Button } from '../components/ui/Button';
import { collections, formatPrice } from '../data/collections';

type ViewMode = 'grid' | 'list';
type SortBy = 'name' | 'price-low' | 'price-high';

export const CollectionsPage: React.FC = () => {
  const [viewMode, setViewMode] = useState<ViewMode>('grid');
  const [sortBy, setSortBy] = useState<SortBy>('name');
  const [searchQuery, setSearchQuery] = useState('');
  const [priceFilter, setPriceFilter] = useState<'all' | 'budget' | 'medium' | 'premium'>('all');

  const filteredAndSortedCollections = React.useMemo(() => {
    let filtered = collections.filter(collection => {
      const matchesSearch = collection.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           collection.description.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchesPrice = priceFilter === 'all' || 
                          (priceFilter === 'budget' && collection.startingPrice < 299000) ||
                          (priceFilter === 'medium' && collection.startingPrice >= 299000 && collection.startingPrice < 349000) ||
                          (priceFilter === 'premium' && collection.startingPrice >= 349000);
      
      return matchesSearch && matchesPrice;
    });

    return filtered.sort((a, b) => {
      switch (sortBy) {
        case 'price-low':
          return a.startingPrice - b.startingPrice;
        case 'price-high':
          return b.startingPrice - a.startingPrice;
        case 'name':
        default:
          return a.title.localeCompare(b.title);
      }
    });
  }, [searchQuery, priceFilter, sortBy]);

  return (
    <div className="min-h-screen bg-dark-950 pt-20">
      {/* Hero Section */}
      <section className="py-16 lg:py-24 bg-dark-900">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <AnimatedSection>
            <div className="text-center max-w-4xl mx-auto">
              <h1 className="font-manrope text-4xl lg:text-6xl font-medium text-white mb-6">
                Наши <span className="text-gold-400">коллекции</span>
              </h1>
              <p className="text-xl text-gray-300 leading-relaxed font-light">
                Каждая коллекция создается с учетом современных тенденций и технологий производства, 
                что позволяет нам предлагать премиальное качество по конкурентной цене.
              </p>
            </div>
          </AnimatedSection>
        </div>
      </section>

      {/* Filters and Controls */}
      <section className="py-8 bg-dark-900/50 border-b border-gold-400/10 sticky top-20 z-40 backdrop-blur-lg">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <AnimatedSection>
            <div className="flex flex-col lg:flex-row gap-6 items-center justify-between">
              {/* Search */}
              <div className="relative flex-1 max-w-md">
                <Search size={20} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 z-10" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Поиск коллекций..."
                  className="w-full pl-10 pr-4 py-3 bg-dark-800 border border-gray-600 text-white focus:outline-none focus:border-gold-400 transition-colors duration-300 rounded-xl relative z-10"
                />
              </div>

              {/* Filters */}
              <div className="flex items-center gap-4">
                {/* Price Filter */}
                <div className="flex items-center space-x-2">
                  <Filter size={16} className="text-gray-400" />
                  <select
                    value={priceFilter}
                    onChange={(e) => setPriceFilter(e.target.value as any)}
                    className="bg-dark-800 border border-gray-600 text-white px-3 py-2 focus:outline-none focus:border-gold-400 rounded-lg relative z-10"
                  >
                    <option value="all">Все цены</option>
                    <option value="budget">до 299 000 ₽</option>
                    <option value="medium">299 000 - 349 000 ₽</option>
                    <option value="premium">от 349 000 ₽</option>
                  </select>
                </div>

                {/* Sort */}
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as SortBy)}
                  className="bg-dark-800 border border-gray-600 text-white px-3 py-2 focus:outline-none focus:border-gold-400 rounded-lg relative z-10"
                >
                  <option value="name">По названию</option>
                  <option value="price-low">Сначала дешевые</option>
                  <option value="price-high">Сначала дорогие</option>
                </select>

                {/* View Mode */}
                <div className="flex border border-gray-600 overflow-hidden rounded-lg relative z-10">
                  <button
                    onClick={() => setViewMode('grid')}
                    className={`p-2 transition-colors duration-300 ${
                      viewMode === 'grid' 
                        ? 'bg-gold-400 text-black' 
                        : 'bg-dark-800 text-white hover:bg-dark-700'
                    }`}
                  >
                    <Grid size={16} />
                  </button>
                  <button
                    onClick={() => setViewMode('list')}
                    className={`p-2 transition-colors duration-300 ${
                      viewMode === 'list' 
                        ? 'bg-gold-400 text-black' 
                        : 'bg-dark-800 text-white hover:bg-dark-700'
                    }`}
                  >
                    <List size={16} />
                  </button>
                </div>
              </div>
            </div>
          </AnimatedSection>
        </div>
      </section>

      {/* Collections Grid/List */}
      <section className="py-16 lg:py-24">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          {filteredAndSortedCollections.length === 0 ? (
            <AnimatedSection>
              <div className="text-center py-16">
                <div className="w-24 h-24 bg-dark-800 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Search size={32} className="text-gray-400" />
                </div>
                <h3 className="font-manrope text-xl font-medium text-white mb-4">
                  Коллекции не найдены
                </h3>
                <p className="text-gray-400 mb-6">
                  Попробуйте изменить параметры поиска или фильтры
                </p>
                <Button
                  variant="outline"
                  onClick={() => {
                    setSearchQuery('');
                    setPriceFilter('all');
                    setSortBy('name');
                  }}
                >
                  Сбросить фильтры
                </Button>
              </div>
            </AnimatedSection>
          ) : (
            <>
              {/* Results Count */}
              <AnimatedSection>
                <div className="mb-8">
                  <p className="text-gray-400 text-lg">
                    Найдено коллекций: <span className="text-white font-semibold">{filteredAndSortedCollections.length}</span>
                  </p>
                </div>
              </AnimatedSection>

              {/* Grid View */}
              {viewMode === 'grid' && (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 lg:gap-12">
                  {filteredAndSortedCollections.map((collection, index) => (
                    <AnimatedSection key={collection.id} className="group">
                      <div className="relative overflow-hidden bg-dark-900 shadow-2xl hover:shadow-3xl transition-all duration-500 hover:scale-[1.02] rounded-xl">
                        {/* Main Image */}
                        <div className="relative overflow-hidden">
                          <OptimizedImage
                            src={collection.image}
                            alt={collection.title}
                            className="aspect-[4/5] group-hover:scale-110 transition-transform duration-700 rounded-t-xl"
                            loading={index === 0 ? 'eager' : 'lazy'}
                            aspectRatio="4/5"
                          />
                          
                          {/* Gradient Overlay */}
                          <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent group-hover:from-black/95 transition-all duration-500"></div>
                        </div>
                        
                        {/* Gallery Preview */}
                        {collection.gallery && collection.gallery.length > 1 && (
                          <div className="grid grid-cols-4 gap-1 p-2 bg-dark-900">
                            {collection.gallery.slice(0, 4).map((image, imgIndex) => (
                              <div key={imgIndex} className="aspect-square overflow-hidden rounded">
                                <OptimizedImage
                                  src={image}
                                  alt={`${collection.title} - фото ${imgIndex + 1}`}
                                  className="w-full h-full object-cover hover:scale-110 transition-transform duration-300"
                                  loading="lazy"
                                />
                              </div>
                            ))}
                          </div>
                        )}
                        
                        {/* Content Below Image */}
                        <div className="p-6 lg:p-8 text-white bg-dark-900">
                          <h3 className="font-manrope text-2xl lg:text-3xl font-semibold mb-3 text-white group-hover:text-gold-400 transition-colors duration-300">
                            {collection.title}
                          </h3>
                          <p className="text-gray-300 mb-6 font-light leading-relaxed text-base line-clamp-3">
                            {collection.description}
                          </p>
                          
                          {/* Price and Action Row */}
                          <div className="flex items-center justify-between mb-6">
                            <div className="space-y-1">
                              <div className="text-gold-400 font-semibold text-base">
                                {collection.price}
                              </div>
                              <div className="text-xs text-gray-400">
                                Стартовая стоимость
                              </div>
                            </div>
                            
                            {/* View Details Link */}
                            <Link 
                              to={`/collection/${collection.slug}`}
                              className="flex items-center text-gold-400 group-hover:text-white transition-colors duration-300"
                            >
                              <span className="text-sm font-medium uppercase tracking-wider mr-2">Подробнее</span>
                              <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform duration-300" />
                            </Link>
                          </div>
                          
                          {/* Centered Brief Button */}
                          <div className="text-center">
                            <Link to={`/collection/${collection.slug}/brief`}>
                              <Button
                                variant="primary"
                                size="lg"
                                className="w-full"
                              >
                                Пройти бриф
                              </Button>
                            </Link>
                          </div>
                        </div>
                      </div>
                    </AnimatedSection>
                  ))}
                </div>
              )}

              {/* List View */}
              {viewMode === 'list' && (
                <div className="space-y-8">
                  {filteredAndSortedCollections.map((collection, index) => (
                    <AnimatedSection key={collection.id}>
                      <div className="bg-dark-900/50 backdrop-blur-sm border border-gold-400/10 hover:border-gold-400/30 transition-all duration-500 hover:scale-[1.01] rounded-xl overflow-hidden">
                        <div className="grid grid-cols-1 lg:grid-cols-3 gap-0 lg:gap-8 items-stretch">
                          {/* Image */}
                          <div className="lg:col-span-1 relative">
                            <OptimizedImage
                              src={collection.image}
                              alt={collection.title}
                              className="aspect-[4/3] lg:aspect-[4/3] group-hover:scale-105 transition-transform duration-500"
                              loading={index === 0 ? 'eager' : 'lazy'}
                              aspectRatio="4/3"
                            />
                            
                            {/* Gallery Preview for List View */}
                            {collection.gallery && collection.gallery.length > 1 && (
                              <div className="absolute bottom-2 right-2 flex space-x-1">
                                {collection.gallery.slice(1, 4).map((image, imgIndex) => (
                                  <div key={imgIndex} className="w-8 h-8 rounded overflow-hidden border border-white/20">
                                    <OptimizedImage
                                      src={image}
                                      alt={`${collection.title} - миниатюра ${imgIndex + 1}`}
                                      className="w-full h-full object-cover"
                                      loading="lazy"
                                    />
                                  </div>
                                ))}
                              </div>
                            )}
                          </div>

                          {/* Content */}
                          <div className="lg:col-span-2 p-6 lg:p-8 space-y-4 relative z-10">
                            <div>
                              <h3 className="font-manrope text-2xl lg:text-3xl font-semibold text-white mb-3 hover:text-gold-400 transition-colors duration-300">
                                {collection.title}
                              </h3>
                              <p className="text-gray-200 leading-relaxed font-light text-base line-clamp-4">
                                {collection.detailedDescription}
                              </p>
                            </div>

                            {/* Features Preview */}
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                              {collection.features.slice(0, 4).map((feature, idx) => (
                                <div key={idx} className="flex items-start text-sm">
                                  <span className="text-gold-400 mr-2 mt-1 font-semibold flex-shrink-0">✓</span>
                                  <span className="text-gray-200 line-clamp-2">{feature}</span>
                                </div>
                              ))}
                            </div>

                            {/* Price and Actions */}
                            <div className="flex items-center justify-between pt-4 border-t border-gray-700">
                              <div className="space-y-1">
                                <div className="text-gold-400 font-semibold text-lg">
                                  {collection.price}
                                </div>
                                <div className="text-sm text-gray-300">
                                  Стартовая стоимость
                                </div>
                              </div>
                              
                              {/* Action Buttons */}
                              <div className="flex items-center space-x-4">
                                <Link 
                                  to={`/collection/${collection.slug}`}
                                  className="flex items-center text-gold-400 hover:text-white transition-colors duration-300 bg-dark-800/50 backdrop-blur-sm px-4 py-2 rounded-lg border border-gold-400/20 hover:border-gold-400/50"
                                >
                                  <span className="text-sm font-medium uppercase tracking-wider mr-2">Подробнее</span>
                                  <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform duration-300" />
                                </Link>
                                
                                <Link to={`/collection/${collection.slug}/brief`}>
                                  <Button variant="primary" size="md">
                                    Пройти бриф
                                  </Button>
                                </Link>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </AnimatedSection>
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 lg:py-24 bg-dark-900">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <AnimatedSection>
            <h2 className="font-manrope text-3xl lg:text-4xl font-medium text-white mb-8">
              Не нашли подходящую коллекцию?
            </h2>
          </AnimatedSection>

          <AnimatedSection>
            <p className="text-lg text-gray-300 mb-12 max-w-2xl mx-auto font-light">
              Наши специалисты помогут создать индивидуальный проект кухни, 
              учитывающий все ваши пожелания и особенности помещения.
            </p>
          </AnimatedSection>

          <AnimatedSection>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                variant="primary"
                size="lg"
                href="tel:+78005553535"
                className="flex items-center justify-center space-x-2"
              >
                <span>Заказать консультацию</span>
              </Button>
              <Button
                variant="outline"
                size="lg"
                href="https://wa.me/78005553535"
                className="flex items-center justify-center space-x-2"
              >
                <MessageCircle size={20} />
                <span>WhatsApp</span>
              </Button>
              <Button
                variant="outline"
                size="lg"
                href="https://t.me/monolit_kitchen"
                className="flex items-center justify-center space-x-2"
              >
                <Send size={20} />
                <span>Telegram</span>
              </Button>
            </div>
          </AnimatedSection>
        </div>
      </section>
    </div>
  );
};