import React from 'react';
import { Hero } from '../components/sections/Hero';
import { About } from '../components/sections/About';
import { Features } from '../components/sections/Features';
import { SavingProcess } from '../components/sections/SavingProcess';
import { Contact } from '../components/sections/Contact';

export const HomePage: React.FC = () => {
  return (
    <main>
      <Hero />
      <About />
      <Features />
      <SavingProcess />
      <Contact />
    </main>
  );
};