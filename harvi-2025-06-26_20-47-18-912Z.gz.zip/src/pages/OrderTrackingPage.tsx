import React, { useState, useEffect } from 'react';
import { useParams, Navigate } from 'react-router-dom';
import { Package, Phone, Mail, Calendar, FileText, ArrowLeft, MessageCircle, Send, AlertCircle } from 'lucide-react';
import { AnimatedSection } from '../components/ui/AnimatedSection';
import { OrderProgressMap } from '../components/order/OrderProgressMap';
import { OrderAnalytics } from '../components/order/OrderAnalytics';
import { OrderProgressChart } from '../components/order/OrderProgressChart';
import { OrderSearch } from '../components/order/OrderSearch';
import { OrderSearchResults } from '../components/order/OrderSearchResults';
import { Button } from '../components/ui/Button';
import { LoadingSpinner } from '../components/ui/LoadingSpinner';
import { ErrorMessage } from '../components/ui/ErrorMessage';
import { adminService } from '../services/adminService';
import { formatWorkingDaysText } from '../utils/workingDays';
import type { Order } from '../types/order';

export const OrderTrackingPage: React.FC = () => {
  const { orderNumber } = useParams<{ orderNumber: string }>();
  const [order, setOrder] = useState<Order | null>(null);
  const [searchResults, setSearchResults] = useState<Order[]>([]);
  const [selectedStage, setSelectedStage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showSearch, setShowSearch] = useState(!orderNumber);
  const [retryCount, setRetryCount] = useState(0);

  useEffect(() => {
    if (orderNumber && orderNumber !== 'search') {
      loadOrderByNumber(orderNumber);
    } else {
      setShowSearch(true);
    }
  }, [orderNumber]);

  const loadOrderByNumber = async (orderNum: string) => {
    // Валидация формата номера заказа
    if (!orderNum || !orderNum.match(/^MNL-\d{4}-\d{3}$/i)) {
      setError(`Некорректный формат номера заказа: ${orderNum}. Ожидается формат MNL-YYYY-XXX`);
      setShowSearch(true);
      return;
    }

    setIsLoading(true);
    setError(null);
    
    try {
      const foundOrder = await adminService.getOrderByNumber(orderNum.toUpperCase());
      
      if (foundOrder) {
        setOrder(foundOrder);
        setShowSearch(false);
        setRetryCount(0);
        
        // Обновляем URL без перезагрузки страницы
        if (window.location.pathname !== `/order/${foundOrder.orderNumber}`) {
          window.history.replaceState(null, '', `/order/${foundOrder.orderNumber}`);
        }
      } else {
        setError(`Заказ с номером ${orderNum} не найден. Проверьте правильность номера или воспользуйтесь поиском.`);
        setShowSearch(true);
      }
    } catch (err) {
      console.error('Ошибка загрузки заказа:', err);
      setError('Ошибка загрузки данных заказа. Проверьте подключение к интернету.');
      setShowSearch(true);
    } finally {
      setIsLoading(false);
    }
  };

  const handleRetryLoad = () => {
    if (orderNumber && retryCount < 3) {
      setRetryCount(prev => prev + 1);
      loadOrderByNumber(orderNumber);
    }
  };

  const handleOrderFound = (orders: Order[]) => {
    setError(null);
    setRetryCount(0);
    
    if (orders.length === 1) {
      setOrder(orders[0]);
      setShowSearch(false);
      setSearchResults([]);
      
      // Обновляем URL
      window.history.pushState(null, '', `/order/${orders[0].orderNumber}`);
    } else if (orders.length > 1) {
      setSearchResults(orders);
      setOrder(null);
      setShowSearch(false);
    } else {
      setSearchResults([]);
      setOrder(null);
    }
  };

  const handleSearchError = (errorMessage: string) => {
    setError(errorMessage);
    setSearchResults([]);
    setOrder(null);
  };

  const handleSelectOrder = (selectedOrder: Order) => {
    setOrder(selectedOrder);
    setSearchResults([]);
    setShowSearch(false);
    setError(null);
    
    // Обновляем URL без перезагрузки страницы
    window.history.pushState(null, '', `/order/${selectedOrder.orderNumber}`);
  };

  const handleNewSearch = () => {
    setOrder(null);
    setSearchResults([]);
    setError(null);
    setShowSearch(true);
    setRetryCount(0);
    
    // Возвращаемся к базовому URL
    window.history.pushState(null, '', '/order/search');
  };

  const handleStageClick = (stageId: string) => {
    setSelectedStage(selectedStage === stageId ? null : stageId);
  };

  // Обработка состояния загрузки
  if (isLoading) {
    return (
      <div className="min-h-screen bg-dark-950 pt-20 flex items-center justify-center">
        <div className="text-center max-w-md mx-auto">
          <LoadingSpinner size="lg" className="text-gold-400 mx-auto mb-4" />
          <h2 className="text-xl font-medium text-white mb-2">
            Загрузка информации о заказе
          </h2>
          <p className="text-gray-400">
            {orderNumber ? `Поиск заказа ${orderNumber}...` : 'Загрузка данных...'}
          </p>
          {retryCount > 0 && (
            <p className="text-sm text-gray-500 mt-2">
              Попытка {retryCount} из 3
            </p>
          )}
        </div>
      </div>
    );
  }

  // Показываем поиск, если нет заказа или есть результаты поиска
  if (showSearch || searchResults.length > 0) {
    return (
      <div className="min-h-screen bg-dark-950 pt-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <AnimatedSection>
            <div className="text-center mb-12">
              <h1 className="font-manrope text-3xl lg:text-4xl font-medium text-white mb-4">
                Отслеживание заказа
              </h1>
              <p className="text-gray-300">
                Найдите свой заказ по номеру телефона или номеру заказа
              </p>
            </div>
          </AnimatedSection>

          {error && (
            <AnimatedSection>
              <div className="max-w-2xl mx-auto mb-8">
                <ErrorMessage 
                  message={error} 
                  onRetry={orderNumber && retryCount < 3 ? handleRetryLoad : undefined}
                />
              </div>
            </AnimatedSection>
          )}

          {searchResults.length > 0 ? (
            <OrderSearchResults
              orders={searchResults}
              onSelectOrder={handleSelectOrder}
              onNewSearch={handleNewSearch}
            />
          ) : (
            <AnimatedSection>
              <OrderSearch
                onOrderFound={handleOrderFound}
                onError={handleSearchError}
              />
            </AnimatedSection>
          )}
        </div>
      </div>
    );
  }

  // Показываем детали заказа
  if (!order) {
    return <Navigate to="/order/search" replace />;
  }

  const selectedStageData = selectedStage 
    ? order.stages.find(s => s.id === selectedStage)
    : null;

  return (
    <div className="min-h-screen bg-dark-950 pt-20">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Header */}
        <AnimatedSection>
          <div className="text-center mb-12">
            <div className="flex items-center justify-center space-x-4 mb-4">
              <Button
                variant="outline"
                size="sm"
                onClick={handleNewSearch}
                className="flex items-center space-x-2"
              >
                <ArrowLeft size={16} />
                <span>Новый поиск</span>
              </Button>
              <h1 className="font-manrope text-3xl lg:text-4xl font-medium text-white">
                Заказ {order.orderNumber}
              </h1>
            </div>
            
            {/* Статус заказа */}
            <div className="flex items-center justify-center space-x-4 mb-4">
              {order.isOverdue && (
                <div className="flex items-center space-x-2 px-4 py-2 bg-red-900/20 border border-red-500/30 rounded-full">
                  <AlertCircle size={16} className="text-red-400" />
                  <span className="text-red-300 text-sm font-medium">Просрочен</span>
                </div>
              )}
              
              <div className="flex items-center space-x-2 px-4 py-2 bg-gold-400/20 border border-gold-400/30 rounded-full">
                <Package size={16} className="text-gold-400" />
                <span className="text-gold-300 text-sm font-medium">
                  Прогресс: {Math.round(order.totalProgress)}%
                </span>
              </div>
            </div>
            
            <p className="text-sm text-gray-400">
              * Все сроки указаны в рабочих днях (пн-пт, исключая праздники)
            </p>
          </div>
        </AnimatedSection>

        {/* Order Info */}
        <AnimatedSection>
          <div className="bg-dark-900/50 backdrop-blur-sm border border-gold-400/10 p-6 mb-12 rounded-xl">
            <h2 className="font-manrope text-lg font-medium text-white mb-4">
              Информация о заказе
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="flex items-center space-x-3">
                <Phone size={20} className="text-gold-400 flex-shrink-0" />
                <div>
                  <p className="text-sm text-gray-400">Контактный телефон</p>
                  <p className="text-white font-medium">{order.customerPhone}</p>
                </div>
              </div>
              
              {order.customerEmail && (
                <div className="flex items-center space-x-3">
                  <Mail size={20} className="text-gold-400 flex-shrink-0" />
                  <div>
                    <p className="text-sm text-gray-400">Email</p>
                    <p className="text-white font-medium">{order.customerEmail}</p>
                  </div>
                </div>
              )}
              
              <div className="flex items-center space-x-3">
                <Calendar size={20} className="text-gold-400 flex-shrink-0" />
                <div>
                  <p className="text-sm text-gray-400">Дата создания</p>
                  <p className="text-white font-medium">
                    {order.createdDate.toLocaleDateString('ru-RU')}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </AnimatedSection>

        {/* Analytics */}
        <div className="mb-12">
          <OrderAnalytics order={order} />
        </div>

        {/* Progress Chart */}
        <div className="mb-12">
          <OrderProgressChart order={order} />
        </div>

        {/* Progress Map */}
        <AnimatedSection>
          <div className="mb-12">
            <h2 className="font-manrope text-2xl font-medium text-white mb-8 text-center">
              Карта выполнения заказа
            </h2>
            <OrderProgressMap 
              stages={order.stages} 
              onStageClick={handleStageClick}
              isEditable={false}
            />
          </div>
        </AnimatedSection>

        {/* Stage Details */}
        {selectedStageData && (
          <AnimatedSection>
            <div className="bg-dark-900/50 backdrop-blur-sm border border-gold-400/20 p-8 mb-12 rounded-xl">
              <div className="flex items-center justify-between mb-6">
                <h3 className="font-manrope text-xl font-medium text-white">
                  Детали этапа: {selectedStageData.title}
                </h3>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setSelectedStage(null)}
                  className="text-xs"
                >
                  Закрыть
                </Button>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <p className="text-gray-300 mb-4">
                    {selectedStageData.description}
                  </p>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Статус:</span>
                      <span className={`font-medium
                        ${selectedStageData.status === 'completed' ? 'text-green-400' : ''}
                        ${selectedStageData.status === 'current' || selectedStageData.status === 'in-progress' ? 'text-gold-400' : ''}
                        ${selectedStageData.status === 'pending' ? 'text-gray-400' : ''}
                      `}>
                        {selectedStageData.status === 'completed' && 'Завершен'}
                        {(selectedStageData.status === 'current' || selectedStageData.status === 'in-progress') && 'В работе'}
                        {selectedStageData.status === 'pending' && 'Ожидает'}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Длительность:</span>
                      <span className="text-white">{formatWorkingDaysText(selectedStageData.estimatedDuration)}</span>
                    </div>
                    {selectedStageData.isFlexibleTiming && (
                      <div className="flex justify-between">
                        <span className="text-gray-400">Тип планирования:</span>
                        <span className="text-blue-400">Гибкий график</span>
                      </div>
                    )}
                    {selectedStageData.estimatedStartDate && (
                      <div className="flex justify-between">
                        <span className="text-gray-400">Планируемое начало:</span>
                        <span className="text-white">
                          {selectedStageData.estimatedStartDate.toLocaleDateString('ru-RU')}
                        </span>
                      </div>
                    )}
                    {selectedStageData.estimatedEndDate && (
                      <div className="flex justify-between">
                        <span className="text-gray-400">Планируемое завершение:</span>
                        <span className="text-white">
                          {selectedStageData.estimatedEndDate.toLocaleDateString('ru-RU')}
                        </span>
                      </div>
                    )}
                  </div>
                </div>
                
                {(selectedStageData.status === 'current' || selectedStageData.status === 'in-progress') && (
                  <div>
                    <p className="text-sm text-gray-400 mb-2">Прогресс выполнения</p>
                    <div className="w-full bg-gray-700 h-3 rounded-full overflow-hidden mb-2">
                      <div
                        className="h-full bg-gold-400 transition-all duration-500"
                        style={{ width: `${selectedStageData.progress}%` }}
                      />
                    </div>
                    <p className="text-right text-sm text-gold-400">
                      {selectedStageData.progress}%
                    </p>
                    
                    {selectedStageData.checklist && selectedStageData.checklist.length > 0 && (
                      <div className="mt-4">
                        <p className="text-sm text-gray-400 mb-2">Выполненные задачи:</p>
                        <div className="space-y-1">
                          {selectedStageData.checklist.slice(0, 3).map((item, index) => (
                            <div key={index} className="flex items-center space-x-2 text-xs">
                              <div className={`w-2 h-2 rounded-full ${item.isCompleted ? 'bg-green-400' : 'bg-gray-600'}`}></div>
                              <span className={item.isCompleted ? 'text-green-300' : 'text-gray-400'}>
                                {item.title}
                              </span>
                            </div>
                          ))}
                          {selectedStageData.checklist.length > 3 && (
                            <p className="text-xs text-gray-500 ml-4">
                              и еще {selectedStageData.checklist.length - 3} задач...
                            </p>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          </AnimatedSection>
        )}

        {/* Notes */}
        {order.notes && order.notes.length > 0 && (
          <AnimatedSection>
            <div className="bg-dark-900/50 backdrop-blur-sm border border-gold-400/10 p-8 mb-12 rounded-xl">
              <h3 className="font-manrope text-xl font-medium text-white mb-6 flex items-center">
                <FileText size={20} className="mr-3 text-gold-400" />
                История заказа
              </h3>
              <div className="space-y-3 max-h-60 overflow-y-auto">
                {order.notes.map((note, index) => (
                  <div key={index} className="flex items-start space-x-3 p-3 bg-dark-800/30 rounded-lg">
                    <div className="w-2 h-2 bg-gold-400 rounded-full mt-2 flex-shrink-0"></div>
                    <p className="text-gray-300 text-sm">{note}</p>
                  </div>
                ))}
              </div>
            </div>
          </AnimatedSection>
        )}

        {/* Contact Support */}
        <AnimatedSection>
          <div className="text-center mt-12">
            <h3 className="font-manrope text-xl font-medium text-white mb-4">
              Есть вопросы по заказу?
            </h3>
            <p className="text-gray-300 mb-6">
              Свяжитесь с нашим менеджером для получения дополнительной информации
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                variant="primary"
                size="lg"
                href="tel:+78005553535"
                className="flex items-center justify-center space-x-2"
              >
                <Phone size={20} />
                <span>+7 (800) 555-35-35</span>
              </Button>
              <Button
                variant="outline"
                size="lg"
                href="https://wa.me/78005553535"
                className="flex items-center justify-center space-x-2"
              >
                <MessageCircle size={20} />
                <span>WhatsApp</span>
              </Button>
              <Button
                variant="outline"
                size="lg"
                href="https://t.me/monolit_kitchen"
                className="flex items-center justify-center space-x-2"
              >
                <Send size={20} />
                <span>Telegram</span>
              </Button>
            </div>
          </div>
        </AnimatedSection>
      </div>
    </div>
  );
};