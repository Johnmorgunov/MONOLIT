import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  BookOpen, 
  Camera, 
  Search, 
  Filter, 
  Calendar,
  User,
  Clock,
  ArrowRight,
  Tag,
  Grid,
  List
} from 'lucide-react';
import { AnimatedSection } from '../components/ui/AnimatedSection';
import { OptimizedImage } from '../components/ui/OptimizedImage';
import { Button } from '../components/ui/Button';
import { contentService } from '../services/contentService';
import type { BlogPost, BlogCategory, WorkPhoto } from '../types';

type ContentType = 'all' | 'articles' | 'photos';
type ViewMode = 'grid' | 'list';

export const UsefulPage: React.FC = () => {
  const [contentType, setContentType] = useState<ContentType>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [viewMode, setViewMode] = useState<ViewMode>('grid');

  // Состояние для данных
  const [blogPosts, setBlogPosts] = useState<BlogPost[]>([]);
  const [blogCategories, setBlogCategories] = useState<BlogCategory[]>([]);
  const [workPhotos, setWorkPhotos] = useState<WorkPhoto[]>([]);

  // Загружаем данные при монтировании компонента
  useEffect(() => {
    setBlogPosts(contentService.getBlogPosts());
    setBlogCategories(contentService.getBlogCategories());
    setWorkPhotos(contentService.getWorkPhotos());
  }, []);

  const filteredArticles = React.useMemo(() => {
    let articles = blogPosts.filter(post => post.isPublished);
    
    if (selectedCategory !== 'all') {
      articles = articles.filter(post => post.category.slug === selectedCategory);
    }
    
    if (searchQuery) {
      articles = articles.filter(post => 
        post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        post.excerpt.toLowerCase().includes(searchQuery.toLowerCase()) ||
        post.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
      );
    }
    
    return articles.sort((a, b) => b.publishedAt.getTime() - a.publishedAt.getTime());
  }, [blogPosts, selectedCategory, searchQuery]);

  const filteredPhotos = React.useMemo(() => {
    let photos = workPhotos.filter(photo => photo.isPublished);
    
    if (searchQuery) {
      photos = photos.filter(photo => 
        photo.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        photo.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        photo.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
      );
    }
    
    return photos.sort((a, b) => b.uploadedAt.getTime() - a.uploadedAt.getTime());
  }, [workPhotos, searchQuery]);

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('ru-RU', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const getCategoryColor = (category: BlogCategory) => {
    return { backgroundColor: category.color + '20', borderColor: category.color + '40', color: category.color };
  };

  return (
    <div className="min-h-screen bg-dark-950 pt-20">
      {/* Hero Section */}
      <section className="py-16 lg:py-24 bg-dark-900">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <AnimatedSection>
            <div className="text-center max-w-4xl mx-auto">
              <h1 className="font-manrope text-4xl lg:text-6xl font-medium text-white mb-6">
                <span className="text-gold-400">Полезное</span> о кухнях
              </h1>
              <p className="text-xl text-gray-300 leading-relaxed font-light">
                Экспертные статьи, советы по дизайну, обзоры материалов и фотографии наших работ. 
                Все, что нужно знать о создании идеальной кухни.
              </p>
            </div>
          </AnimatedSection>
        </div>
      </section>

      {/* Filters and Controls */}
      <section className="py-8 bg-dark-900/50 border-b border-gold-400/10 sticky top-20 z-40 backdrop-blur-lg">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <AnimatedSection>
            <div className="space-y-6">
              {/* Content Type Tabs */}
              <div className="flex flex-wrap gap-2 justify-center">
                {[
                  { key: 'all', label: 'Все материалы', icon: <BookOpen size={16} /> },
                  { key: 'articles', label: 'Статьи', icon: <BookOpen size={16} /> },
                  { key: 'photos', label: 'Фото работ', icon: <Camera size={16} /> }
                ].map(tab => (
                  <button
                    key={tab.key}
                    onClick={() => setContentType(tab.key as ContentType)}
                    className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-all duration-300 ${
                      contentType === tab.key
                        ? 'bg-gold-400 text-black'
                        : 'bg-dark-800 text-white hover:bg-dark-700'
                    }`}
                  >
                    {tab.icon}
                    <span>{tab.label}</span>
                  </button>
                ))}
              </div>

              {/* Search and Filters */}
              <div className="flex flex-col lg:flex-row gap-4 items-center justify-between">
                {/* Search */}
                <div className="relative flex-1 max-w-md">
                  <Search size={20} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Поиск по статьям и фото..."
                    className="w-full pl-10 pr-4 py-3 bg-dark-800 border border-gray-600 text-white focus:outline-none focus:border-gold-400 transition-colors duration-300 rounded-xl"
                  />
                </div>

                <div className="flex items-center gap-4">
                  {/* Category Filter (только для статей) */}
                  {(contentType === 'all' || contentType === 'articles') && (
                    <div className="flex items-center space-x-2">
                      <Filter size={16} className="text-gray-400" />
                      <select
                        value={selectedCategory}
                        onChange={(e) => setSelectedCategory(e.target.value)}
                        className="bg-dark-800 border border-gray-600 text-white px-3 py-2 focus:outline-none focus:border-gold-400 rounded-lg"
                      >
                        <option value="all">Все категории</option>
                        {blogCategories.map(category => (
                          <option key={category.id} value={category.slug}>
                            {category.name}
                          </option>
                        ))}
                      </select>
                    </div>
                  )}

                  {/* View Mode */}
                  <div className="flex border border-gray-600 overflow-hidden rounded-lg">
                    <button
                      onClick={() => setViewMode('grid')}
                      className={`p-2 transition-colors duration-300 ${
                        viewMode === 'grid' 
                          ? 'bg-gold-400 text-black' 
                          : 'bg-dark-800 text-white hover:bg-dark-700'
                      }`}
                    >
                      <Grid size={16} />
                    </button>
                    <button
                      onClick={() => setViewMode('list')}
                      className={`p-2 transition-colors duration-300 ${
                        viewMode === 'list' 
                          ? 'bg-gold-400 text-black' 
                          : 'bg-dark-800 text-white hover:bg-dark-700'
                      }`}
                    >
                      <List size={16} />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </AnimatedSection>
        </div>
      </section>

      {/* Content */}
      <section className="py-16 lg:py-24">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          {/* Articles Section */}
          {(contentType === 'all' || contentType === 'articles') && filteredArticles.length > 0 && (
            <div className="mb-16">
              <AnimatedSection>
                <h2 className="font-manrope text-2xl lg:text-3xl font-medium text-white mb-8">
                  {contentType === 'all' ? 'Полезные статьи' : 'Статьи'}
                  <span className="text-gray-400 text-lg ml-2">({filteredArticles.length})</span>
                </h2>
              </AnimatedSection>

              {viewMode === 'grid' ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                  {filteredArticles.map((post, index) => (
                    <AnimatedSection key={post.id}>
                      <article className="bg-dark-900/50 backdrop-blur-sm border border-gold-400/10 hover:border-gold-400/30 transition-all duration-500 hover:scale-[1.02] rounded-xl overflow-hidden group">
                        <div className="aspect-[16/10] overflow-hidden">
                          <OptimizedImage
                            src={post.featuredImage}
                            alt={post.title}
                            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                            loading={index < 3 ? 'eager' : 'lazy'}
                          />
                        </div>
                        
                        <div className="p-6">
                          {/* Category and Date */}
                          <div className="flex items-center justify-between mb-3">
                            <span 
                              className="px-3 py-1 text-xs font-medium rounded-full border"
                              style={getCategoryColor(post.category)}
                            >
                              {post.category.name}
                            </span>
                            <div className="flex items-center text-xs text-gray-400">
                              <Calendar size={12} className="mr-1" />
                              {formatDate(post.publishedAt)}
                            </div>
                          </div>

                          <h3 className="font-manrope text-lg font-medium text-white mb-3 group-hover:text-gold-400 transition-colors duration-300 line-clamp-2">
                            {post.title}
                          </h3>
                          
                          <p className="text-gray-300 text-sm mb-4 line-clamp-3">
                            {post.excerpt}
                          </p>

                          {/* Meta Info */}
                          <div className="flex items-center justify-between text-xs text-gray-400 mb-4">
                            <div className="flex items-center">
                              <User size={12} className="mr-1" />
                              {post.author}
                            </div>
                            <div className="flex items-center">
                              <Clock size={12} className="mr-1" />
                              {post.readTime} мин
                            </div>
                          </div>

                          {/* Tags */}
                          <div className="flex flex-wrap gap-1 mb-4">
                            {post.tags.slice(0, 3).map(tag => (
                              <span key={tag} className="px-2 py-1 bg-dark-800 text-gray-400 text-xs rounded">
                                #{tag}
                              </span>
                            ))}
                          </div>

                          <Link 
                            to={`/useful/article/${post.slug}`}
                            className="inline-flex items-center text-gold-400 hover:text-white transition-colors duration-300 text-sm font-medium"
                          >
                            Читать далее
                            <ArrowRight size={14} className="ml-1 group-hover:translate-x-1 transition-transform duration-300" />
                          </Link>
                        </div>
                      </article>
                    </AnimatedSection>
                  ))}
                </div>
              ) : (
                <div className="space-y-6">
                  {filteredArticles.map((post, index) => (
                    <AnimatedSection key={post.id}>
                      <article className="bg-dark-900/50 backdrop-blur-sm border border-gold-400/10 hover:border-gold-400/30 transition-all duration-500 rounded-xl overflow-hidden">
                        <Link to={`/useful/article/${post.slug}`} className="block">
                          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 p-6">
                            <div className="lg:col-span-1">
                              <OptimizedImage
                                src={post.featuredImage}
                                alt={post.title}
                                className="aspect-[16/10] rounded-lg"
                                loading={index < 3 ? 'eager' : 'lazy'}
                              />
                            </div>
                            
                            <div className="lg:col-span-3 space-y-3">
                              <div className="flex items-center justify-between">
                                <span 
                                  className="px-3 py-1 text-xs font-medium rounded-full border"
                                  style={getCategoryColor(post.category)}
                                >
                                  {post.category.name}
                                </span>
                                <div className="flex items-center text-xs text-gray-400">
                                  <Calendar size={12} className="mr-1" />
                                  {formatDate(post.publishedAt)}
                                </div>
                              </div>

                              <h3 className="font-manrope text-xl font-medium text-white hover:text-gold-400 transition-colors duration-300">
                                {post.title}
                              </h3>
                              
                              <p className="text-gray-300 line-clamp-2">
                                {post.excerpt}
                              </p>

                              <div className="flex items-center justify-between">
                                <div className="flex items-center space-x-4 text-xs text-gray-400">
                                  <div className="flex items-center">
                                    <User size={12} className="mr-1" />
                                    {post.author}
                                  </div>
                                  <div className="flex items-center">
                                    <Clock size={12} className="mr-1" />
                                    {post.readTime} мин
                                  </div>
                                </div>
                                
                                <div className="flex items-center text-gold-400 hover:text-white transition-colors duration-300">
                                  <span className="text-sm font-medium mr-1">Читать</span>
                                  <ArrowRight size={14} />
                                </div>
                              </div>
                            </div>
                          </div>
                        </Link>
                      </article>
                    </AnimatedSection>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Photos Section */}
          {(contentType === 'all' || contentType === 'photos') && filteredPhotos.length > 0 && (
            <div>
              <AnimatedSection>
                <h2 className="font-manrope text-2xl lg:text-3xl font-medium text-white mb-8">
                  {contentType === 'all' ? 'Фотографии наших работ' : 'Фото работ'}
                  <span className="text-gray-400 text-lg ml-2">({filteredPhotos.length})</span>
                </h2>
              </AnimatedSection>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {filteredPhotos.map((photo, index) => (
                  <AnimatedSection key={photo.id}>
                    <div className="bg-dark-900/50 backdrop-blur-sm border border-gold-400/10 hover:border-gold-400/30 transition-all duration-500 hover:scale-[1.02] rounded-xl overflow-hidden group">
                      <div className="aspect-square overflow-hidden">
                        <OptimizedImage
                          src={photo.imageUrl}
                          alt={photo.title}
                          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                          loading={index < 8 ? 'eager' : 'lazy'}
                        />
                      </div>
                      
                      <div className="p-4">
                        <h3 className="font-medium text-white mb-2 line-clamp-2 group-hover:text-gold-400 transition-colors duration-300">
                          {photo.title}
                        </h3>
                        
                        <p className="text-gray-400 text-sm mb-3 line-clamp-2">
                          {photo.description}
                        </p>

                        <div className="flex flex-wrap gap-1 mb-3">
                          {photo.tags.slice(0, 2).map(tag => (
                            <span key={tag} className="px-2 py-1 bg-dark-800 text-gray-400 text-xs rounded">
                              #{tag}
                            </span>
                          ))}
                        </div>

                        <div className="flex items-center justify-between text-xs text-gray-400">
                          <span className="capitalize">{photo.category}</span>
                          <span>{formatDate(photo.uploadedAt)}</span>
                        </div>
                      </div>
                    </div>
                  </AnimatedSection>
                ))}
              </div>
            </div>
          )}

          {/* No Results */}
          {((contentType === 'articles' && filteredArticles.length === 0) || 
            (contentType === 'photos' && filteredPhotos.length === 0) ||
            (contentType === 'all' && filteredArticles.length === 0 && filteredPhotos.length === 0)) && (
            <AnimatedSection>
              <div className="text-center py-16">
                <div className="w-24 h-24 bg-dark-800 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Search size={32} className="text-gray-400" />
                </div>
                <h3 className="font-manrope text-xl font-medium text-white mb-4">
                  Ничего не найдено
                </h3>
                <p className="text-gray-400 mb-6">
                  Попробуйте изменить параметры поиска или фильтры
                </p>
                <Button
                  variant="outline"
                  onClick={() => {
                    setSearchQuery('');
                    setSelectedCategory('all');
                    setContentType('all');
                  }}
                >
                  Сбросить фильтры
                </Button>
              </div>
            </AnimatedSection>
          )}
        </div>
      </section>
    </div>
  );
};