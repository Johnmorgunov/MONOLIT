import type { Order, OrderStage, ChecklistItem } from '../types/order';
import type { AdminUser, AdminSession, OrderFilter, OrderUpdate, AdminStats } from '../types/admin';
import { createMockOrder } from '../data/mockOrder';
import { orderService } from './orderService';
import { collections } from '../data/collections';

class AdminService {
  private readonly ADMIN_SESSION_KEY = 'admin_session';
  private readonly ORDERS_KEY = 'admin_orders';
  private readonly ADMIN_USERS_KEY = 'admin_users';

  constructor() {
    this.initializeAdminUsers();
    this.initializeOrders();
  }

  private initializeAdminUsers() {
    const existingUsers = localStorage.getItem(this.ADMIN_USERS_KEY);
    if (!existingUsers) {
      const defaultUsers: AdminUser[] = [
        {
          id: 'admin-1',
          username: 'admin',
          role: 'admin'
        },
        {
          id: 'manager-1',
          username: 'manager',
          role: 'manager'
        }
      ];
      localStorage.setItem(this.ADMIN_USERS_KEY, JSON.stringify(defaultUsers));
    }
  }

  private initializeOrders() {
    const existingOrders = localStorage.getItem(this.ORDERS_KEY);
    if (!existingOrders) {
      // Создаем несколько тестовых заказов
      const mockOrders: Order[] = [
        createMockOrder(),
        {
          ...createMockOrder(),
          id: 'order-002',
          orderNumber: 'MNL-2025-002',
          customerName: 'Мария Иванова',
          customerPhone: '+7 (999) 876-54-32',
          customerEmail: 'maria.ivanova@example.com',
          collectionId: 'classic',
          createdDate: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000),
          stages: createMockOrder().stages.map((stage, index) => ({
            ...stage,
            status: index < 3 ? 'completed' : index === 3 ? 'current' : 'pending',
            progress: index < 3 ? 100 : index === 3 ? 40 : 0,
            checklist: stage.checklist.map(item => ({
              ...item,
              isCompleted: index < 3 ? item.isRequired : false
            }))
          }))
        },
        {
          ...createMockOrder(),
          id: 'order-003',
          orderNumber: 'MNL-2025-003',
          customerName: 'Алексей Сидоров',
          customerPhone: '+7 (999) 111-22-33',
          customerEmail: 'alexey.sidorov@example.com',
          collectionId: 'smart',
          createdDate: new Date(Date.now() - 21 * 24 * 60 * 60 * 1000),
          stages: createMockOrder().stages.map(stage => ({
            ...stage,
            status: 'completed',
            progress: 100,
            checklist: stage.checklist.map(item => ({
              ...item,
              isCompleted: true,
              completedAt: new Date(Date.now() - Math.random() * 21 * 24 * 60 * 60 * 1000),
              completedBy: 'admin'
            }))
          }))
        }
      ];

      // Пересчитываем общий прогресс для каждого заказа
      mockOrders.forEach(order => {
        this.recalculateOrderProgress(order);
      });

      localStorage.setItem(this.ORDERS_KEY, JSON.stringify(mockOrders));
    }
  }

  private recalculateOrderProgress(order: Order) {
    // Пересчитываем прогресс чек-листов для каждого этапа
    order.stages.forEach(stage => {
      const completedItems = stage.checklist.filter(item => item.isCompleted).length;
      stage.checklistProgress = stage.checklist.length > 0 ? (completedItems / stage.checklist.length) * 100 : 100;
    });

    // Пересчитываем общий прогресс заказа
    const completedStages = order.stages.filter(s => s.status === 'completed').length;
    const currentStageProgress = order.stages.find(s => s.status === 'current')?.progress || 0;
    order.totalProgress = (completedStages * 100 + currentStageProgress) / order.stages.length;

    // Проверяем просрочку
    const currentStage = order.stages.find(s => s.status === 'current');
    order.isOverdue = currentStage?.schedule?.plannedEndDate ? 
      new Date() > currentStage.schedule.plannedEndDate : false;

    // Находим ближайший дедлайн
    order.nextDeadline = order.stages
      .filter(s => s.status !== 'completed' && s.schedule?.plannedEndDate)
      .sort((a, b) => (a.schedule!.plannedEndDate!.getTime() - b.schedule!.plannedEndDate!.getTime()))[0]?.schedule?.plannedEndDate;
  }

  // Аутентификация
  async login(username: string, password: string): Promise<AdminSession | null> {
    // Простая проверка (в реальном приложении - через API)
    const users: AdminUser[] = JSON.parse(localStorage.getItem(this.ADMIN_USERS_KEY) || '[]');
    const user = users.find(u => u.username === username);
    
    if (user && (password === 'admin123' || password === 'manager123')) {
      const session: AdminSession = {
        user: {
          ...user,
          lastLogin: new Date()
        },
        token: `token_${Date.now()}_${Math.random()}`,
        expiresAt: new Date(Date.now() + 8 * 60 * 60 * 1000) // 8 часов
      };

      localStorage.setItem(this.ADMIN_SESSION_KEY, JSON.stringify(session));
      return session;
    }

    return null;
  }

  logout(): void {
    localStorage.removeItem(this.ADMIN_SESSION_KEY);
  }

  getCurrentSession(): AdminSession | null {
    const sessionData = localStorage.getItem(this.ADMIN_SESSION_KEY);
    if (!sessionData) return null;

    try {
      const session: AdminSession = JSON.parse(sessionData);
      session.expiresAt = new Date(session.expiresAt);
      
      if (session.expiresAt < new Date()) {
        this.logout();
        return null;
      }

      return session;
    } catch {
      return null;
    }
  }

  isAuthenticated(): boolean {
    return this.getCurrentSession() !== null;
  }

  // Управление заказами - используем единое хранилище
  async getOrders(filter?: OrderFilter): Promise<Order[]> {
    // Получаем заказы из единого хранилища (включая созданные из брифов)
    const ordersData = localStorage.getItem(this.ORDERS_KEY);
    if (!ordersData) return [];

    let orders: Order[] = JSON.parse(ordersData);
    
    // Восстанавливаем даты
    orders = orders.map(order => ({
      ...order,
      createdDate: new Date(order.createdDate),
      estimatedCompletionDate: new Date(order.estimatedCompletionDate),
      nextDeadline: order.nextDeadline ? new Date(order.nextDeadline) : undefined,
      stages: order.stages.map(stage => ({
        ...stage,
        estimatedStartDate: stage.estimatedStartDate ? new Date(stage.estimatedStartDate) : undefined,
        estimatedEndDate: stage.estimatedEndDate ? new Date(stage.estimatedEndDate) : undefined,
        schedule: stage.schedule ? {
          ...stage.schedule,
          plannedStartDate: stage.schedule.plannedStartDate ? new Date(stage.schedule.plannedStartDate) : undefined,
          plannedEndDate: stage.schedule.plannedEndDate ? new Date(stage.schedule.plannedEndDate) : undefined,
          actualStartDate: stage.schedule.actualStartDate ? new Date(stage.schedule.actualStartDate) : undefined,
          actualEndDate: stage.schedule.actualEndDate ? new Date(stage.schedule.actualEndDate) : undefined
        } : undefined,
        checklist: stage.checklist.map(item => ({
          ...item,
          completedAt: item.completedAt ? new Date(item.completedAt) : undefined
        }))
      }))
    }));

    // Применяем фильтры
    if (filter) {
      if (filter.status && filter.status !== 'all') {
        orders = orders.filter(order => {
          switch (filter.status) {
            case 'active':
              return order.totalProgress > 0 && order.totalProgress < 100;
            case 'completed':
              return order.totalProgress === 100;
            case 'pending':
              return order.totalProgress === 0;
            case 'overdue':
              return order.isOverdue;
            default:
              return true;
          }
        });
      }

      if (filter.customerPhone) {
        const phoneFilter = filter.customerPhone.replace(/\D/g, '');
        orders = orders.filter(order => 
          order.customerPhone.replace(/\D/g, '').includes(phoneFilter)
        );
      }

      if (filter.customerEmail) {
        orders = orders.filter(order => 
          order.customerEmail?.toLowerCase().includes(filter.customerEmail!.toLowerCase())
        );
      }

      if (filter.orderNumber) {
        orders = orders.filter(order => 
          order.orderNumber.toLowerCase().includes(filter.orderNumber!.toLowerCase())
        );
      }

      if (filter.collectionId) {
        orders = orders.filter(order => order.collectionId === filter.collectionId);
      }

      // Фильтрация по ценовым сегментам
      if (filter.priceRange) {
        orders = orders.filter(order => {
          const collection = collections.find(c => c.id === order.collectionId);
          if (!collection) return false;
          
          switch (filter.priceRange) {
            case 'budget':
              return collection.priceRange.min < 299000;
            case 'medium':
              return collection.priceRange.min >= 299000 && collection.priceRange.min < 349000;
            case 'premium':
              return collection.priceRange.min >= 349000;
            default:
              return true;
          }
        });
      }

      // Фильтрация по точному диапазону цен
      if (filter.priceFrom || filter.priceTo) {
        orders = orders.filter(order => {
          const collection = collections.find(c => c.id === order.collectionId);
          if (!collection) return false;
          
          const minPrice = collection.priceRange.min;
          const maxPrice = collection.priceRange.max;
          
          let matchesFrom = true;
          let matchesTo = true;
          
          if (filter.priceFrom) {
            matchesFrom = minPrice >= filter.priceFrom;
          }
          
          if (filter.priceTo) {
            matchesTo = minPrice <= filter.priceTo;
          }
          
          return matchesFrom && matchesTo;
        });
      }

      if (filter.createdMonth) {
        const [year, month] = filter.createdMonth.split('-').map(Number);
        orders = orders.filter(order => {
          const orderDate = order.createdDate;
          return orderDate.getFullYear() === year && orderDate.getMonth() + 1 === month;
        });
      }

      if (filter.dateFrom) {
        orders = orders.filter(order => order.createdDate >= filter.dateFrom!);
      }

      if (filter.dateTo) {
        const endOfDay = new Date(filter.dateTo);
        endOfDay.setHours(23, 59, 59, 999);
        orders = orders.filter(order => order.createdDate <= endOfDay);
      }
    }

    return orders.sort((a, b) => b.createdDate.getTime() - a.createdDate.getTime());
  }

  async getOrderById(orderId: string): Promise<Order | null> {
    const orders = await this.getOrders();
    return orders.find(order => order.id === orderId) || null;
  }

  async getOrderByNumber(orderNumber: string): Promise<Order | null> {
    const orders = await this.getOrders();
    return orders.find(order => order.orderNumber === orderNumber) || null;
  }

  async getOrderByPhone(phone: string): Promise<Order[]> {
    const phoneDigits = phone.replace(/\D/g, '');
    const orders = await this.getOrders();
    
    return orders.filter(order => {
      const orderPhoneDigits = order.customerPhone.replace(/\D/g, '');
      return orderPhoneDigits.includes(phoneDigits) || phoneDigits.includes(orderPhoneDigits);
    });
  }

  async updateOrder(update: OrderUpdate): Promise<Order | null> {
    const orders = await this.getOrders();
    const orderIndex = orders.findIndex(order => order.id === update.orderId);
    
    if (orderIndex === -1) return null;

    const order = orders[orderIndex];
    const stageIndex = order.stages.findIndex(stage => stage.id === update.stageId);
    
    if (stageIndex === -1) return null;

    // Создаем копию заказа для изменения
    const updatedOrder = { ...order };
    updatedOrder.stages = [...order.stages];

    const currentSession = this.getCurrentSession();
    const username = currentSession?.user.username || 'system';

    switch (update.action) {
      case 'mark_complete':
        updatedOrder.stages[stageIndex] = {
          ...updatedOrder.stages[stageIndex],
          status: 'completed',
          progress: 100,
          canMarkComplete: false,
          canUnmarkComplete: true
        };

        // Активируем следующий этап
        if (stageIndex < updatedOrder.stages.length - 1) {
          updatedOrder.stages[stageIndex + 1] = {
            ...updatedOrder.stages[stageIndex + 1],
            status: 'current',
            progress: 0,
            canMarkComplete: true,
            canUnmarkComplete: false
          };
        }

        // Добавляем запись в историю
        const stageName = updatedOrder.stages[stageIndex].title;
        updatedOrder.notes = [
          ...(updatedOrder.notes || []),
          `Этап "${stageName}" отмечен как выполненный (${username})`
        ];
        break;

      case 'unmark_complete':
        updatedOrder.stages[stageIndex] = {
          ...updatedOrder.stages[stageIndex],
          status: 'current',
          progress: 0,
          canMarkComplete: true,
          canUnmarkComplete: false
        };

        // Возвращаем все последующие этапы в статус pending
        for (let i = stageIndex + 1; i < updatedOrder.stages.length; i++) {
          updatedOrder.stages[i] = {
            ...updatedOrder.stages[i],
            status: 'pending',
            progress: 0,
            canMarkComplete: false,
            canUnmarkComplete: false
          };
        }
        break;

      case 'update_progress':
        if (update.progress !== undefined) {
          updatedOrder.stages[stageIndex] = {
            ...updatedOrder.stages[stageIndex],
            progress: Math.max(0, Math.min(100, update.progress))
          };
        }
        break;

      case 'update_schedule':
        if (update.schedule) {
          const currentSchedule = updatedOrder.stages[stageIndex].schedule || {};
          updatedOrder.stages[stageIndex] = {
            ...updatedOrder.stages[stageIndex],
            schedule: {
              ...currentSchedule,
              ...update.schedule,
              isOverdue: update.schedule.plannedEndDate ? new Date() > update.schedule.plannedEndDate : false,
              daysUntilDeadline: update.schedule.plannedEndDate ? 
                Math.ceil((update.schedule.plannedEndDate.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24)) : undefined
            }
          };

          updatedOrder.notes = [
            ...(updatedOrder.notes || []),
            `Обновлено расписание этапа "${updatedOrder.stages[stageIndex].title}" (${username})`
          ];
        }
        break;

      case 'update_checklist':
        if (update.checklistUpdate) {
          const { itemId, isCompleted } = update.checklistUpdate;
          const checklistItem = updatedOrder.stages[stageIndex].checklist.find(item => item.id === itemId);
          
          if (checklistItem) {
            checklistItem.isCompleted = isCompleted;
            checklistItem.completedAt = isCompleted ? new Date() : undefined;
            checklistItem.completedBy = isCompleted ? username : undefined;

            updatedOrder.notes = [
              ...(updatedOrder.notes || []),
              `${isCompleted ? 'Выполнен' : 'Отменен'} пункт чек-листа: "${checklistItem.title}" (${username})`
            ];
          }
        }

        if (update.newChecklistItem) {
          const newItem: ChecklistItem = {
            ...update.newChecklistItem,
            id: `${update.stageId}_${Date.now()}_${Math.random()}`,
            isCompleted: false
          };
          
          updatedOrder.stages[stageIndex].checklist.push(newItem);
          
          updatedOrder.notes = [
            ...(updatedOrder.notes || []),
            `Добавлен новый пункт чек-листа: "${newItem.title}" (${username})`
          ];
        }
        break;
    }

    // Добавляем заметку если указана
    if (update.note) {
      updatedOrder.notes = [
        ...(updatedOrder.notes || []),
        `Заметка администратора: ${update.note}`
      ];
    }

    // Пересчитываем прогресс
    this.recalculateOrderProgress(updatedOrder);

    // Сохраняем изменения
    orders[orderIndex] = updatedOrder;
    localStorage.setItem(this.ORDERS_KEY, JSON.stringify(orders));

    return updatedOrder;
  }

  async getStatistics(): Promise<AdminStats> {
    const orders = await this.getOrders();
    
    const totalOrders = orders.length;
    const activeOrders = orders.filter(o => o.totalProgress > 0 && o.totalProgress < 100).length;
    const completedOrders = orders.filter(o => o.totalProgress === 100).length;
    const overdueOrders = orders.filter(o => o.isOverdue).length;
    
    // Средний срок выполнения (только для завершенных заказов)
    const completedOrdersWithDuration = orders.filter(o => o.totalProgress === 100);
    const averageCompletionTime = completedOrdersWithDuration.length > 0
      ? completedOrdersWithDuration.reduce((sum, order) => {
          const duration = (new Date().getTime() - order.createdDate.getTime()) / (1000 * 60 * 60 * 24);
          return sum + duration;
        }, 0) / completedOrdersWithDuration.length
      : 0;

    // Статистика по этапам
    const stageStats = new Map<string, { 
      name: string; 
      completed: number; 
      total: number; 
      totalDuration: number;
      overdue: number,
    }>();
    
    orders.forEach(order => {
      order.stages.forEach(stage => {
        if (!stageStats.has(stage.id)) {
          stageStats.set(stage.id, {
            name: stage.title,
            completed: 0,
            total: 0,
            totalDuration: 0,
            overdue: 0
          });
        }
        
        const stats = stageStats.get(stage.id)!;
        stats.total++;
        stats.totalDuration += stage.estimatedDuration;
        
        if (stage.status === 'completed') {
          stats.completed++;
        }

        if (stage.schedule?.isOverdue) {
          stats.overdue++;
        }
      });
    });

    const stageStatistics = Array.from(stageStats.entries()).map(([stageId, stats]) => ({
      stageId,
      stageName: stats.name,
      averageDuration: stats.totalDuration / stats.total,
      completionRate: (stats.completed / stats.total) * 100,
      overdueCount: stats.overdue
    }));

    return {
      totalOrders,
      activeOrders,
      completedOrders,
      overdueOrders,
      averageCompletionTime,
      stageStatistics
    };
  }
}

export const adminService = new AdminService();