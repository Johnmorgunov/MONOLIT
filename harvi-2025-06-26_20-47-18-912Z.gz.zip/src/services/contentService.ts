import type { BlogPost, BlogCategory, WorkPhoto, Collection } from '../types';
import { blogPosts as initialBlogPosts, blogCategories as initialBlogCategories, workPhotos as initialWorkPhotos } from '../data/blog';
import { collections as initialCollections } from '../data/collections';

class ContentService {
  private readonly BLOG_POSTS_KEY = 'blog_posts';
  private readonly BLOG_CATEGORIES_KEY = 'blog_categories';
  private readonly WORK_PHOTOS_KEY = 'work_photos';
  private readonly COLLECTIONS_KEY = 'collections';

  constructor() {
    this.initializeData();
  }

  private initializeData() {
    // Инициализируем данные если их нет
    if (!localStorage.getItem(this.BLOG_POSTS_KEY)) {
      localStorage.setItem(this.BLOG_POSTS_KEY, JSON.stringify(initialBlogPosts));
    }
    if (!localStorage.getItem(this.BLOG_CATEGORIES_KEY)) {
      localStorage.setItem(this.BLOG_CATEGORIES_KEY, JSON.stringify(initialBlogCategories));
    }
    if (!localStorage.getItem(this.WORK_PHOTOS_KEY)) {
      localStorage.setItem(this.WORK_PHOTOS_KEY, JSON.stringify(initialWorkPhotos));
    }
    if (!localStorage.getItem(this.COLLECTIONS_KEY)) {
      localStorage.setItem(this.COLLECTIONS_KEY, JSON.stringify(initialCollections));
    }
  }

  // === BLOG POSTS ===
  getBlogPosts(): BlogPost[] {
    const data = localStorage.getItem(this.BLOG_POSTS_KEY);
    if (!data) return [];
    
    return JSON.parse(data).map((post: any) => ({
      ...post,
      publishedAt: new Date(post.publishedAt),
      updatedAt: new Date(post.updatedAt)
    }));
  }

  getBlogPostBySlug(slug: string): BlogPost | undefined {
    return this.getBlogPosts().find(post => post.slug === slug && post.isPublished);
  }

  getBlogPostById(id: string): BlogPost | undefined {
    return this.getBlogPosts().find(post => post.id === id);
  }

  saveBlogPost(post: Omit<BlogPost, 'id' | 'publishedAt' | 'updatedAt'> | BlogPost): BlogPost {
    const posts = this.getBlogPosts();
    const now = new Date();
    
    let savedPost: BlogPost;
    
    if ('id' in post && post.id) {
      // Обновление существующей статьи
      const index = posts.findIndex(p => p.id === post.id);
      if (index === -1) throw new Error('Статья не найдена');
      
      savedPost = {
        ...post,
        updatedAt: now
      };
      posts[index] = savedPost;
    } else {
      // Создание новой статьи
      savedPost = {
        ...post,
        id: `post_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        publishedAt: now,
        updatedAt: now
      } as BlogPost;
      posts.push(savedPost);
    }
    
    localStorage.setItem(this.BLOG_POSTS_KEY, JSON.stringify(posts));
    return savedPost;
  }

  deleteBlogPost(id: string): boolean {
    const posts = this.getBlogPosts();
    const index = posts.findIndex(p => p.id === id);
    if (index === -1) return false;
    
    posts.splice(index, 1);
    localStorage.setItem(this.BLOG_POSTS_KEY, JSON.stringify(posts));
    return true;
  }

  // === BLOG CATEGORIES ===
  getBlogCategories(): BlogCategory[] {
    const data = localStorage.getItem(this.BLOG_CATEGORIES_KEY);
    return data ? JSON.parse(data) : [];
  }

  saveBlogCategory(category: Omit<BlogCategory, 'id'> | BlogCategory): BlogCategory {
    const categories = this.getBlogCategories();
    
    let savedCategory: BlogCategory;
    
    if ('id' in category && category.id) {
      // Обновление существующей категории
      const index = categories.findIndex(c => c.id === category.id);
      if (index === -1) throw new Error('Категория не найдена');
      
      savedCategory = category;
      categories[index] = savedCategory;
    } else {
      // Создание новой категории
      savedCategory = {
        ...category,
        id: `category_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
      } as BlogCategory;
      categories.push(savedCategory);
    }
    
    localStorage.setItem(this.BLOG_CATEGORIES_KEY, JSON.stringify(categories));
    return savedCategory;
  }

  deleteBlogCategory(id: string): boolean {
    const categories = this.getBlogCategories();
    const index = categories.findIndex(c => c.id === id);
    if (index === -1) return false;
    
    // Проверяем, что нет статей с этой категорией
    const posts = this.getBlogPosts();
    const hasPostsWithCategory = posts.some(post => post.category.id === id);
    if (hasPostsWithCategory) {
      throw new Error('Нельзя удалить категорию, которая используется в статьях');
    }
    
    categories.splice(index, 1);
    localStorage.setItem(this.BLOG_CATEGORIES_KEY, JSON.stringify(categories));
    return true;
  }

  // === WORK PHOTOS ===
  getWorkPhotos(): WorkPhoto[] {
    const data = localStorage.getItem(this.WORK_PHOTOS_KEY);
    if (!data) return [];
    
    return JSON.parse(data).map((photo: any) => ({
      ...photo,
      uploadedAt: new Date(photo.uploadedAt)
    }));
  }

  getWorkPhotoById(id: string): WorkPhoto | undefined {
    return this.getWorkPhotos().find(photo => photo.id === id);
  }

  saveWorkPhoto(photo: Omit<WorkPhoto, 'id' | 'uploadedAt'> | WorkPhoto): WorkPhoto {
    const photos = this.getWorkPhotos();
    const now = new Date();
    
    let savedPhoto: WorkPhoto;
    
    if ('id' in photo && photo.id) {
      // Обновление существующего фото
      const index = photos.findIndex(p => p.id === photo.id);
      if (index === -1) throw new Error('Фотография не найдена');
      
      savedPhoto = photo;
      photos[index] = savedPhoto;
    } else {
      // Создание нового фото
      savedPhoto = {
        ...photo,
        id: `photo_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        uploadedAt: now
      } as WorkPhoto;
      photos.push(savedPhoto);
    }
    
    localStorage.setItem(this.WORK_PHOTOS_KEY, JSON.stringify(photos));
    return savedPhoto;
  }

  deleteWorkPhoto(id: string): boolean {
    const photos = this.getWorkPhotos();
    const index = photos.findIndex(p => p.id === id);
    if (index === -1) return false;
    
    photos.splice(index, 1);
    localStorage.setItem(this.WORK_PHOTOS_KEY, JSON.stringify(photos));
    return true;
  }

  // === COLLECTIONS ===
  getCollections(): Collection[] {
    const data = localStorage.getItem(this.COLLECTIONS_KEY);
    return data ? JSON.parse(data) : [];
  }

  getCollectionById(id: string): Collection | undefined {
    return this.getCollections().find(collection => collection.id === id);
  }

  getCollectionBySlug(slug: string): Collection | undefined {
    return this.getCollections().find(collection => collection.slug === slug);
  }

  saveCollection(collection: Omit<Collection, 'id'> | Collection): Collection {
    const collections = this.getCollections();
    
    let savedCollection: Collection;
    
    if ('id' in collection && collection.id) {
      // Обновление существующей коллекции
      const index = collections.findIndex(c => c.id === collection.id);
      if (index === -1) throw new Error('Коллекция не найдена');
      
      savedCollection = collection;
      collections[index] = savedCollection;
    } else {
      // Создание новой коллекции
      savedCollection = {
        ...collection,
        id: `collection_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
      } as Collection;
      collections.push(savedCollection);
    }
    
    localStorage.setItem(this.COLLECTIONS_KEY, JSON.stringify(collections));
    return savedCollection;
  }

  deleteCollection(id: string): boolean {
    const collections = this.getCollections();
    const index = collections.findIndex(c => c.id === id);
    if (index === -1) return false;
    
    collections.splice(index, 1);
    localStorage.setItem(this.COLLECTIONS_KEY, JSON.stringify(collections));
    return true;
  }

  // === UTILITY METHODS ===
  generateSlug(title: string): string {
    return title
      .toLowerCase()
      .replace(/[а-я]/g, (char) => {
        const map: { [key: string]: string } = {
          'а': 'a', 'б': 'b', 'в': 'v', 'г': 'g', 'д': 'd', 'е': 'e', 'ё': 'yo',
          'ж': 'zh', 'з': 'z', 'и': 'i', 'й': 'y', 'к': 'k', 'л': 'l', 'м': 'm',
          'н': 'n', 'о': 'o', 'п': 'p', 'р': 'r', 'с': 's', 'т': 't', 'у': 'u',
          'ф': 'f', 'х': 'h', 'ц': 'ts', 'ч': 'ch', 'ш': 'sh', 'щ': 'sch',
          'ъ': '', 'ы': 'y', 'ь': '', 'э': 'e', 'ю': 'yu', 'я': 'ya'
        };
        return map[char] || char;
      })
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '');
  }

  isSlugUnique(slug: string, excludeId?: string): boolean {
    const posts = this.getBlogPosts();
    const collections = this.getCollections();
    
    const postExists = posts.some(post => post.slug === slug && post.id !== excludeId);
    const collectionExists = collections.some(collection => collection.slug === slug && collection.id !== excludeId);
    
    return !postExists && !collectionExists;
  }
}

export const contentService = new ContentService();