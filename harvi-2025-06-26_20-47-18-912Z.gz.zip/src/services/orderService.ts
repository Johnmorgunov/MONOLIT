import type { Order, OrderStage, ChecklistItem } from '../types/order';
import type { BriefResult } from '../types';
import { orderStages } from '../data/orderStages';
import { addWorkingDays, getProjectEndDate, calculateProjectDuration } from '../utils/workingDays';

class OrderService {
  private readonly ORDERS_KEY = 'admin_orders';
  private readonly ORDER_COUNTER_KEY = 'order_counter';

  // Генерация уникального номера заказа
  generateOrderNumber(): string {
    const currentYear = new Date().getFullYear();
    const counter = this.getNextOrderCounter();
    return `MNL-${currentYear}-${counter.toString().padStart(3, '0')}`;
  }

  private getNextOrderCounter(): number {
    const currentCounter = parseInt(localStorage.getItem(this.ORDER_COUNTER_KEY) || '0');
    const nextCounter = currentCounter + 1;
    localStorage.setItem(this.ORDER_COUNTER_KEY, nextCounter.toString());
    return nextCounter;
  }

  // Создание заказа из результатов брифа
  createOrderFromBrief(briefResult: BriefResult): Order {
    const now = new Date();
    const totalWorkingDays = calculateProjectDuration(orderStages);
    
    // Извлекаем контактную информацию из ответов брифа
    const nameAnswer = briefResult.answers.find(a => a.questionId === 'client_name')?.value as string;
    const phoneAnswer = briefResult.answers.find(a => a.questionId === 'client_phone')?.value as string;
    const emailAnswer = briefResult.answers.find(a => a.questionId === 'client_email')?.value as string;

    const customerName = nameAnswer || 'Клиент';
    const customerPhone = phoneAnswer || '';
    const customerEmail = emailAnswer || undefined;

    // Создаем этапы заказа
    const stages = orderStages.map((stageTemplate, index) => {
      let estimatedStartDate: Date | undefined;
      let estimatedEndDate: Date | undefined;

      // Рассчитываем даты для этапов (кроме свободных)
      if (!stageTemplate.isFlexibleTiming) {
        let workingDayOffset = 0;
        for (let i = 0; i < index; i++) {
          if (!orderStages[i].isFlexibleTiming) {
            workingDayOffset += orderStages[i].estimatedDuration;
          }
        }

        estimatedStartDate = addWorkingDays(now, workingDayOffset);
        estimatedEndDate = addWorkingDays(estimatedStartDate, stageTemplate.estimatedDuration);
      }

      // Создаем чек-лист для этапа
      const checklist: ChecklistItem[] = this.getDefaultChecklistForStage(stageTemplate.id);

      // Календарное планирование
      const schedule = {
        plannedStartDate: estimatedStartDate,
        plannedEndDate: estimatedEndDate,
        actualStartDate: undefined,
        actualEndDate: undefined,
        isOverdue: false,
        daysUntilDeadline: estimatedEndDate ? Math.ceil((estimatedEndDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)) : undefined
      };

      const stage: OrderStage = {
        ...stageTemplate,
        status: index === 0 ? 'current' : 'pending',
        progress: 0,
        estimatedStartDate,
        estimatedEndDate,
        canMarkComplete: index === 0,
        canUnmarkComplete: false,
        schedule,
        checklist,
        checklistProgress: 0
      };

      return stage;
    });

    const order: Order = {
      id: `order-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      orderNumber: this.generateOrderNumber(),
      collectionId: briefResult.collectionId,
      customerName,
      customerPhone,
      customerEmail,
      createdDate: now,
      estimatedCompletionDate: getProjectEndDate(now, totalWorkingDays),
      currentStage: stages[0].id,
      stages,
      totalProgress: 0,
      notes: [
        'Заказ создан на основе заполненного брифа',
        `Дата создания: ${now.toLocaleDateString('ru-RU')} в ${now.toLocaleTimeString('ru-RU')}`
      ],
      isOverdue: false,
      nextDeadline: stages[0].schedule?.plannedEndDate,
      briefData: briefResult // Сохраняем данные брифа
    };

    // Сохраняем заказ
    this.saveOrder(order);

    return order;
  }

  private saveOrder(order: Order): void {
    const existingOrders = this.getAllOrders();
    existingOrders.push(order);
    localStorage.setItem(this.ORDERS_KEY, JSON.stringify(existingOrders));
  }

  private getAllOrders(): Order[] {
    const ordersData = localStorage.getItem(this.ORDERS_KEY);
    if (!ordersData) return [];

    try {
      return JSON.parse(ordersData).map((order: any) => ({
        ...order,
        createdDate: new Date(order.createdDate),
        estimatedCompletionDate: new Date(order.estimatedCompletionDate),
        nextDeadline: order.nextDeadline ? new Date(order.nextDeadline) : undefined,
        stages: order.stages.map((stage: any) => ({
          ...stage,
          estimatedStartDate: stage.estimatedStartDate ? new Date(stage.estimatedStartDate) : undefined,
          estimatedEndDate: stage.estimatedEndDate ? new Date(stage.estimatedEndDate) : undefined,
          schedule: stage.schedule ? {
            ...stage.schedule,
            plannedStartDate: stage.schedule.plannedStartDate ? new Date(stage.schedule.plannedStartDate) : undefined,
            plannedEndDate: stage.schedule.plannedEndDate ? new Date(stage.schedule.plannedEndDate) : undefined,
            actualStartDate: stage.schedule.actualStartDate ? new Date(stage.schedule.actualStartDate) : undefined,
            actualEndDate: stage.schedule.actualEndDate ? new Date(stage.schedule.actualEndDate) : undefined
          } : undefined,
          checklist: stage.checklist.map((item: any) => ({
            ...item,
            completedAt: item.completedAt ? new Date(item.completedAt) : undefined
          }))
        }))
      }));
    } catch (error) {
      console.error('Ошибка загрузки заказов:', error);
      return [];
    }
  }

  // Получение заказа по номеру
  getOrderByNumber(orderNumber: string): Order | null {
    const orders = this.getAllOrders();
    return orders.find(order => order.orderNumber === orderNumber) || null;
  }

  // Создание дефолтного чек-листа для этапа
  private getDefaultChecklistForStage(stageId: string): ChecklistItem[] {
    const baseId = `${stageId}_${Date.now()}`;
    
    switch (stageId) {
      case 'project-discussion-and-info':
        return [
          {
            id: `${baseId}_1`,
            title: 'Провести консультацию с клиентом',
            description: 'Обсудить пожелания, бюджет и требования',
            isCompleted: false,
            isRequired: true
          },
          {
            id: `${baseId}_2`,
            title: 'Определить стиль и материалы',
            description: 'Выбрать коллекцию и основные материалы',
            isCompleted: false,
            isRequired: true
          },
          {
            id: `${baseId}_3`,
            title: 'Согласовать функциональные решения',
            description: 'Обсудить планировку и техническое оснащение',
            isCompleted: false,
            isRequired: true
          },
          {
            id: `${baseId}_4`,
            title: 'Подготовить предварительную смету',
            description: 'Рассчитать примерную стоимость проекта',
            isCompleted: false,
            isRequired: false
          }
        ];

      case 'measurement':
        return [
          {
            id: `${baseId}_1`,
            title: 'Согласовать время замера с клиентом',
            description: 'Назначить удобное время для выезда',
            isCompleted: false,
            isRequired: true
          },
          {
            id: `${baseId}_2`,
            title: 'Провести точные замеры помещения',
            description: 'Измерить все размеры и особенности планировки',
            isCompleted: false,
            isRequired: true
          },
          {
            id: `${baseId}_3`,
            title: 'Сфотографировать помещение',
            description: 'Сделать фото для дизайн-проекта',
            isCompleted: false,
            isRequired: true
          },
          {
            id: `${baseId}_4`,
            title: 'Проверить коммуникации',
            description: 'Оценить состояние электрики, водопровода, газа',
            isCompleted: false,
            isRequired: true
          }
        ];

      case 'design-project':
        return [
          {
            id: `${baseId}_1`,
            title: 'Создать планировочное решение',
            description: 'Разработать оптимальную планировку кухни',
            isCompleted: false,
            isRequired: true
          },
          {
            id: `${baseId}_2`,
            title: 'Подготовить 3D-визуализацию',
            description: 'Создать реалистичные изображения будущей кухни',
            isCompleted: false,
            isRequired: true
          },
          {
            id: `${baseId}_3`,
            title: 'Составить спецификацию материалов',
            description: 'Детальный список всех материалов и комплектующих',
            isCompleted: false,
            isRequired: true
          },
          {
            id: `${baseId}_4`,
            title: 'Согласовать проект с клиентом',
            description: 'Получить одобрение дизайна и внести правки',
            isCompleted: false,
            isRequired: true
          },
          {
            id: `${baseId}_5`,
            title: 'Подготовить чертежи для производства',
            description: 'Технические чертежи для изготовления',
            isCompleted: false,
            isRequired: true
          }
        ];

      case 'production':
        return [
          {
            id: `${baseId}_1`,
            title: 'Заказать материалы и комплектующие',
            description: 'Оформить заказ у поставщиков',
            isCompleted: false,
            isRequired: true
          },
          {
            id: `${baseId}_2`,
            title: 'Распилить детали корпусов',
            description: 'Раскрой ЛДСП и других материалов',
            isCompleted: false,
            isRequired: true
          },
          {
            id: `${baseId}_3`,
            title: 'Изготовить фасады',
            description: 'Производство фасадов согласно проекту',
            isCompleted: false,
            isRequired: true
          },
          {
            id: `${baseId}_4`,
            title: 'Собрать корпуса',
            description: 'Сборка каркасов шкафов',
            isCompleted: false,
            isRequired: true
          },
          {
            id: `${baseId}_5`,
            title: 'Установить фурнитуру',
            description: 'Монтаж петель, направляющих, ручек',
            isCompleted: false,
            isRequired: true
          },
          {
            id: `${baseId}_6`,
            title: 'Контроль качества',
            description: 'Проверка готовых изделий перед отгрузкой',
            isCompleted: false,
            isRequired: true
          }
        ];

      case 'installation':
        return [
          {
            id: `${baseId}_1`,
            title: 'Согласовать дату доставки',
            description: 'Назначить удобное время для клиента',
            isCompleted: false,
            isRequired: true
          },
          {
            id: `${baseId}_2`,
            title: 'Доставить кухню на объект',
            description: 'Транспортировка всех элементов кухни',
            isCompleted: false,
            isRequired: true
          },
          {
            id: `${baseId}_3`,
            title: 'Установить корпуса',
            description: 'Монтаж каркасов и навесных шкафов',
            isCompleted: false,
            isRequired: true
          },
          {
            id: `${baseId}_4`,
            title: 'Установить столешницу',
            description: 'Монтаж и подгонка столешницы',
            isCompleted: false,
            isRequired: true
          },
          {
            id: `${baseId}_5`,
            title: 'Навесить фасады',
            description: 'Установка дверок и ящиков',
            isCompleted: false,
            isRequired: true
          },
          {
            id: `${baseId}_6`,
            title: 'Подключить технику',
            description: 'Подключение встроенной техники',
            isCompleted: false,
            isRequired: false
          },
          {
            id: `${baseId}_7`,
            title: 'Финальная приемка с клиентом',
            description: 'Сдача готового объекта клиенту',
            isCompleted: false,
            isRequired: true
          }
        ];

      default:
        return [
          {
            id: `${baseId}_1`,
            title: 'Выполнить основные работы этапа',
            description: 'Основные задачи данного этапа',
            isCompleted: false,
            isRequired: true
          }
        ];
    }
  }
}

export const orderService = new OrderService();
