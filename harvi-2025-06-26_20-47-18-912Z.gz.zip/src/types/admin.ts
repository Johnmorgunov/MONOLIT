export interface AdminUser {
  id: string;
  username: string;
  role: 'admin' | 'manager';
  lastLogin?: Date;
}

export interface AdminSession {
  user: AdminUser;
  token: string;
  expiresAt: Date;
}

export interface OrderFilter {
  status?: 'all' | 'active' | 'completed' | 'pending' | 'overdue';
  dateFrom?: Date;
  dateTo?: Date;
  createdMonth?: string; // Формат: YYYY-MM
  customerPhone?: string;
  customerEmail?: string;
  orderNumber?: string;
  collectionId?: string;
  priceRange?: 'budget' | 'medium' | 'premium';
  priceFrom?: number;
  priceTo?: number;
}

export interface ChecklistItem {
  id: string;
  title: string;
  description?: string;
  isCompleted: boolean;
  isRequired: boolean;
  completedAt?: Date;
  completedBy?: string;
}

export interface StageSchedule {
  plannedStartDate?: Date;
  plannedEndDate?: Date;
  actualStartDate?: Date;
  actualEndDate?: Date;
  isOverdue: boolean;
  daysUntilDeadline?: number;
}

export interface OrderUpdate {
  orderId: string;
  stageId: string;
  action: 'mark_complete' | 'unmark_complete' | 'update_progress' | 'update_schedule' | 'update_checklist';
  progress?: number;
  note?: string;
  schedule?: Partial<StageSchedule>;
  checklistUpdate?: {
    itemId: string;
    isCompleted: boolean;
  };
  newChecklistItem?: Omit<ChecklistItem, 'id' | 'isCompleted' | 'completedAt' | 'completedBy'>;
}

export interface AdminStats {
  totalOrders: number;
  activeOrders: number;
  completedOrders: number;
  overdueOrders: number;
  averageCompletionTime: number;
  stageStatistics: {
    stageId: string;
    stageName: string;
    averageDuration: number;
    completionRate: number;
    overdueCount: number;
  }[];
}