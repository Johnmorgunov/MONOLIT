export interface Collection {
  id: string;
  title: string;
  description: string;
  price: string;
  image: string;
  slug: string;
  detailedDescription: string;
  features: string[];
  specifications: {
    materials: string[];
    colors: string[];
    sizes: string[];
    warranty: string;
  };
  gallery: string[];
  startingPrice: number; // Добавляем числовое значение для фильтрации
}

export interface Feature {
  id: string;
  icon: string;
  title: string;
  description: string;
}

export interface ProcessStep {
  id: string;
  number: number;
  title: string;
  description: string;
}

export interface ContactInfo {
  address: string;
  phone: string;
  email: string;
  whatsapp?: string;
  telegram?: string;
}

export interface BriefQuestion {
  id: string;
  type: 'single' | 'multiple' | 'range' | 'text' | 'select';
  question: string;
  description?: string;
  options?: BriefOption[];
  min?: number;
  max?: number;
  unit?: string;
  required: boolean;
}

export interface BriefOption {
  id: string;
  label: string;
  description?: string;
  image?: string;
}

export interface BriefAnswer {
  questionId: string;
  value: string | string[] | number;
}

export interface BriefResult {
  collectionId: string;
  answers: BriefAnswer[];
  timestamp: Date;
  contactInfo?: {
    name: string;
    phone: string;
    email: string;
  };
  dataProcessingConsent: boolean;
  consentTimestamp: Date;
}

export interface BriefStep {
  id: string;
  title: string;
  description: string;
  questions: BriefQuestion[];
}

export interface DataProcessingConsent {
  id: string;
  type: 'brief' | 'consultation' | 'messenger' | 'telegram';
  timestamp: Date;
  userAgent: string;
  ipAddress?: string;
  collectionId?: string;
}

// Типы для блога и полезной информации
export interface BlogPost {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  featuredImage: string;
  category: BlogCategory;
  tags: string[];
  author: string;
  publishedAt: Date;
  updatedAt: Date;
  isPublished: boolean;
  readTime: number; // в минутах
}

export interface BlogCategory {
  id: string;
  name: string;
  slug: string;
  description: string;
  color: string;
}

export interface WorkPhoto {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  category: 'kitchen' | 'design' | 'installation' | 'materials';
  collectionId?: string;
  tags: string[];
  uploadedAt: Date;
  isPublished: boolean;
}