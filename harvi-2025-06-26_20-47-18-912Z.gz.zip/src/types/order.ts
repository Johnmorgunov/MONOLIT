export interface ChecklistItem {
  id: string;
  title: string;
  description?: string;
  isCompleted: boolean;
  isRequired: boolean;
  completedAt?: Date;
  completedBy?: string;
}

export interface StageSchedule {
  plannedStartDate?: Date;
  plannedEndDate?: Date;
  actualStartDate?: Date;
  actualEndDate?: Date;
  isOverdue: boolean;
  daysUntilDeadline?: number;
}

export interface OrderStage {
  id: string;
  title: string;
  description: string;
  status: 'pending' | 'in-progress' | 'completed' | 'current';
  estimatedStartDate?: Date; // Предварительная дата начала
  estimatedEndDate?: Date;   // Предварительная дата завершения
  estimatedDuration: number; // в рабочих днях (0 для свободного времени)
  isFlexibleTiming?: boolean; // Этап со свободным временем
  progress: number; // 0-100
  canMarkComplete?: boolean; // Возможность ручного отмечания как выполненный
  canUnmarkComplete?: boolean; // Возможность отмены выполнения
  schedule?: StageSchedule; // Календарное планирование
  checklist: ChecklistItem[]; // Чек-лист для этапа
  checklistProgress: number; // Процент выполнения чек-листа (0-100)
}

export interface Order {
  id: string;
  orderNumber: string;
  collectionId: string;
  customerName: string;
  customerPhone: string;
  customerEmail?: string;
  createdDate: Date;
  estimatedCompletionDate: Date;
  currentStage: string;
  stages: OrderStage[];
  totalProgress: number;
  notes?: string[];
  isOverdue?: boolean;
  nextDeadline?: Date;
  briefData?: any; // Данные из брифа
}

export interface OrderAnalytics {
  totalOrders: number;
  averageCompletionTime: number;
  stageStatistics: {
    stageId: string;
    averageDuration: number;
    completionRate: number;
  }[];
}
