// Утилиты для валидации данных
export const ValidationPatterns = {
  phone: /^(\+7|8)?[\s\-]?\(?[489][0-9]{2}\)?[\s\-]?[0-9]{3}[\s\-]?[0-9]{2}[\s\-]?[0-9]{2}$/,
  email: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
  name: /^[а-яёА-ЯЁa-zA-Z\s]{2,50}$/
};

export const validatePhone = (phone: string): boolean => {
  const cleanPhone = phone.replace(/[\s\-\(\)]/g, '');
  return ValidationPatterns.phone.test(cleanPhone);
};

export const validateEmail = (email: string): boolean => {
  return ValidationPatterns.email.test(email.trim());
};

export const validateName = (name: string): boolean => {
  return ValidationPatterns.name.test(name.trim());
};

export const sanitizeInput = (input: string): string => {
  return input
    .replace(/[<>]/g, '')
    .replace(/javascript:/gi, '')
    .replace(/on\w+=/gi, '')
    .trim();
};

export const formatPhone = (phone: string): string => {
  const cleaned = phone.replace(/\D/g, '');
  if (cleaned.length === 11 && cleaned.startsWith('8')) {
    return `+7 (${cleaned.slice(1, 4)}) ${cleaned.slice(4, 7)}-${cleaned.slice(7, 9)}-${cleaned.slice(9)}`;
  }
  if (cleaned.length === 11 && cleaned.startsWith('7')) {
    return `+7 (${cleaned.slice(1, 4)}) ${cleaned.slice(4, 7)}-${cleaned.slice(7, 9)}-${cleaned.slice(9)}`;
  }
  return phone;
};

export const getValidationError = (field: string, value: string): string | null => {
  switch (field) {
    case 'name':
      if (!value.trim()) return 'Имя обязательно для заполнения';
      if (!validateName(value)) return 'Имя должно содержать только буквы и быть от 2 до 50 символов';
      return null;
    
    case 'phone':
      if (!value.trim()) return 'Телефон обязателен для заполнения';
      if (!validatePhone(value)) return 'Введите корректный номер телефона';
      return null;
    
    case 'email':
      if (value.trim() && !validateEmail(value)) return 'Введите корректный email адрес';
      return null;
    
    default:
      return null;
  }
};
