// Утилиты для работы с рабочими днями
export const WorkingDaysConfig = {
  // Российские праздничные дни (можно расширить)
  holidays: [
    '2025-01-01', '2025-01-02', '2025-01-03', '2025-01-04', '2025-01-05', '2025-01-06', '2025-01-07', '2025-01-08',
    '2025-02-23', '2025-03-08', '2025-05-01', '2025-05-09', '2025-06-12', '2025-11-04'
  ],
  // Рабочие дни недели (1 = понедельник, 7 = воскресенье)
  workingDays: [1, 2, 3, 4, 5] // Понедельник - Пятница
};

export const isWorkingDay = (date: Date): boolean => {
  const dayOfWeek = date.getDay();
  const dateString = date.toISOString().split('T')[0];
  
  // Проверяем, что это рабочий день недели (понедельник-пятница)
  const isWeekday = dayOfWeek >= 1 && dayOfWeek <= 5;
  
  // Проверяем, что это не праздничный день
  const isNotHoliday = !WorkingDaysConfig.holidays.includes(dateString);
  
  return isWeekday && isNotHoliday;
};

export const addWorkingDays = (startDate: Date, workingDaysToAdd: number): Date => {
  const result = new Date(startDate);
  let daysAdded = 0;
  
  while (daysAdded < workingDaysToAdd) {
    result.setDate(result.getDate() + 1);
    
    if (isWorkingDay(result)) {
      daysAdded++;
    }
  }
  
  return result;
};

export const getWorkingDaysBetween = (startDate: Date, endDate: Date): number => {
  let workingDays = 0;
  const current = new Date(startDate);
  
  while (current <= endDate) {
    if (isWorkingDay(current)) {
      workingDays++;
    }
    current.setDate(current.getDate() + 1);
  }
  
  return workingDays;
};

export const formatWorkingDaysText = (days: number): string => {
  if (days === 0) return 'свободное время';
  if (days === 1) return '1 рабочий день';
  if (days >= 2 && days <= 4) return `${days} рабочих дня`;
  return `${days} рабочих дней`;
};

export const getNextWorkingDay = (date: Date): Date => {
  const result = new Date(date);
  
  do {
    result.setDate(result.getDate() + 1);
  } while (!isWorkingDay(result));
  
  return result;
};

export const getPreviousWorkingDay = (date: Date): Date => {
  const result = new Date(date);
  
  do {
    result.setDate(result.getDate() - 1);
  } while (!isWorkingDay(result));
  
  return result;
};

export const calculateProjectDuration = (stages: { estimatedDuration: number; isFlexibleTiming?: boolean }[]): number => {
  return stages
    .filter(stage => !stage.isFlexibleTiming)
    .reduce((total, stage) => total + stage.estimatedDuration, 0);
};

export const getProjectEndDate = (startDate: Date, totalWorkingDays: number): Date => {
  return addWorkingDays(startDate, totalWorkingDays);
};
